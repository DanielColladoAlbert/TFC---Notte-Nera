const express = require("express");
const router = express.Router();
const tatuajesRealizadosController = require("../controller/tatuajesRealizados.controller");
const jwtMW = require("../middlewares/jwt.mw");
const upload = require("../utils/multer.config");
const rutasProtegidas = require("../middlewares/rutasprotegidas.mw");

// Ruta para mostrar todos los tatuajes realizados
router.get("/", jwtMW.authenticate, rutasProtegidas.userBlocked, tatuajesRealizadosController.verTodosTatuajes);

// Ruta para crear un nuevo tatuaje realizado
router.post("/nuevo", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, upload.single("foto"), tatuajesRealizadosController.crearTatuaje);

// Ruta para obtener los datos de un tatuaje para editar
router.get("/editar/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, tatuajesRealizadosController.obtenerTatuaje);

// Ruta para editar un tatuaje realizado
router.patch("/editar/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, upload.single("foto"), tatuajesRealizadosController.editarTatuaje);

// Ruta para eliminar un tatuaje realizado
router.delete("/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, tatuajesRealizadosController.eliminarTatuaje);

module.exports = router;