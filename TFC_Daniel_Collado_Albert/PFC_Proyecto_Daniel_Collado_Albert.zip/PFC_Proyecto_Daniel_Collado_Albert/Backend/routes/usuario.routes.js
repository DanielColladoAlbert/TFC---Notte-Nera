const userController = require("../controller/usuario.controller");
const express = require("express");
const router = express.Router();
const upload = require("../utils/multer.config");
const jwtMW = require("../middlewares/jwt.mw");
const rutasProtegidas = require("../middlewares/rutasprotegidas.mw");

// Rutas de Inicio

// Ruta para la sesión
router.post("/login", userController.login);
router.get("/logout", userController.logout);

// Ruta para registrar un usuario
router.post("/registro", upload.single("foto"), userController.registro);

// Ruta para listar todos los usuarios
router.get("/lista", jwtMW.authenticate, rutasProtegidas.userBlocked, userController.listaUsuarios);

// Ruta para ver el perfil de un usuario por ID
router.get("/perfil/:id", jwtMW.authenticate, userController.verUsuarioPorId);

// Ruta para editar un usuario
router.patch("/editar/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, upload.single("foto"), userController.editarUsuario);

// Ruta para eliminar un usuario
router.delete("/:id", jwtMW.authenticate, userController.eliminarUsuario);

// Ruta para contar administradores
router.get('/contarAdmins', jwtMW.authenticate, rutasProtegidas.userBlocked, userController.contarAdministradores);

// Ruta para cambiar el perfil de un usuario (admin)
router.patch("/cambiarPerfil/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, userController.cambiarPerfil);

// Ruta para verificar la contraseña
router.post("/verificarContrasena",jwtMW.authenticate, rutasProtegidas.userBlocked, userController.validarContrasena);

// Ruta para ver la página de bloqueo de usuario (admin)
router.get("/bloquear/:id", jwtMW.authenticate, userController.verBloquear);

// Ruta para bloquear un usuario (admin)
router.patch("/bloquear/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, userController.bloquearUsuario);

module.exports = router;