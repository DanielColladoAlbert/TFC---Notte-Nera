const express = require("express");
const router = express.Router();
const citasController = require("../controller/citas.controller");
const jwtMW = require("../middlewares/jwt.mw");
const upload = require("../utils/multer.config");
const { userBlocked } = require("../middlewares/rutasprotegidas.mw"); // Asegúrate de que la ruta sea correcta

// Ruta para mostrar todas las citas
router.get("/", jwtMW.authenticate, citasController.verTodasCitas);

// Ruta para añadir una nueva cita
router.get("/nueva", jwtMW.authenticate, userBlocked, citasController.verNuevaCita);
router.post("/nueva", jwtMW.authenticate, userBlocked, upload.single("foto"), citasController.crearCita);

// Ruta para ver los detalles de la cita
router.get("/verDetalles/:id", jwtMW.authenticate, userBlocked, citasController.verDetalles);

// Ruta para editar una cita
router.get("/editar/:id", jwtMW.authenticate, userBlocked, citasController.verEditarCita);
router.patch("/editar/:id", jwtMW.authenticate, userBlocked, upload.single("foto"), citasController.editarCita);

// Ruta para eliminar una cita
router.delete("/:id", jwtMW.authenticate, userBlocked, citasController.eliminarCita);

module.exports = router;
