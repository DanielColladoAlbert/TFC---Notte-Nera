const express = require("express")
const resenasController = require("../controller/resenas.controller")
const usuariosController = require("../controller/usuario.controller")
const jwtMW = require("../middlewares/jwt.mw")
const rutasProtegidas = require("../middlewares/rutasprotegidas.mw")


const router = express.Router()

// Ruta para mostrar todas las reseñas
router.get("/", jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.verTodasResenas)

// Ruta para crear una reseña
router.post("/nueva", jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.crearResena)

// Ruta para ver las estadisticas de las reseñas
router.get('/estadisticas',jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, resenasController.obtenerEstadisticas)

// Ruta para editar una reseña
router.get("/editar/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.verEditarResena)
router.patch("/editar/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.editarResena)

// Ruta para eliminar una reseña
router.delete("/:id", jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.eliminarResena)

// Ruta para actualizar el estado de una reseña
router.patch('/estado/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, resenasController.actualizarEstadoResena)
router.patch('/anonimizar/:clienteId',jwtMW.authenticate, resenasController.anonimizarResenasPorCliente)

// Rutas de usuarios

// Ruta para bloquear al usuario
router.get("/bloquear/:id",jwtMW.authenticate, rutasProtegidas.requireAdmin, rutasProtegidas.userBlocked, usuariosController.verBloquear)

module.exports = router