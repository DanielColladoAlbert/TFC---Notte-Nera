const express = require('express');
const router = express.Router();
const disenosController = require('../controller/disenosDisponibles.controller');
const jwtMW = require("../middlewares/jwt.mw");
const upload = require("../utils/multer.config");
const rutasProtegidas = require("../middlewares/rutasprotegidas.mw");

// Ruta para mostrar todas los diseños disponibles
router.get('/', jwtMW.authenticate, rutasProtegidas.userBlocked, disenosController.inicio);

// Ruta para crear un diseño disponible
router.get('/nuevo', jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, disenosController.verCrear);
router.post('/nuevo', jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, upload.single('foto'), disenosController.crear);

// Ruta para editar un diseño disponible
router.get('/editar/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, disenosController.verEditar);
router.patch('/editar/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, upload.single('foto'), disenosController.editar);
router.patch('/editar/disponible/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, disenosController.editarDisponible);

// Ruta para eliminar un diseño disponible
router.delete('/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, rutasProtegidas.requireAdmin, disenosController.eliminar);

// Ruta para reservar un diseño disponible
router.post('/reservar/:id', jwtMW.authenticate, rutasProtegidas.userBlocked, disenosController.reservarCita);

module.exports = router;
