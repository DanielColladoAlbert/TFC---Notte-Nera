require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") }) // Forzar carga con una ruta absoluta, porque sino no carga los seeds
const mongoose = require("mongoose")


exports.conectarMongoDB = async() => {
    return mongoose.connect(process.env.MONGODB_CONSTRING)
}