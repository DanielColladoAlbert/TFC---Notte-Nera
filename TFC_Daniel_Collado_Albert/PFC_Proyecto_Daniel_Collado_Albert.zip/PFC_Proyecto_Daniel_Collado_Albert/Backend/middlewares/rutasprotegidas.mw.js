const AppError = require("../utils/AppError")

const checkProfile = (req, profileParam) => {
    if (req.session &&
        req.session.userLogued &&
        req.session.userLogued.data &&
        req.session.userLogued.data.perfil && 
        req.session.userLogued.data.perfil === profileParam
    ) {
        return true
    } else {
        return false
    }
}

const checkIfBlocked = (req) => {
    if (req.session &&
        req.session.userLogued &&
        req.session.userLogued.data &&
        req.session.userLogued.data.isBlocked !== undefined
    ) {
        return req.session.userLogued.data.isBlocked === true;
    } else {
        return false;
    }
};

exports.userBlocked = (req, res, next) => {
    
    if (checkIfBlocked(req)) {
        return res.status(403).json({
            success: false,
            error: "Acceso denegado. Usuario bloqueado.",
        });
    }
    next();
};

exports.requireAdmin = (req, res, next) => {
  if (checkProfile(req, "ADMIN")) {
    next();
  } else {
    res.status(403).json({
      success: false,
      error: "Acceso denegado. No tienes permisos de administrador.",
    });
  }
};