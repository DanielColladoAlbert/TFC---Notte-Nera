// middlewares/authMiddleware.js
const jwt = require("jsonwebtoken");
const AppError = require("../utils/AppError");
const User = require("../models/usuario.model");

function extractToken(req) {
  if (req.headers.authorization?.startsWith("Bearer ")) {
    return req.headers.authorization.split(" ")[1];
  }
  if (req.query?.token) return req.query.token;
  if (req.session?.userLogued?.token) return req.session.userLogued.token;
  return null;
}

exports.authenticate = async (req, res, next) => {
  const token = extractToken(req);

  if (!token) return next(new AppError("Token no proveído", 401));

  try {
    const decoded = jwt.verify(token, process.env.SECRET_JWT);

    const user = await User.findById(decoded.id);

    if (!user) return next(new AppError("Usuario no encontrado", 401));
    if (user.isBlocked) return next(new AppError("Usuario bloqueado", 403));

    req.user = user;
    req.session.userLogued = { data: decoded };
    next();
  } catch (err) {
    console.error("Error al verificar token:", err.message);
    next(new AppError("Token inválido", 401));
  }
};


exports.createJWT = (userData) => {
  try {
    const payload = {
      id: userData.id || userData._id,
      perfil: userData.perfil,
      isBlocked: userData.bloqueado || false
    };

    const token = jwt.sign(payload, process.env.SECRET_JWT, {
      expiresIn: "24h",
    });

    return token;
  } catch (error) {
    throw new Error("Error al crear el token: " + error.message);
  }
};


exports.destroyJWT = (req) => {
  // Verifica si existe el token en la sesión
  if (!req.session || !req.session.userLogued || !req.session.userLogued.token) {
    return false;
  }

  try {
    // Firma un token vacío con expiración inmediata para invalidarlo
    jwt.sign({}, process.env.SECRET_JWT, { expiresIn: 1 });
    req.session.userLogued.token = null;
    return true;
  } catch (error) {
    console.error("Error al destruir el token:", error.message);
    return false;
  }
};