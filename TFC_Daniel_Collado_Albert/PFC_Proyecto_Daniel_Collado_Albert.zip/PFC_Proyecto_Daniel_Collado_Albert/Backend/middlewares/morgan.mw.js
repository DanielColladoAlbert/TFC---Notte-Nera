require("dotenv").config()
const morgan = require("morgan")
const fs = require("fs")
const express = require("express")
const app = express()
const ruta = process.env.LOGS_FOLDER

exports.usingMorgan = () => {
    return morgan("combined", {    
      stream: app.get("env") == "development"?fs.createWriteStream(ruta + "access.log", {flags:"a"}):''
    })
}