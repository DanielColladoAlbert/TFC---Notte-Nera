const mongoose = require("mongoose")

const tatuajeSchema = new mongoose.Schema({
    foto: {
        type: String,
        required: true
    },
    titulo: {
        type: String,
        required: true,
    },
    descripcion: {
        type: String,
        required: true
    },
    tamano: {
        type: String
    },
    tipo: {
        type: String,
    },
    fecha: {
        type: Date,
        default: Date.now
    },
    nombreCliente: {
        type: String,
        required: true
    },
})

const Tatuaje = mongoose.model("Tatuaje", tatuajeSchema, "tatuajesRealizados")

Tatuaje.buscarTodo = async function () {
    try {
        return await Tatuaje.find({})
    } catch (err) {
        throw new Error("Error al obtener los tatuajes: " + err.message)
    }
}

Tatuaje.crearTatuaje = async function (tatuajeData) {
    try {
        const newTatuaje = new Tatuaje(tatuajeData)
        return await newTatuaje.save()
    } catch (err) {
        throw new Error("Error al crear el tatuaje: " + err.message) 
    }
}

Tatuaje.editarTatuajeById = async function (id, tatuajeData) {
    try {
        return await Tatuaje.findByIdAndUpdate(id, tatuajeData, { runValidators: true, new: true })
    } catch (err) {
        throw new Error(err)
    }
}

module.exports = Tatuaje
