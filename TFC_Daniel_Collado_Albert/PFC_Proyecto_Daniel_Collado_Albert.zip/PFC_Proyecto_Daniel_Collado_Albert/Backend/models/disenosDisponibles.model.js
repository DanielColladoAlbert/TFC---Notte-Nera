const mongoose = require("mongoose")

const disenoSchema = new mongoose.Schema({
    foto: {
        type: String,
        required: true
    },
    titulo: {
        type: String,
        required: true
    },
    descripcion: {
        type: String,
        required: true
    },
    tamano: {
        type: String,
        required: true
    },
    tipo: {
        type: String,
        required: true
    },
    precio: {
        type: Number,
        required: true
    },
    tiempoEstimado: {
        type: String,
        required: true
    },
    disponible: {
        type: Boolean,
        default: true
    },
    precioExclusivo: {
        type: Number,
        required: true
    },
    yaRealizado: {
        type: Boolean,
        default: false
    },
})

const Diseno = mongoose.model("Diseno", disenoSchema, "disenosDisponibles")

Diseno.crearDiseno = async function (disenoData) {
    try {
        const nuevoDiseno = new Diseno(disenoData)
        return await nuevoDiseno.save()
    } catch (err) {
        throw new Error(err)
    }
}

Diseno.buscarTodo = async function () {
    try {
        return await Diseno.find({})
    } catch (err) {
        throw new Error(err)
    }
}

Diseno.buscarDisenoPorId = async function (id) {
    try {
        const diseno = await Diseno.findById(id)
        if (!diseno) throw new Error("Diseño no encontrado")
        return diseno
    } catch (err) {
        throw new Error(err.message)
    }
}

Diseno.editarDisenoPorId = async function (id, disenoData) {
    try {
        return await Diseno.findByIdAndUpdate(id, disenoData, { runValidators: true, new: true })
    } catch (err) {
        throw new Error(err)
    }
}

Diseno.eliminarDisenoPorId = async function (id) {
    try {
        const deletedDiseno = await Diseno.findByIdAndDelete(id)
        if (!deletedDiseno) throw new Error("Diseño no encontrado")
        return deletedDiseno
    } catch (err) {
        throw err
    }
}

module.exports = Diseno