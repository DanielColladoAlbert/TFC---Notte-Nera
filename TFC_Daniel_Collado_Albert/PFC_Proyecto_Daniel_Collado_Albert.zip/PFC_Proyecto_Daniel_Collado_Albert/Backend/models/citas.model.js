const mongoose = require("mongoose")

const citasSchema = new mongoose.Schema({
    clienteId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
    },
    nombreCompletoCliente: {
        type: String,
        required: true
    },
    foto: {
        type: String,
        required: true
    },
    descripcion: {
        type: String,
        required: true
    },
    tamano: {
        type: String,
        required: true
    },
    fecha: {
        type: Date,
        default: Date.now,
        required: true
    },
    precio: {
        type: Number
    },
    tiempoEstimado: {
        type: String
    },
    estado: {
        type: String,
        enum: ["pendiente", "confirmada", "cancelada"],
        default: "pendiente"
    },
    motivoCancelacion: {
        type: String
    },
    conversacion:{
        type: Array
    }
})

const Cita = mongoose.model("Cita", citasSchema, "citas")

Cita.crearCita = async function (citaData) {
    try {
        const nuevaCita = new Cita(citaData)
        return await nuevaCita.save()
    } catch (err) {
        throw new Error(err)
    }
}

Cita.buscarTodo = async function () {
    try {
        return await Cita.find({})
    } catch (err) {
        throw new Error(err)
    }
}

Cita.buscarCitaPorId = async function (id) {
    try {
        const cita = await Cita.findById(id)
        if (!cita) throw new Error("Cita no encontrada")
        return cita
    } catch (err) {
        throw new Error(err.message)
    }
}

Cita.editarCitaPorId = async function (id, citaData) {
    try {
        return await Cita.findByIdAndUpdate(id, citaData, { runValidators: true, new: true })
    } catch (err) {
        throw new Error(err)
    }
}

Cita.eliminarCitaPorId = async function (id) {
    try {
        const deletedCita = await Cita.findByIdAndDelete(id)
        if (!deletedCita) throw new Error("Cita no encontrada")
        return deletedCita
    } catch (err) {
        throw err
    }
}

module.exports = Cita