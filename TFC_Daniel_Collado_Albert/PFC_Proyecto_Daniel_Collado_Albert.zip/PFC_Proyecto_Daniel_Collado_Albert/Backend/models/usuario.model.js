const mongoose = require("mongoose")

const userSchema = new mongoose.Schema({
    nombreUsuario: {
        type: String,
        required: true,
        unique: true
    },
    contrasena: {
        type: String,
        required: true
    },
    nombre: {
        type: String,
        required: true
    },
    apellidos: {
        type: String,
        required: true
    },
    correo: {
        type: String,
        required: true,
        unique: true
    },
    foto: {
        type: String
    },
    perfil: {
        type: String,
        enum: ["ADMIN", "USUARIO"],
        default: "USUARIO"
    },
    bloqueado: {
        type: Boolean,
        default: false
    },
    motivoBloqueo: {
        type: String
    }, 
    fechaBloqueo: {
        type: Date
    }
})

const User = mongoose.model("User", userSchema, "usuarios")

User.crearUsuario = async function (userData) {
    try {
        const newUser = new User(userData)
        return await newUser.save()
    } catch (err) {
        throw new Error(err)
    }
}

User.buscarTodo = async function () {
    try {
        return await User.find({})
    } catch (err) {
        throw new Error(err)
    }
}

User.buscarUsuarioPorId = async function(id) {
    try {
        const user = await User.findById(id)
        if (!user) throw new Error("Usuario no encontrado")
        return user
    } catch (err) {
        throw new Error(err.message) 
    }
}

User.editarUsuarioPorId = async function (id, userData) {
    try {
        return await User.findByIdAndUpdate(id, userData, { runValidators: true, new: true })
    } catch (err) {
        throw new Error(err)
    }
}

User.eliminarUsuarioById = async function (id) {
    try {
        const deletedUser = await User.findByIdAndDelete(id)
        if (!deletedUser) throw new Error("Usuario no encontrado")
        return deletedUser
    } catch (err) {
        throw err 
    }
}

User.buscarPorNombreUsuario = async function (usernameParam) {
    try {
        const user = await User.findOne({ nombreUsuario: usernameParam })
        if (!user) throw new Error("No hay datos del usuario")
        return user
    } catch (error) {
        throw new Error(error)
    }
}

module.exports = User
