const mongoose = require("mongoose")

const resenaSchema = new mongoose.Schema({
    clienteId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: false 
    },
    nombreUsuario: {
        type: String,
        required: true
    },
    fotoPerfil: {
        type: String
    },
    resena: {
        type: String,
        required: true
    },
    estrellas: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    aprobado: {
        type: String,
        enum: ["por aprobar", "aprobado", "cancelado"],
        default: "por aprobar"
    },
    fecha: {
        type: Date,
        default: Date.now,
        required: true
    }
})

const Resena = mongoose.model("Resena", resenaSchema, "resenas")

Resena.crearResena = async function (resenaData) {
    try {
        const nuevaResena = new Resena(resenaData)
        return await nuevaResena.save()
    } catch (err) {
        throw new Error(err)
    }
}

Resena.buscarTodo = async function () {
    try {
        return await Resena.find({})
    } catch (err) {
        throw new Error(err)
    }
}

Resena.buscarResenaPorId = async function (id) {
    try {
        const resena = await Resena.findById(id)
        if (!resena) throw new Error("Reseña no encontrada")
        return resena
    } catch (err) {
        throw new Error(err.message)
    }
}

Resena.editarResenaById = async function (id, resenaData) {
    try {
        return await Resena.findByIdAndUpdate(id, resenaData, { runValidators: true, new: true })
    } catch (err) {
        throw new Error(err)
    }
}

Resena.eliminarResenaPorId = async function (id) {
    try {
        const deletedResena = await Resena.findByIdAndDelete(id)
        if (!deletedResena) throw new Error("Reseña no encontrada")
        return deletedResena
    } catch (err) {
        throw err
    }
}

module.exports = Resena