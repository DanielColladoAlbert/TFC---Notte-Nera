const disenoModel = require('../models/disenosDisponibles.model')
const mongoose = require('mongoose')
const { wrapAsync } = require("../utils/functions")
const AppError = require("../utils/AppError")
const fs = require("fs")
const path = require("path")

exports.inicio = wrapAsync(async (req, res, next) => {
    try {
        const disenos = await disenoModel.buscarTodo()
        const user = req.session.userLogued || null
        res.json({ disenos, user,  success: true, })
    } catch (error) {
        res.status(500).json({ error: error.message, success: false })
    }
})

exports.verCrear = wrapAsync(async (req, res, next) => {
    const user = req.session.userLogued || null
    res.json({ user })
})

function validarCamposDiseno({ foto, titulo, descripcion, tamano, tipo, precio, tiempoEstimado, precioExclusivo }) {
    if (!foto || (typeof foto !== "string" && typeof foto !== "object")) {
        throw new AppError("La foto es obligatoria", 400);
    }
    if (!titulo || typeof titulo !== "string" || !titulo.trim()) {
        throw new AppError("El título es obligatorio y debe ser una cadena", 400);
    }
    if (!descripcion || typeof descripcion !== "string" || !descripcion.trim()) {
        throw new AppError("La descripción es obligatoria y debe ser una cadena", 400);
    }
    if (!tamano || typeof tamano !== "string" || !tamano.trim()) {
        throw new AppError("El tamaño es obligatorio y debe ser una cadena", 400);
    }
    if (!tipo || typeof tipo !== "string" || !tipo.trim()) {
        throw new AppError("El tipo es obligatorio y debe ser una cadena", 400);
    }
    if (precio === undefined || isNaN(Number(precio)) || Number(precio) < 0) {
        throw new AppError("El precio es obligatorio y debe ser un número positivo", 400);
    }
    if (!tiempoEstimado || typeof tiempoEstimado !== "string" || !tiempoEstimado.trim()) {
        throw new AppError("El tiempo estimado es obligatorio y debe ser una cadena", 400);
    }
    if (precioExclusivo === undefined || isNaN(Number(precioExclusivo)) || Number(precioExclusivo) < 0) {
        throw new AppError("El precio exclusivo es obligatorio y debe ser un número positivo", 400);
    }
}

exports.crear = wrapAsync(async (req, res, next) => {
    try {
        const { titulo, descripcion, tamano, tipo, precio, tiempoEstimado, precioExclusivo } = req.body;
        let foto = req.file ? "/uploads/" + req.file.filename : req.body.foto;

        try {
            validarCamposDiseno({ foto, titulo, descripcion, tamano, tipo, precio, tiempoEstimado, precioExclusivo });
        } catch (err) {
            // Si se subió una imagen pero los datos son inválidos, eliminar la imagen subida
            if (req.file && foto) {
                const newImagePath = path.join(__dirname, "..", "public", foto);
                if (fs.existsSync(newImagePath)) {
                    fs.unlinkSync(newImagePath);
                }
            }
            return next(err);
        }

        const nuevoDiseno = {
            foto,
            titulo,
            descripcion,
            tamano,
            tipo,
            precio,
            tiempoEstimado,
            disponible: true,
            esExclusivo: false,
            precioExclusivo,
            yaRealizado: false
        };

        const disenoCreado = await disenoModel.crearDiseno(nuevoDiseno);
        res.status(201).json({ mensaje: 'Diseño creado', disenoCreado });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

exports.verEditar = wrapAsync(async function (req, res, next) {
    const disenoId = req.params.id
    if (!mongoose.Types.ObjectId.isValid(disenoId)) {
        return next(new AppError("ID de diseño no válido", 400))
    }
    try {
        const diseno = await disenoModel.buscarDisenoPorId(disenoId)
        if (!diseno) {
            return next(new AppError("Diseño no encontrado", 404))
        }
        const user = req.session.userLogued || null
        res.json({ diseno, user })
    } catch (err) {
        next(new AppError(err.message, 500))
    }
})

exports.editar = wrapAsync(async (req, res, next) => {
    try {
        const { id } = req.params
        const { titulo, descripcion, tamano, tipo, precio, tiempoEstimado, precioExclusivo } = req.body
        let foto = req.file ? "/uploads/" + req.file.filename : req.body.foto

        const disponible = Array.isArray(req.body.disponible)
            ? req.body.disponible.pop() === 'true'
            : req.body.disponible === 'true'

        const yaRealizado = Array.isArray(req.body.yaRealizado)
            ? req.body.yaRealizado.pop() === 'true'
            : req.body.yaRealizado === 'true'

        const diseno = await disenoModel.findById(id)
        if (!diseno) {
            return res.status(404).json({ error: 'Diseño no encontrado' })
        }

        try {
            validarCamposDiseno({ foto, titulo, descripcion, tamano, tipo, precio, tiempoEstimado, precioExclusivo });
        } catch (err) {
            return next(err);
        }

        if (req.file && diseno.foto) {
            const oldImagePath = `./public${diseno.foto}`
            if (fs.existsSync(oldImagePath)) {
                fs.unlinkSync(oldImagePath)
            }
        }

        const disenoActualizado = await disenoModel.editarDisenoPorId(id, {
            foto,
            titulo,
            descripcion,
            tamano,
            tipo,
            precio,
            tiempoEstimado,
            disponible,
            precioExclusivo,
            yaRealizado
        })

        if (!disenoActualizado) {
            return res.status(404).json({ error: 'Diseño no encontrado' })
        }

        res.json({ mensaje: 'Diseño actualizado', disenoActualizado })
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
})

exports.editarDisponible = wrapAsync(async (req, res, next) => {
    try {
        const { id } = req.params;
        const { disponible } = req.body;

        // Convertir el valor de 'disponible' a un booleano
        const disponibleBoolean = Array.isArray(disponible)
            ? disponible.pop() === 'true'
            : disponible === 'true';

        const diseno = await disenoModel.findById(id);
        if (!diseno) {
            return res.status(404).json({ error: 'Diseño no encontrado' });
        }

        // Actualizar solo el campo 'disponible'
        const disenoActualizado = await disenoModel.editarDisenoPorId(id, {
            disponible: disponibleBoolean
        });

        if (!disenoActualizado) {
            return res.status(404).json({ error: 'Diseño no encontrado' });
        }

        res.json({ mensaje: 'Disponibilidad del diseño actualizada', disenoActualizado });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

exports.eliminar = wrapAsync(async (req, res, next) => {
    try {
        const { id } = req.params
        const diseno = await disenoModel.eliminarDisenoPorId(id)
        if (!diseno) {
            return next(new AppError("Diseño no encontrado", 404))
        }
        if (diseno.foto) {
            const rutaImagen = path.join(__dirname, "..", "public", diseno.foto)
            if (fs.existsSync(rutaImagen)) {
                fs.unlinkSync(rutaImagen)
            }
        }
        res.json({ mensaje: 'Diseño eliminado', diseno })
    } catch (error) {
        next(new AppError(error.message, 500))
    }
})

exports.reservarCita = wrapAsync(async (req, res, next) => {
  try {
    const { id } = req.params;
    const diseno = await disenoModel.editarDisenoPorId(id, {
      disponible: false,
      yaRealizado: true
    });

    if (!diseno) {
      return res.status(404).json({ error: 'Diseño no encontrado' });
    }

    res.json({
      mensaje: 'Cita reservada',
      redirectUrl: `/citas/nueva?foto=${encodeURIComponent(diseno.foto)}`
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
