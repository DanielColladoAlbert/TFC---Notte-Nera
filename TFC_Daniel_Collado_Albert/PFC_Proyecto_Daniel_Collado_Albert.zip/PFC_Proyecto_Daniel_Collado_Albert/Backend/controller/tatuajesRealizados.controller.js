const tatuajeModel = require("../models/tatuajesRealizados.model");
const { wrapAsync } = require("../utils/functions");
const AppError = require("../utils/AppError");
const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");

const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

const eliminarImagenAnterior = (fotoPath) => {
  const ruta = path.join(__dirname, "..", "public", fotoPath);
  if (fs.existsSync(ruta)) {
    fs.unlinkSync(ruta);
  }
};

const buscarTatuajePorId = async (id) => {
  if (!isValidObjectId(id)) throw new AppError("ID inválido", 400);
  const tatuaje = await tatuajeModel.findById(id);
  if (!tatuaje) throw new AppError("Tatuaje no encontrado", 404);
  return tatuaje;
};

exports.obtenerTatuaje = wrapAsync(async (req, res, next) => {
  const { id } = req.params;
  const tatuaje = await buscarTatuajePorId(id);
  res.status(200).json({ success: true, data: tatuaje });
});

exports.verTodosTatuajes = wrapAsync(async (req, res, next) => {
  const tatuajes = await tatuajeModel.buscarTodo();
  if (!tatuajes || tatuajes.length === 0) {
    throw new AppError("No se encontraron tatuajes", 404);
  }
  res.json({ success: true, data: tatuajes });
});

function validarCamposTatuaje({ foto, titulo, descripcion, nombreCliente, fecha }) {
  if (!foto || typeof foto !== "string" || !foto.trim()) {
    throw new AppError("La foto es obligatoria y debe ser una cadena", 400);
  }
  if (!titulo || typeof titulo !== "string" || !titulo.trim()) {
    throw new AppError("El título es obligatorio y debe ser una cadena", 400);
  }
  if (!descripcion || typeof descripcion !== "string" || !descripcion.trim()) {
    throw new AppError("La descripción es obligatoria y debe ser una cadena", 400);
  }
  if (!nombreCliente || typeof nombreCliente !== "string" || !nombreCliente.trim()) {
    throw new AppError("El nombre del cliente es obligatorio y debe ser una cadena", 400);
  }
  if (fecha && isNaN(new Date(fecha))) {
    throw new AppError("La fecha ingresada no es válida", 400);
  }
}

exports.editarTatuaje = wrapAsync(async (req, res, next) => {
  const { id } = req.params;
  const { foto, titulo, descripcion, tamano, tipo, fecha, nombreCliente } = req.body;
  const nuevaFoto = req.file ? "/uploads/" + req.file.filename : foto;

  const tatuaje = await buscarTatuajePorId(id);
  if (!tatuaje) throw new AppError("Tatuaje no encontrado para editar", 404);

  try {
    validarCamposTatuaje({ foto: nuevaFoto, titulo, descripcion, nombreCliente, fecha });
  } catch (err) {
    if (req.file && nuevaFoto) {
      const newImagePath = path.join(__dirname, "..", "public", nuevaFoto);
      if (fs.existsSync(newImagePath)) fs.unlinkSync(newImagePath);
    }
    return next(err);
  }

  if (req.file && tatuaje.foto) eliminarImagenAnterior(tatuaje.foto);

  const fechaSeleccionada = fecha ? new Date(fecha) : new Date();
  const fechaActual = new Date();
  fechaSeleccionada.setHours(0, 0, 0, 0);
  fechaActual.setHours(0, 0, 0, 0);

  if (fechaSeleccionada > fechaActual) {
    if (req.file && nuevaFoto) {
      const newImagePath = path.join(__dirname, "..", "public", nuevaFoto);
      if (fs.existsSync(newImagePath)) fs.unlinkSync(newImagePath);
    }
    return res.status(400).json({
      success: false,
      message: "La fecha de realización no puede ser superior a la fecha actual.",
    });
  }

  const updatedData = {
    foto: nuevaFoto || undefined,
    titulo,
    descripcion,
    tamano,
    tipo,
    fecha: fechaSeleccionada,
    nombreCliente,
  };

  const actualizado = await tatuajeModel.editarTatuajeById(id, updatedData);
  if (!actualizado) throw new AppError("No se pudo actualizar el tatuaje", 500);

  res.json({ success: true, data: actualizado, message: "Tatuaje actualizado" });
});

exports.eliminarTatuaje = wrapAsync(async (req, res, next) => {
  const tatuaje = await buscarTatuajePorId(req.params.id);
  if (!tatuaje) throw new AppError("Tatuaje no encontrado para eliminar", 404);

  if (tatuaje.foto) eliminarImagenAnterior(tatuaje.foto);

  const eliminado = await tatuajeModel.findByIdAndDelete(tatuaje._id);
  if (!eliminado) throw new AppError("No se pudo eliminar el tatuaje", 500);

  res.json({ success: true, message: "Tatuaje eliminado correctamente" });
});

exports.crearTatuaje = wrapAsync(async (req, res, next) => {
  const { titulo, descripcion, tamano, tipo, fecha, nombreCliente } = req.body;
  const foto = req.file ? "/uploads/" + req.file.filename : undefined;

  try {
    validarCamposTatuaje({ foto, titulo, descripcion, nombreCliente, fecha });
  } catch (err) {
    if (req.file && foto) {
      const newImagePath = path.join(__dirname, "..", "public", foto);
      if (fs.existsSync(newImagePath)) fs.unlinkSync(newImagePath);
    }
    return next(err);
  }

  const fechaSeleccionada = fecha ? new Date(fecha) : new Date();
  const fechaActual = new Date();
  fechaSeleccionada.setHours(0, 0, 0, 0);
  fechaActual.setHours(0, 0, 0, 0);

  if (fechaSeleccionada > fechaActual) {
    if (req.file && foto) {
      const newImagePath = path.join(__dirname, "..", "public", foto);
      if (fs.existsSync(newImagePath)) fs.unlinkSync(newImagePath);
    }
    return res.status(400).json({
      success: false,
      message: "La fecha de realización no puede ser superior a la fecha actual.",
    });
  }

  const tatuajeData = {
    titulo,
    descripcion,
    tamano,
    tipo,
    foto,
    fecha: fechaSeleccionada,
    nombreCliente
  };

  const creado = await tatuajeModel.crearTatuaje(tatuajeData);
  if (!creado) throw new AppError("No se pudo crear el tatuaje", 500);

  res.status(201).json({
    success: true,
    data: creado,
    message: "Tatuaje creado con éxito",
  });
});

exports.editarTatuaje = wrapAsync(async (req, res, next) => {
  const { id } = req.params;
  const { foto, titulo, descripcion, tamano, tipo, fecha, nombreCliente } = req.body;
  const nuevaFoto = req.file ? "/uploads/" + req.file.filename : foto;

  const tatuaje = await buscarTatuajePorId(id);
  if (!tatuaje) throw new AppError("Tatuaje no encontrado para editar", 404);

  if (req.file && tatuaje.foto) eliminarImagenAnterior(tatuaje.foto);

  const fechaSeleccionada = fecha ? new Date(fecha) : new Date();
  const fechaActual = new Date();
  fechaSeleccionada.setHours(0, 0, 0, 0);
  fechaActual.setHours(0, 0, 0, 0);

  if (fechaSeleccionada > fechaActual) {
    return res.status(400).json({
      success: false,
      message: "La fecha de realización no puede ser superior a la fecha actual.",
    });
  }

  const updatedData = {
    foto: nuevaFoto || undefined,
    titulo,
    descripcion,
    tamano,
    tipo,
    fecha: fechaSeleccionada,
    nombreCliente,
  };

  const actualizado = await tatuajeModel.editarTatuajeById(id, updatedData);
  if (!actualizado) throw new AppError("No se pudo actualizar el tatuaje", 500);

  res.json({ success: true, data: actualizado, message: "Tatuaje actualizado" });
});

exports.eliminarTatuaje = wrapAsync(async (req, res, next) => {
  const tatuaje = await buscarTatuajePorId(req.params.id);
  if (tatuaje.foto) eliminarImagenAnterior(tatuaje.foto);

  await tatuajeModel.findByIdAndDelete(tatuaje._id);
  res.json({ success: true, message: "Tatuaje eliminado correctamente" });
});

exports.crearTatuaje = wrapAsync(async (req, res, next) => {
  const { titulo, descripcion, tamano, tipo, fecha, nombreCliente } = req.body;

  if (!titulo || !descripcion) {
    return res.status(400).json({
      success: false,
      message: "Debe proporcionar un título y una descripción para el tatuaje",
    });
  }

  if (!nombreCliente) {
    return res.status(400).json({
      success: false,
      message: "Debe proporcionar el nombre del cliente",
    });
  }

  if (!req.file) {
    return res.status(400).json({
      success: false,
      message: "Debe proporcionar una foto para el tatuaje",
    });
  }

  const fechaSeleccionada = fecha ? new Date(fecha) : new Date();
  const fechaActual = new Date();
  fechaSeleccionada.setHours(0, 0, 0, 0);
  fechaActual.setHours(0, 0, 0, 0);

  if (fechaSeleccionada > fechaActual) {
    return res.status(400).json({
      success: false,
      message: "La fecha de realización no puede ser superior a la fecha actual.",
    });
  }

  const foto = "/uploads/" + req.file.filename;

  const tatuajeData = {
    titulo,
    descripcion,
    tamano,
    tipo,
    foto,
    fecha: fechaSeleccionada,
    nombreCliente
  };

  const creado = await tatuajeModel.crearTatuaje(tatuajeData);
  if (!creado) throw new AppError("No se pudo crear el tatuaje", 500);

  res.status(201).json({
    success: true,
    data: creado,
    message: "Tatuaje creado con éxito",
  });
});