require("dotenv").config();
const userModel = require("../models/usuario.model");
const mongoose = require('mongoose');

// CONFIGURACIÓN WRAP
const { wrapAsync } = require("../utils/functions");
const AppError = require("../utils/AppError");

// CONFIGURACIÓN JWT
const bcrypt = require("../utils/bcrypt");
const jwtMW = require("../middlewares/jwt.mw");

// CONFIGURACIÓN FS Y PATH PARA ELIMINAR ARCHIVOS
const fs = require("fs");
const path = require("path");

// CONFIGURACIÓN MULTER
const multer = require('multer');

exports.login = wrapAsync(async (req, res, next) => {
    const { nombreUsuario, contrasena } = req.body;
  
    if (!nombreUsuario || !contrasena) {
      return next(new AppError("Usuario y/o contraseña son requeridos", 400));
    }
  
    const userFound = await userModel.buscarPorNombreUsuario(nombreUsuario);
  
    if (!userFound) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }
  
    if (!userFound.contrasena) {
      return next(new AppError("Error en la base de datos: contraseña no encontrada", 500));
    }
  
    const validado = await bcrypt.compareLogin(contrasena, userFound.contrasena);
  
    if (!validado) {
      return res.status(401).json({ message: "Usuario y/o contraseña incorrectos" });
    }
  
    const jwtToken = jwtMW.createJWT(userFound);
    const isBlocked = !!userFound.bloqueado;
  
    const userLogued = {
      data: {
        _id: userFound._id,
        username: userFound.nombreUsuario,
        profile: userFound.perfil,
        isBlocked,
      },
      token: jwtToken,
    };
  
    req.session.userLogued = userLogued;
    res.locals.username = userFound.nombreUsuario;
    res.locals.profile = userFound.perfil;
    res.locals.isBlocked = isBlocked;
  
    res.status(200).json({
      status: true,
      message: isBlocked ? "Usuario bloqueado" : "Inicio de sesión exitoso",
      token: jwtToken,
      data: userLogued.data,
      motivoBloqueo: userFound.motivoBloqueo || null,
      fechaBloqueo: userFound.fechaBloqueo || null,
    });
  });

exports.logout = (req, res, next) => {
    const jwtDestroyed = jwtMW.destroyJWT(req);
    if (jwtDestroyed) {
        req.session.destroy((err) => {
            if (err) {
                return next(new AppError('Error al destruir la sesión', 500));
            }
            res.status(200).json({ message: "Sesión cerrada correctamente" });
        });
    } else {
        next(new AppError('Error al eliminar token o sesión inexistente', 500));
    }
};

exports.verRegistro = wrapAsync(async function(req, res, next) {
    res.status(200).json({ message: "Página de registro" });
});

const usernameRegex = /^[\w@!#$%^&*º()[\]{}\-+=~.]{5,}$/;
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[-_!?@]).{8,}$/;
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const nameRegex = /^[\p{L} \-'`´]+$/u;
const surnameRegex = /^[\p{L} \-'`´]+$/u;

const normalizarNombreUsuario = (nombre) => {
  return nombre
    .toLowerCase()
    .normalize("NFD")
    .replace(/[^\p{L}\\p{N}]/gu, "");
};

const esNombreUsuarioRestringido = (nombre) => {
  return normalizarNombreUsuario(nombre) === "usuarioeliminado";
};

function validarCamposUsuario({ nombreUsuario, contrasena, nombre, apellidos, correo }) {
  if (!nombreUsuario || typeof nombreUsuario !== "string" || nombreUsuario.length < 5) {
    throw new AppError("El nombre de usuario es obligatorio y debe tener al menos 5 caracteres.", 400);
  }
  if (!contrasena || typeof contrasena !== "string" || contrasena.length < 8) {
    throw new AppError("La contraseña es obligatoria y debe tener al menos 8 caracteres.", 400);
  }
  if (!nombre || typeof nombre !== "string" || !nombre.trim()) {
    throw new AppError("El nombre es obligatorio.", 400);
  }
  if (!apellidos || typeof apellidos !== "string" || !apellidos.trim()) {
    throw new AppError("Los apellidos son obligatorios.", 400);
  }
  if (!correo || typeof correo !== "string" || !correo.trim()) {
    throw new AppError("El correo electrónico es obligatorio.", 400);
  }
}

exports.registro = wrapAsync(async (req, res, next) => {
  const { nombreUsuario, contrasena, correo, nombre, apellidos } = req.body;

  try {
    validarCamposUsuario({ nombreUsuario, contrasena, nombre, apellidos, correo });
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(err);
  }

    // Validaciones
    if (!usernameRegex.test(nombreUsuario)) {
        return res.status(400).json({ errorMessage: "El nombre de usuario debe tener al menos 5 caracteres." });
    }

    if (!passwordRegex.test(contrasena)) {
        return res.status(400).json({ errorMessage: "La contraseña debe contener minio 8 caracteres con Mayúscula, número y símbolo." });
    }

    if (!emailRegex.test(correo)) {
        return res.status(400).json({ errorMessage: "El formato del correo es incorrecto." });
    }

    if (!nameRegex.test(nombre)) {
        return res.status(400).json({ errorMessage: "El nombre no debe contener ni numeros ni simbolos inadecuados." });
    }

    if (!surnameRegex.test(apellidos)) {
        return res.status(400).json({ errorMessage: "Los apellidos no deben contener ni numeros ni simbolos inadecuados." });
    }

    if (!usernameRegex.test(nombreUsuario)) {
        return res.status(400).json({ errorMessage: "El nombre de usuario debe tener al menos 5 caracteres." });
    }

    if (esNombreUsuarioRestringido(nombreUsuario)) {
        return res.status(400).json({ errorMessage: "El nombre de usuario está restringido. Por favor, elige otro." });
    }

    const userExist = await userModel.findOne({ nombreUsuario });
    if (userExist) {
        if (req.file) {
            fs.unlinkSync(req.file.path);
        }
        return res.status(400).json({ errorMessage: "El nombre de usuario ya está en uso." });
    }

    const emailExist = await userModel.findOne({ correo });
    if (emailExist) {
        if (req.file) {
            fs.unlinkSync(req.file.path);
        }
        return res.status(400).json({ errorMessage: "El correo electrónico ya está registrado." });
    }

    // Asignar la ruta de la foto, usando una por defecto si no se proporciona ninguna
    const foto = req.file ? "/uploads/" + req.file.filename : "/Img/foto_usuario_blanco.png";
    req.body.foto = foto; 

    req.body.contrasena = await bcrypt.hashPassword(contrasena);

    // Crea el usuario
    const userCreated = await userModel.crearUsuario(req.body);
    const jwtToken = jwtMW.createJWT(req, res, next, userCreated);
    req.session.userLogued = { data: userCreated, token: jwtToken };
    res.status(201).json({ message: "Usuario registrado con éxito", user: userCreated, token: jwtToken });
});

exports.verUsuarioPorId = wrapAsync(async function(req, res, next) {
    const { id } = req.params;

    // Verifica si el id es undefined o no es un ObjectId válido
    if (!id || !mongoose.Types.ObjectId.isValid(id)) {
        return next(new AppError("ID de usuario no válido.", 400));
    }

    try {
        const user = await userModel.buscarUsuarioPorId(id);

        if (!user) {
            return res.status(404).json({ status: false, message: "Usuario no encontrado" });
        }

        res.json({ status: true, user });
    } catch (err) {
        next(new AppError(err.message, 500));
    }
});

exports.verEditar = wrapAsync(async function(req, res, next) {
    const userId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return next(new AppError("ID de usuario no válido", 400));
    }
    try {
        const user = await userModel.findById(userId);
        if (!user) {
            return next(new AppError("Usuario no encontrado", 404));
        }

        const loguedUser = req.session.userLogued ? req.session.userLogued.data : null;

        res.status(200).json({ user, loguedUser });
    } catch (err) {
        next(new AppError(err.message, 500));
    }
});

exports.editarUsuario = wrapAsync(async function(req, res, next) {
  const { id } = req.params;
   const { nombreUsuario, nombre, apellidos, correo, contrasena } = req.body;

  try {
    if (contrasena) {
      validarCamposUsuario({ nombreUsuario, contrasena, nombre, apellidos, correo });
    } else {
      validarCamposUsuario({ nombreUsuario, contrasena: "contrasenaFicticia", nombre, apellidos, correo });
    }
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(err);
  }

  const user = await userModel.findById(id);
  if (!user) return next(new AppError("Usuario no encontrado", 404));

  if (!usernameRegex.test(nombreUsuario)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(new AppError("El nombre de usuario debe tener al menos 5 caracteres.", 400));
  }

  if (esNombreUsuarioRestringido(nombreUsuario)) {
        return res.status(400).json({ errorMessage: "El nombre de usuario está restringido. Por favor, elige otro." });
    }


  if (!emailRegex.test(correo)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(new AppError("El correo electrónico no es válido.", 400));
  }

  if (!nameRegex.test(nombre)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(new AppError("El nombre no debe contener números ni símbolos inadecuados.", 400));
  }

  if (!surnameRegex.test(apellidos)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return next(new AppError("Los apellidos no deben contener números ni símbolos inadecuados.", 400));
  }

  if (nombreUsuario !== user.nombreUsuario) {
    const userExist = await userModel.findOne({ nombreUsuario });
    if (userExist) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({ errorMessage: "El nombre de usuario ya está en uso." });
    }
  }

  if (correo !== user.correo) {
    const emailExist = await userModel.findOne({ correo });
    if (emailExist) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({ errorMessage: "El correo electrónico ya está registrado." });
    }
  }

  if (contrasena || repeatPassword || oldPassword) {
    if (!oldPassword) return next(new AppError("Debe proporcionar la contraseña actual para cambiarla.", 400));
    if (!contrasena || !repeatPassword) return next(new AppError("Debe ingresar y repetir la nueva contraseña.", 400));
    if (contrasena !== repeatPassword) return next(new AppError("Las nuevas contraseñas no coinciden.", 400));
    if (!passwordRegex.test(contrasena)) {
      return next(new AppError("La nueva contraseña debe tener al menos 8 caracteres, incluir una mayúscula, un número y un símbolo.", 400));
    }

    const passwordMatch = await bcrypt.compareLogin(oldPassword, user.contrasena);
    if (!passwordMatch) return next(new AppError("La contraseña actual es incorrecta.", 401));
  }

  if (req.file && user.foto) {
    const oldImagePath = path.join(__dirname, 'public', user.foto);
    if (fs.existsSync(oldImagePath)) fs.unlinkSync(oldImagePath);
  }

  const foto = req.file ? "/uploads/" + req.file.filename : user.foto;

  const updatedData = {
    nombreUsuario,
    nombre,
    apellidos,
    correo,
    perfil,
    foto: foto || undefined
  };

  if (contrasena) {
    updatedData.contrasena = await bcrypt.hashPassword(contrasena);
  }

  try {
    const datosActualizados = await userModel.editarUsuarioPorId(id, updatedData);

    const sessionId = req.session.userLogued?.data?._id || req.session.userLogued?.data?.id;
    if (sessionId && sessionId.toString() === id) {
      req.session.userLogued.data = { ...req.session.userLogued.data, ...updatedData };
    }

    res.status(200).json({ message: "Usuario actualizado correctamente", user: datosActualizados });
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path);
    next(new AppError(err, 400));
  }
});

exports.contarAdministradores = async (req, res, next) => {
    try {
        const adminCount = await userModel.countDocuments({ 
            $or: [
                { perfil: 'ADMIN' },
                { perfil: 'admin' }
            ]
        });
        
        return res.status(200).json({
            success: true,
            count: adminCount
        });
    } catch (err) {
        return res.status(500).json({
            success: false,
            message: "Error al contar administradores"
        });
    }
};

exports.eliminarUsuario = async (req, res, next) => {
    try {
        const { id } = req.params;

        // Validar si el id es un ObjectId válido antes de eliminar
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ success: false, message: "ID no válido" });
        }

        // Buscar al usuario para saber el nombre de la foto y verificar su perfil
        const usuario = await userModel.findById(id);
        if (!usuario) {
            return res.status(404).json({ success: false, message: "Usuario no encontrado" });
        }

        // Verificar si es administrador y si es el último
        if (usuario.perfil && (usuario.perfil.toLowerCase() === 'admin' || usuario.perfil === 'ADMIN')) {
            console.log("👑 Usuario a eliminar es admin, verificando si es el último...");
            const adminCount = await userModel.countDocuments({ 
                $or: [
                    { perfil: 'ADMIN' },
                    { perfil: 'admin' }
                ]
            });
            
            if (adminCount <= 1) {
              
                return res.status(400).json({
                    success: false,
                    message: "No se puede eliminar la cuenta. Eres el último administrador del sistema."
                });
            }
        }

        // Eliminar la foto del sistema de archivos si existe y no es foto_usuario_blanco.jpg
        if (usuario.foto) {
            const nombreArchivo = path.basename(usuario.foto);

            if (nombreArchivo !== 'foto_usuario_blanco.png') {
                const rutaFoto = path.join(__dirname, "..", "public", "uploads", nombreArchivo);
                
                fs.unlink(rutaFoto, (err) => {
                    if (err) {
                        console.warn("No se pudo eliminar la foto de perfil:", err.message);
                    }
                });
            }
        }

        // Eliminar el usuario de la base de datos
        await userModel.eliminarUsuarioById(id);

        return res.status(200).json({ success: true, message: "Usuario eliminado correctamente" });
    } catch (err) {

        return res.status(500).json({ success: false, message: "Error eliminando usuario" });
    }
};

exports.listaUsuarios = wrapAsync(async function(req, res, next) {
    try {
        const search = req.query.search || '';
        const query = search ? { nombreUsuario: new RegExp(search, 'i') } : {};
        const usuarios = await userModel.find(query);

        res.status(200).json({ usuarios, search });
    } catch (err) {
        next(new AppError(err.message, 500));
    }
});

exports.verBloquear = wrapAsync(async function(req, res, next) {
    const userId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return next(new AppError("ID de usuario no válido", 400));
    }
    try {
        const user = await userModel.findById(userId);
        if (!user) {
            return next(new AppError("Usuario no encontrado", 404));
        }
        res.status(200).json({ user });
    } catch (err) {
        next(new AppError(err.message, 500));
    }
});

exports.bloquearUsuario = wrapAsync(async function(req, res, next) {
    try {
        const { motivoBloqueo } = req.body;
        const usuarioId = req.params.id;
        
        // Obtener usuario del token JWT en Authorization header
        let usuarioActualId;
        
        if (req.user && req.user.id) {
            usuarioActualId = req.user.id;
        } else if (req.user && req.user._id) {
            usuarioActualId = req.user._id;
        } else if (req.authUser && req.authUser._id) {
            usuarioActualId = req.authUser._id;
        } else if (req.headers.authorization) {

            try {
                const token = req.headers.authorization.replace('Bearer ', '');
                const jwt = require('jsonwebtoken');
                const decoded = jwt.decode(token); 
                usuarioActualId = decoded.id;
                console.log('Usuario decodificado del JWT:', decoded);
            } catch (e) {
                console.log('Error decodificando JWT:', e);
            }
        }
        
        if (!usuarioActualId) {
            return next(new AppError('Usuario no autenticado correctamente', 401));
        }
        
        console.log('IDs para comparar:', {
            usuarioId: usuarioId.toString(),
            usuarioActualId: usuarioActualId.toString()
        });
        
        // Verificar que el usuario no intente bloquearse a sí mismo
        if (usuarioId.toString() === usuarioActualId.toString()) {
            return next(new AppError('No puedes bloquear tu propia cuenta', 403));
        }
        
        const usuario = await userModel.findById(usuarioId);
        if (!usuario) {
            return next(new AppError('Usuario no encontrado', 404));
        }
        
        console.log('Datos para bloqueo:', {
            usuarioId,
            usuarioActualId,
            estadoActual: usuario.bloqueado,
            fechaBloqueo: usuario.fechaBloqueo,
            motivoBloqueo: usuario.motivoBloqueo
        });
        
        usuario.bloqueado = !usuario.bloqueado;
        if (usuario.bloqueado) {
            usuario.motivoBloqueo = motivoBloqueo;
            usuario.fechaBloqueo = new Date();
        } else {
            usuario.motivoBloqueo = null;
            usuario.fechaBloqueo = null;
        }
        
        await usuario.save();
        
        res.status(200).json({ 
            message: "Usuario bloqueado/desbloqueado correctamente",
            usuario: {
                id: usuario._id,
                nombreUsuario: usuario.nombreUsuario,
                bloqueado: usuario.bloqueado,
                motivoBloqueo: usuario.motivoBloqueo,
                fechaBloqueo: usuario.fechaBloqueo
            }
        });
    } catch (error) {

        next(new AppError(`Error al bloquear/desbloquear el usuario: ${error.message}`, 500));
    }
});

exports.cambiarPerfil = wrapAsync(async function(req, res, next) {
    const userId = req.params.id;
    const { perfil } = req.body;
    
    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return next(new AppError("ID de usuario no válido", 400));
    }
    
    // Verificar si el usuario está intentando cambiar su propio perfil
    if (req.user?._id.toString() === userId) {
        return res.status(403).json({
            success: false,
            message: "No puedes cambiar tu propio perfil"
        });
    }
    
    try {
        const user = await userModel.findById(userId);
        if (!user) return next(new AppError("Usuario no encontrado", 404));
        
        // Verificar que no sea el último administrador
        if (user.perfil === 'ADMIN' && perfil !== 'ADMIN') {
            const adminCount = await userModel.countDocuments({ perfil: 'ADMIN' });
            if (adminCount <= 1) {
                return res.status(403).json({
                    success: false,
                    message: "No se puede cambiar el perfil del único administrador"
                });
            }
        }
        
        user.perfil = perfil;
        await user.save();
        
        res.json({
            success: true,
            message: 'Perfil actualizado correctamente'
        });
        
    } catch (err) {

        next(new AppError(err.message, 500));
    }
});

exports.validarContrasena = wrapAsync(async (req, res, next) => {
  const { id, oldPassword } = req.body;

  if (!id || !oldPassword) {
    return res.status(400).json({ valid: false, message: "Datos incompletos" });
  }

  try {
    const user = await userModel.findById(id);
    if (!user) return res.status(404).json({ valid: false, message: "Usuario no encontrado" });

    const isValid = await bcrypt.compareLogin(oldPassword, user.contrasena);
    return res.json({ valid: isValid });
  } catch (error) {

    return res.status(500).json({ valid: false, message: "Error interno del servidor" });
  }
});
