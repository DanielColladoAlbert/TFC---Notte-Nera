const resenaModel = require("../models/resenas.model")
const User = require('../models/usuario.model') 
const { wrapAsync } = require("../utils/functions")
const AppError = require("../utils/AppError")
const mongoose = require('mongoose')

exports.verTodasResenas = wrapAsync(async function (req, res, next) {
    try {
        const user = req.session.userLogued ? req.session.userLogued.data : null;
        const estado = req.query.estado || 'todas';
        const ordenarPor = req.query.ordenarPor || '';

        let filtro = {};
        if (user && user.perfil === 'ADMIN') {
            if (estado !== 'todas') {
                filtro.aprobado = estado;
            }
        } else {
            filtro.aprobado = 'aprobado';
            if (user) {
                filtro.$or = [
                    { clienteId: user._id },
                    { aprobado: 'aprobado' }
                ];
            }
        }

        let orden = {};
        if (ordenarPor === "recientes") {
            orden = { fecha: -1 };
        } else if (ordenarPor === "antiguas") {
            orden = { fecha: 1 };
        } else if (ordenarPor === "mejorValorados") {
            orden = { estrellas: -1 };
        } else if (ordenarPor === "peorValorados") {
            orden = { estrellas: 1 };
        } else {
            orden = { _id: -1 }; // Orden predeterminado
        }

        const resenas = await resenaModel.find(filtro).populate('clienteId').sort(orden);
        res.json({ resenas, user, estado, ordenarPor });
    } catch (err) {
        console.error('Error en verTodasResenas:', err);
        next(new AppError(err.message, 500));
    }
});

function validarCamposResena({resena, estrellas }) {
   
    if (!resena || typeof resena !== "string" || !resena.trim()) {
        throw new AppError("La reseña es obligatoria y debe ser texto", 400);
    }
    if (
        estrellas === undefined ||
        isNaN(Number(estrellas)) ||
        Number(estrellas) < 1 ||
        Number(estrellas) > 5
    ) {
        throw new AppError("Las estrellas son obligatorias y deben ser un número entre 1 y 5", 400);
    }
}

exports.verEditarResena = wrapAsync(async function(req, res, next) {
    const resenaId = req.params.id
    const user = req.session.userLogued ? req.session.userLogued : null

    if (!mongoose.Types.ObjectId.isValid(resenaId)) {
        return next(new AppError("ID de reseña no válido", 400))
    }
    try {
        const resena = await resenaModel.buscarResenaPorId(resenaId)
        if (!resena) {
            return next(new AppError("Reseña no encontrada", 404))
        }
        res.json({ resena, user })
    } catch (err) {
        next(new AppError(err.message, 500))
    }
})

exports.editarResena = wrapAsync(async function(req, res, next) {
    const { id } = req.params;
    const { nombreUsuario, fotoPerfil, resena, estrellas, aprobado } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
        return next(new AppError("ID de reseña no válido", 400));
    }

    let user = req.session.userLogued?.data || null;

    if (!user && req.headers.authorization?.startsWith("Bearer ")) {
        const token = req.headers.authorization.split(" ")[1];
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            user = { id: decoded.id };
        } catch (err) {
            return next(new AppError("Token inválido", 401));
        }
    }

    try {
        const resenaExistente = await resenaModel.buscarResenaPorId(id);
        if (!resenaExistente) {
            return next(new AppError("Reseña no encontrada", 404));
        }

        if (!user || !user.id) {
            return next(new AppError("No hay sesión activa o token inválido", 401));
        }

        const esAutor = resenaExistente.clienteId.toString() === user.id.toString();

        const soloAnonimizar = !user && fotoPerfil === "" && !nombreUsuario && !resena && !estrellas;

        if (!esAutor && !soloAnonimizar) {
            return next(new AppError("No tienes permisos para editar esta reseña", 403));
        }

        if (!soloAnonimizar) {
            try {
                validarCamposResena({ resena, estrellas });
            } catch (err) {
                return next(err);
            }
        }

        const nuevaFotoPerfil = req.file ? "/uploads/" + req.file.filename : fotoPerfil;
        const updatedData = {
            nombreUsuario,
            fotoPerfil: nuevaFotoPerfil || undefined,
            resena,
            estrellas,
            aprobado
        };

        await resenaModel.editarResenaById(id, updatedData);
        res.status(200).json({ message: "Reseña actualizada correctamente", resena: updatedData });
    } catch (err) {
        next(new AppError(err.message, 400));
    }
});

exports.anonimizarResenasPorCliente = wrapAsync(async (req, res, next) => {
  const { clienteId } = req.params;
  
  await resenaModel.updateMany(
    { clienteId },
    {
      $set: {
        fotoPerfil: "",
        nombreUsuario: "Usuario eliminado",
      },
    }
  );

  res.status(200).json({ message: "Reseñas anonimizadas" });
});


exports.eliminarResena = wrapAsync(async function(req, res, next) {
    const resenaId = req.params.id
    
    const usuarioActual = req.session.userLogued.data; 

    if (!mongoose.Types.ObjectId.isValid(resenaId)) {
        return next(new AppError("ID de reseña no válido", 400))
    }

    try {
        const resena = await resenaModel.buscarResenaPorId(resenaId)
        if (!resena) {
            return next(new AppError("Reseña no encontrada", 404))
        }

        const esAdmin = usuarioActual.perfil === "ADMIN"; 
        const esAutor = resena.clienteId.toString() === usuarioActual.id.toString();
        
        if (!esAdmin && !esAutor) {
            return next(new AppError("No tienes permisos para eliminar esta reseña", 403))
        }

        await resenaModel.eliminarResenaPorId(resenaId)
        res.status(200).json({ message: "Reseña eliminada correctamente", resenaId })
    } catch (err) {
        next(new AppError(err.message, 500))
    }
})

exports.crearResena = wrapAsync(async function(req, res, next) {
    try {
        const user = req.session.userLogued ? req.session.userLogued.data : null;
        if (!user) {
            return next(new AppError("Usuario no autenticado", 401));
        }

        const usuario = await User.findById(user.id);
        if (!usuario) {
            return next(new AppError("Usuario no encontrado", 404));
        }

        const nombreUsuario = usuario.nombreUsuario;
        const estrellas = parseInt(req.body.estrellas, 10);
        const resena = req.body.resena;

        try {
            validarCamposResena({ resena, estrellas });
        } catch (err) {
            return next(err);
        }

        const fotoPerfilPath = usuario.foto && usuario.foto.startsWith("/uploads/")
            ? usuario.foto
            : `/Img/foto_usuario/default.jpg`;

        const resenaData = {
            nombreUsuario,
            clienteId: usuario._id,
            fotoPerfil: fotoPerfilPath,
            resena,
            estrellas,
            aprobado: "por aprobar",
            fecha: new Date()
        };

        const nuevaResena = await resenaModel.crearResena(resenaData);
        res.status(201).json({ message: "Reseña creada", resena: nuevaResena });
    } catch (err) {
        next(new AppError(err.message || 'Error al crear la reseña', 500));
    }
});

exports.obtenerEstadisticas = wrapAsync(async function(req, res, next) {
    try {
        const total = await resenaModel.countDocuments();
        const media = await resenaModel.aggregate([
            { $group: { _id: null, promedio: { $avg: "$estrellas" } } }
        ]);
        const estrellas = await resenaModel.aggregate([
            { $group: { _id: "$estrellas", count: { $sum: 1 } } }
        ]);

        const estrellasMap = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
        estrellas.forEach(curr => {
            estrellasMap[curr._id] = curr.count;
        });

        res.json({
            total,
            media: media[0] ? media[0].promedio.toFixed(2) : 0,
            estrellas: estrellasMap
        });
    } catch (error) {
        next(new AppError(error.message, 500));
    }
});

exports.actualizarEstadoResena = wrapAsync(async function(req, res, next) {
    const { id } = req.params
    const { estado } = req.body

    if (!mongoose.Types.ObjectId.isValid(id)) {
        return next(new AppError("ID de reseña no válido", 400))
    }

    try {
        await resenaModel.editarResenaById(id, { aprobado: estado })
        res.status(200).json({ message: "Estado actualizado" })
    } catch (err) {
        next(new AppError(err.message, 500))
    }
})