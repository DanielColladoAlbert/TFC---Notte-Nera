const citaModel = require("../models/citas.model");
const { wrapAsync } = require("../utils/functions");
const AppError = require("../utils/AppError");
const mongoose = require('mongoose');
const fs = require("fs");
const path = require("path");

const obtenerUsuario = (req) => {
    return req.user || req.session?.userLogued?.data || req.session?.userLogued;
};

exports.verTodasCitas = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);

    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }

    // Obtener citas según el usuario
    const citas = await exports.obtenerCitasFiltradas(user);

    res.status(200).json({ 
        success: true, 
        data: { 
            citas,
            user: { 
                data: { 
                    data: user
                }
            },
            totalCitas: citas.length 
        } 
    });
});

exports.verDetalles = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);
    
    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }
    
    try {
        const cita = await verificarPermisossCita(req.params.id, user, next);
        res.status(200).json({ success: true, data: cita });
    } catch (error) {
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ 
                success: false, 
                message: error.message 
            });
        }
        next(error);
    }
});

function validarCamposCita({ nombreCompletoCliente, descripcion, tamano, fecha, precio }) {
    if (!nombreCompletoCliente || typeof nombreCompletoCliente !== "string" || !nombreCompletoCliente.trim()) {
        throw new AppError("El nombre completo del cliente es obligatorio y debe ser un texto", 400);
    }
    if (!descripcion || typeof descripcion !== "string" || !descripcion.trim()) {
        throw new AppError("La descripción es obligatoria y debe ser un texto", 400);
    }
    if (!tamano || typeof tamano !== "string" || !tamano.trim()) {
        throw new AppError("El tamaño es obligatorio y debe ser un texto", 400);
    }
    if (!fecha || isNaN(new Date(fecha))) {
        throw new AppError("La fecha ingresada no es válida", 400);
    }

    if (!precio|| precio < 0 || isNaN(Number(precio))) {
        throw new AppError("El precio debe ser un número positivo", 400);
    }
}

exports.verEditarCita = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);

    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }

    try {
        const cita = await verificarPermisossCita(req.params.id, user, next);
        res.status(200).json({ 
            success: true, 
            data: { 
                cita, 
                user: { 
                    data: { 
                        data: user 
                    } 
                } 
            } 
        });
    } catch (error) {
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ 
                success: false, 
                message: error.message 
            });
        }
        next(error);
    }
});

exports.editarCita = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);

    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }
    
    try {
        const cita = await verificarPermisossCita(req.params.id, user, next);
        
        let {
            nombreCompletoCliente,
            foto,
            descripcion,
            tamano,
            fecha,
            estado,
            precio,
            tiempoEstimado,
            conversacion,
            motivoCancelacion
        } = req.body;

        // Validar campos requeridos y tipos
        try {
            validarCamposCita({ nombreCompletoCliente, descripcion, tamano, fecha, precio });
        } catch (err) {
            return next(err);
        }
        
        if (typeof conversacion === "string") {
            try {
                conversacion = JSON.parse(conversacion);
            } catch {
                conversacion = [];
            }
        }

        if (!Array.isArray(conversacion)) {
            conversacion = [];
        } else {
            conversacion = conversacion.filter(msg =>
                msg && typeof msg === 'object' && msg.text && msg.userId
            );
        }

        // Convertir precio a número si es string
        if (typeof precio === "string" && precio !== "") {
            precio = Number(precio);
        }

        // Manejar la imagen
        let nuevaFoto = req.file ? `/uploads/${req.file.filename}` : undefined;
        
        // Si hay nueva imagen, eliminar la anterior
        if (req.file && cita.foto && !cita.foto.startsWith("http")) {
            const oldImagePath = `./public${cita.foto}`;
            if (fs.existsSync(oldImagePath)) {
                fs.unlinkSync(oldImagePath);
            }
        }

        const updatedData = {
            nombreCompletoCliente,
            descripcion,
            tamano,
            fecha,
            estado,
            precio,
            tiempoEstimado,
            conversacion,
            motivoCancelacion
        };

        // Solo actualizar la foto si hay una nueva imagen
        if (nuevaFoto) {
            updatedData.foto = nuevaFoto;
        }

        await citaModel.editarCitaPorId(req.params.id, updatedData);
        res.status(200).json({ success: true, message: "Cita actualizada", data: updatedData });
        
    } catch (error) {
        // Si hay error y se subió una nueva imagen, eliminarla
        if (req.file) {
            const newImagePath = path.join(__dirname, '..', req.file.path);
            if (fs.existsSync(newImagePath)) {
                fs.unlinkSync(newImagePath);
            }
        }
        
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ 
                success: false, 
                message: error.message 
            });
        }
        next(error);
    }
});

exports.eliminarCita = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);

    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }

    try {
        const cita = await verificarPermisossCita(req.params.id, user, next);

        if (cita.foto && !cita.foto.startsWith("http")) {
            const rutaImagen = path.join(__dirname, "..", "public", cita.foto);
            if (fs.existsSync(rutaImagen)) fs.unlinkSync(rutaImagen);
        }

        await citaModel.eliminarCitaPorId(req.params.id);
        res.status(200).json({ success: true, message: "Cita eliminada", data: { id: req.params.id } });
        
    } catch (error) {
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ 
                success: false, 
                message: error.message 
            });
        }
        next(error);
    }
});

exports.verNuevaCita = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);
    
    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }
    
    const foto = req.query.foto;

    res.status(200).json({ 
        success: true, 
        data: { 
            user: { 
                data: { 
                    data: user 
                } 
            }, 
            foto 
        } 
    });
});

exports.crearCita = wrapAsync(async function (req, res, next) {
    try {
        const user = obtenerUsuario(req);

        if (!user) {
            return next(new AppError("Usuario no autenticado", 401));
        }

        let {
            nombreCompletoCliente,
            descripcion,
            tamano,
            fecha,
            precio,
            tiempoEstimado,
            estado,
            conversacion,
            motivoCancelacion
        } = req.body;

        let foto = req.file ? "/uploads/" + req.file.filename : req.body.fotoUrl || req.body.foto;

        const clienteId = user.id || user._id;

        if (!clienteId) {
            return next(new AppError("No se pudo obtener el ID del cliente", 401));
        }

        try {
            validarCamposCita({ nombreCompletoCliente, descripcion, tamano, fecha, precio });
        } catch (err) {
            // Si se subió una imagen pero los datos son inválidos, eliminar la imagen subida
            if (req.file && foto) {
                const newImagePath = path.join(__dirname, "..", "public", foto);
                if (fs.existsSync(newImagePath)) {
                    fs.unlinkSync(newImagePath);
                }
            }
            return next(err);
        }

        if (!foto) {
            return next(new AppError("Se debe proporcionar una foto del diseño del tatuaje", 400));
        }

        // CORRECCIÓN: Mejorar el parsing de la conversación
        let conversacionParsed = [];
        if (conversacion) {
            try {
                if (typeof conversacion === "string") {
                    conversacionParsed = JSON.parse(conversacion);
                } else if (Array.isArray(conversacion)) {
                    conversacionParsed = conversacion;
                }
                
                // Validar que sea un array y que tenga la estructura correcta
                if (!Array.isArray(conversacionParsed)) {
                    conversacionParsed = [];
                } else {
                    // Validar estructura de cada mensaje
                    conversacionParsed = conversacionParsed.filter(msg => 
                        msg && typeof msg === 'object' && msg.text && msg.userId
                    );
                }
            } catch (error) {
                console.error("Error al parsear conversación:", error);
                conversacionParsed = [];
            }
        }

        // Convertir precio a número si es string
        if (typeof precio === "string" && precio !== "") {
            precio = Number(precio);
        }

        const citaData = {
            nombreCompletoCliente,
            clienteId,
            foto,
            descripcion,
            tamano,
            fecha: fecha ? new Date(fecha) : new Date(),
            precio,
            tiempoEstimado,
            estado: estado || "pendiente",
            conversacion: conversacionParsed, // CORRECCIÓN: Usar la variable corregida
            motivoCancelacion
        };

        console.log("Datos de la cita a crear:", citaData); // Para debug
        console.log("Conversación a guardar:", conversacionParsed); // Para debug

        const citaCreada = await citaModel.crearCita(citaData);
        res.status(201).json({ success: true, message: "Cita creada", data: citaCreada });

    } catch (err) {
        // Si hay error y se subió una nueva imagen, eliminarla
        if (req.file) {
            const newImagePath = path.join(__dirname, "..", "public", req.file.filename);
            if (fs.existsSync(newImagePath)) {
                fs.unlinkSync(newImagePath);
            }
        }
        console.error("Error en crearCita:", err); // Para debug
        next(new AppError(err.message || "Error al crear la cita", 500));
    }
});
const verificarPermisossCita = async (citaId, user, next) => {
    if (!mongoose.Types.ObjectId.isValid(citaId)) {
        throw new AppError("ID de cita no válido", 400);
    }

    const cita = await citaModel.buscarCitaPorId(citaId);
    if (!cita) {
        throw new AppError("Cita no encontrada", 404);
    }

    const userId = user.id || user._id;
    const isAdmin = user.perfil === "ADMIN" || user.profile === "ADMIN";
    const isOwner = cita.clienteId && (cita.clienteId.toString() === userId.toString());
    
    if (!isAdmin && !isOwner) {
        throw new AppError("No tienes permisos para realizar esta acción sobre esta cita", 403);
    }

    return cita;
};

exports.verificarAutorizacionCita = wrapAsync(async function(req, res, next) {
    const user = obtenerUsuario(req);
    
    if (!user) {
        return res.status(401).json({ success: false, message: "Usuario no autenticado" });
    }

    try {
        const cita = await verificarPermisossCita(req.params.id, user, next);
        req.cita = cita; 
        req.userAuth = user; 
        next();
    } catch (error) {
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ 
                success: false, 
                message: error.message 
            });
        }
        next(error);
    }
});

exports.obtenerCitasFiltradas = async (user) => {
    const isAdmin = user.perfil === "ADMIN" || user.profile === "ADMIN";
    
    if (isAdmin) {

        const todasLasCitas = await citaModel.buscarTodo();
        return todasLasCitas;
        
    } else {

        const userId = user.id || user._id;
        const todasLasCitas = await citaModel.buscarTodo();
        const citasDelUsuario = todasLasCitas.filter(cita => {
            const match = cita.clienteId && cita.clienteId.toString() === userId.toString();
            return match;
        });

        return citasDelUsuario;
    }
};