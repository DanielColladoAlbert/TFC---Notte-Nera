// IMPORTS/REQUIRE
require("dotenv").config();
const express = require("express");
const session = require("express-session");
const methodOverride = require("method-override");
const path = require("path");
const port = process.env.PUERTO || 3016;
const mongodbConfig = require("./utils/mongodb.config");
const morganMW = require("./middlewares/morgan.mw");
const logger = require("./utils/logger");
const errorHandlerMW = require("./middlewares/errorHandler.mw");
const AppError = require("./utils/AppError");
const cors = require("cors");

const app = express();

// MIDDLEWARE
app.use(methodOverride("_method"));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "Img/uploads")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Ignorar /favicon.ico para evitar errores
app.use((req, res, next) => {
    if (req.originalUrl === "/favicon.ico") {
        return res.status(204).end();
    }
    next();
});

// Configuración de CORS
app.use(
    cors({
        origin: ['http://localhost:5173', 'http://localhost:5174'],// URL del frontend
        credentials: true
    })
);

// Configuración de sesión
app.use(
    session({
        name: "connect.sid",
        secret: process.env.SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        cookie: {
            maxAge: 3600000, // 1 hora
            secure: process.env.NODE_ENV === "production",
        },
    })
);

// Middleware global 
app.use((req, res, next) => {
    res.locals.username = req.session.userLogued
        ? req.session.userLogued.data.nombreUsuario
        : "";
    res.locals.profile = req.session.userLogued
        ? req.session.userLogued.data.perfil
        : "";
    res.locals.user = req.session.userLogued ? req.session.userLogued.data : null;
    next();
});

// RUTAS DE LA API
const userRoutes = require("./routes/usuario.routes");
const tatuajesRealizadosRoutes = require("./routes/tatuajesRealizados.routes");
const citasRoutes = require("./routes/citas.routes");
const resenasRoutes = require("./routes/resenas.routes");
const disenosDisponiblesRoutes = require("./routes/disenosDisponibles.routes");

app.use(morganMW.usingMorgan());

// Archivos estáticos del frontend
app.use(express.static(path.join(__dirname, "../frontend/dist")));

// Rutas API
app.use("/api/disenosDisponibles", disenosDisponiblesRoutes);
app.use("/api/resenas", resenasRoutes);
app.use("/api/citas", citasRoutes);
app.use("/api/tatuajesRealizados", tatuajesRealizadosRoutes);
app.use("/api/", userRoutes); 

// Redirigir rutas que no son API a index.html 
app.get(/^\/(?!api|Img|public).*/, (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// Middleware para rutas no existentes (API)
app.use((req, res, next) => {
    logger.error.fatal("Ruta no existente " + req.originalUrl);
    next(new AppError("Ruta no existente", 404));
});

// Gestión de errores
app.use(errorHandlerMW.errorHandler);

// Fallback 404 JSON
app.use((req, res) => {
    res.status(404).json({ err: "Ruta no encontrada" });
});


// INICIAR SERVIDOR
app.listen(port, async () => {
    try {
        await mongodbConfig.conectarMongoDB();
    } catch (err) {
        console.error(`Error al conectar a MongoDB: ${err}`);
        process.exit(1);
    }
});
