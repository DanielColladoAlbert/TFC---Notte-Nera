const userModel = require("../models/usuario.model")

const ejecutar = async () => {

     await userModel.deleteMany({});

    const users = [
        {
            nombreUsuario: "admin1",
            contrasena: "$2b$12$V186PVL25qdoewHE201UmePCL2IVEv3YRJggjRJsc2sO1T9hKmSGS",
            nombre: "Guillermo",
            apellidos: "Pérez Castro",
            correo: "guillermo@tatto.com",
            foto: "/uploads/usuario1.jpeg",
            perfil: "ADMIN",
        },
        {
            nombreUsuario: "usuario1",
            contrasena: "$2b$12$WE1ouG7gv45dJSxh5ol.z.KQg0V6WiOP/Rk.FlSMQOSejoZV8AEum",
            nombre: "Raquel",
            apellidos: "Hernández García",
            correo: "usuario@ejemplo.com",
            foto: "/uploads/usuario2.jpg",
            perfil: "USUARIO",
        },
        {
            nombreUsuario: "usuario2",
            contrasena: "$2b$12$WE1ouG7gv45dJSxh5ol.z.KQg0V6WiOP/Rk.FlSMQOSejoZV8AEum",
            nombre: "Miriam",
            apellidos: "Gonzalez López",
            correo: "usuario2@ejemplo.com",
            foto: "/uploads/usuario3.png",
            perfil: "USUARIO",
        }
    ]

    try {
        const res = await userModel.insertMany(users) 
    } catch (err) {
        console.error("Error al insertar los usuarios:", err)
    }
}

module.exports = ejecutar
