const resenaModel = require("../models/resenas.model")
const Usuario = require("../models/usuario.model")

const ejecutar = async () => {

    const usuario1 = await Usuario.findOne({ nombreUsuario: "usuario1" })
    const usuario2 = await Usuario.findOne({ nombreUsuario: "usuario2" })

     await resenaModel.deleteMany({});

    const resenas = [
        {
            clienteId: usuario1._id,
            nombreUsuario: "usuario1",
            fotoPerfil: "/uploads/usuario2.jpg",
            resena: "Excelente servicio y atención, muy recomendable.",
            estrellas: 4,
            aprobado: "aprobado",
            fecha: new Date("2024-10-15"),
        },
        {
            clienteId: usuario2._id,
            nombreUsuario: "usuario2",
            fotoPerfil: "/uploads/usuario3.png",
            resena: "Cada vez mas enamorada de como tatua.",
            estrellas: 5,
            aprobado: "aprobado",
            fecha: new Date("2024-7-21"),
        }
    ]

    try {
        await resenaModel.insertMany(resenas)
    } catch (err) {
        console.error("Error insertando reseñas:", err)
    }
}

module.exports = ejecutar
