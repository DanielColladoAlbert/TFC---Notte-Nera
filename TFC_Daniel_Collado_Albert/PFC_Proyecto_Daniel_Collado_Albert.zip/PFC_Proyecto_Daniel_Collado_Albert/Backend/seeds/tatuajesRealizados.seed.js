const tatuajeModel = require("../models/tatuajesRealizados.model")

const ejecutar = async () => {

     await tatuajeModel.deleteMany({});

    const tatuajesRealizados = [
        {
            foto: "/uploads/tatuajesRealizados.jpg",
            titulo: "Tatuaje de una ola geometrica",
            descripcion: "Tatuaje de una ola estilo acuarela con toques de geometría",
            tamano: "30cm x 20cm",
            tipo: "Acuarela/Geometría",
            fecha: new Date(),
            nombreCliente: "Gabriela Lillo López",
        },
    ]

    try {
        await tatuajeModel.insertMany(tatuajesRealizados)
    } catch (err) {
        console.error("Error insertando tatuajes:", err)
    }
}

module.exports = ejecutar
