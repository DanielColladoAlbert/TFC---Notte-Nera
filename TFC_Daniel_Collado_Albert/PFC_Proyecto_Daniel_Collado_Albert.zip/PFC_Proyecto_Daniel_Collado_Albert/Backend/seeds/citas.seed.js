const Cita = require("../models/citas.model")
const Usuario = require("../models/usuario.model")

const ejecutar = async () => {
    try {

        await Cita.deleteMany({});
    
        const usuario = await Usuario.findOne({ nombreUsuario: "usuario1" })
        const usuario2 = await Usuario.findOne({ nombreUsuario: "usuario2" })

        const citas = [
            {
                clienteId: usuario2._id, 
                nombreCompletoCliente: "Miriam Gonzalez López", 
                foto: "/uploads/cita1.jpg",
                descripcion: "Kunoichi con mascara de oni",
                tamano: "28cm x 20cm",
                fecha: new Date("2025-06-10T18:00:00Z"),
                precio: 150,
                tiempoEstimado: "1h 30min",
                estado: "pendiente",
            },
            {
                clienteId: usuario._id, 
                nombreCompletoCliente: "Raquel Hernández García",
                foto: "/uploads/cita2.jpg",
                descripcion: "Dibujo de zorro con decoracion",
                tamano: "40cm x 35cm",
                fecha: new Date("2025-07-11T19:30:00Z"),
                precio: 80,
                tiempoEstimado: "45min",
                estado: "confirmada",
            }
        ]

        await Cita.insertMany(citas)
    } catch (err) {
        console.error("Error insertando citas:", err)
    }
}

module.exports = ejecutar
