const Diseno = require("../models/disenosDisponibles.model")

const ejecutar = async () => {

     await Diseno.deleteMany({});

    const disenos = [
        {
            foto: "/uploads/disenosDisponibles.jpg",
            titulo: "Himiko Toga",
            descripcion: "Diseño del personaje de Himiko Toga de My Hero Academia, en blanco y negro con detalles florales en fucsia.",
            tamano: "20cm x 15cm",
            tipo: "Anime",
            precio: 150,
            tiempoEstimado: "1h 15min",
            disponible: true,
            precioExclusivo: 40
        }
    ]

    try {
        await Diseno.insertMany(disenos)
    } catch (err) {
        console.error("Error insertando diseños:", err)
    }
}

module.exports = ejecutar