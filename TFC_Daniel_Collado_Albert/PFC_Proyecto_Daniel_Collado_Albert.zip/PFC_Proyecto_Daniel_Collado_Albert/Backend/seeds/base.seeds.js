const mongoose = require("mongoose")
const mongodbConfig = require("../utils/mongodb.config")

const citas = require("./citas.seed")
const disenosDisponibles = require("./disenosDisponibles.seed")
const resenas = require("./resenas.seed")
const tatuajesRealizados = require("./tatuajesRealizados.seed")
const usuarios = require("./usuario.seed")

const ejecutarSeeds = async () => {
    try {

        await mongodbConfig.conectarMongoDB() 

        await usuarios()
        console.log("Seed de usuarios completado")

        await citas()
        console.log("Seed de citas completado")

        await disenosDisponibles()
        console.log("Seed de diseños disponibles completado")

        await tatuajesRealizados()
        console.log("Seed de tatuajes realizados completado")

        await resenas()
        console.log("Seed de reseñas completado")


    } catch (err) {
        console.error("Error durante la ejecución de los seeds:", err)
    } finally {
        await mongoose.connection.close()
        console.log("Conexión cerrada con MongoDB")
    }
}

ejecutarSeeds()
