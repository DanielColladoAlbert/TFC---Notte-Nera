import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './Components/AuthContext.jsx';
import App from './App.jsx'

import axios from 'axios'

let host = import.meta.env.REACT_APP_BACKEND_URL

window.axios = axios

window.axios.defaults.baseURL = host
window.axios.defaults.headers.common["Accept"] = "application/json"
window.axios.defaults.headers.common["Content-Type"] = "application/json"
window.axios.defaults.headers.common["X-Requested-With"] = "XMLHttpRequest"
window.axios.defaults.withCredentials = true

// Interceptor para manejar errores
axios.interceptors.response.use(
    response => response,
    async error => {
        if (error.response && error.response.status === 401) {
            const refreshToken = storage.get('refreshToken'); // Recupera el token

            if (refreshToken) {
                try {
                    // Intenta renovar el token
                    const { data } = await axios.post('/auth/refresh-token', { refreshToken });

                    // Guarda el nuevo token
                    storage.set('authToken', data.token);
                    error.config.headers['Authorization'] = `Bearer ${data.token}`;

                    // Vuelve a realizar la petición original
                    return axios(error.config);
                } catch (refreshError) {
                    console.error('Error al renovar el token:', refreshError);
                    storage.remove('authToken');
                    storage.remove('authUser');
                    window.location.href = '/';
                }
            } else {
                // Si no hay token, redirige a la página de login
                storage.remove('authToken');
                storage.remove('authUser');
                window.location.href = '/';
            }
        }
        return Promise.reject(error);
    }
);

window.axios = axios

createRoot(document.getElementById('root')).render(  
    <StrictMode>
    <BrowserRouter>
        <AuthProvider>
            <App />
        </AuthProvider>
    </BrowserRouter>
  </StrictMode>
)