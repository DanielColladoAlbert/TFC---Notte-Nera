import { createContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"; 
import storage from "../Storage/storage";
import Swal from 'sweetalert2';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  const [user, setUser] = useState(null); 
  const [isBlocked, setIsBlocked] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate(); 

  const handleInvalidSession = async () => {
    await Swal.fire({
      icon: 'warning',
      title: 'Sesión inválida',
      text: 'Por favor, registrese de nuevo. Su sesión se ha cerrado.',
      confirmButtonText: 'Aceptar',
      customClass: {
        popup: 'swal-popup',
        title: 'swal-title',
        content: 'swal-content',
        confirmButton: 'swal-confirm-button',
      }
    });
    storage.remove("authToken");
    storage.remove("authUser");
    setIsAuthenticated(false);
    setUser(null);
    navigate('/'); 
  };

  const isTokenExpired = (token) => {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp * 1000 < Date.now(); 
    } catch (error) {
      console.error("Error decodificando token:", error);
      return true;
    }
  };

  const checkAuth = async () => {
    const token = storage.get("authToken");
    const user = storage.get("authUser");
    setIsBlocked(user?.isBlocked === true);

    if (token && user) {
      if (isTokenExpired(token)) {
        await handleInvalidSession();
        setIsLoading(false);
        return;
      }

      try {
        const response = await fetch('/auth/check-token', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
          }
        });

        if (!response.ok) {
          const errorData = await response.json();
          if (errorData.err === "Token inválida" || errorData.err === "Token expirado") {
            await handleInvalidSession();
          }
          setIsLoading(false); 
          return;
        }

        setIsAuthenticated(true);
        setUser(user);
      } catch (error) {
        console.error("Error verificando autenticación:", error);
      }
    }

    setIsLoading(false);
  };

  useEffect(() => {
    const initializeAuth = async () => {
      await checkAuth();
    };
    initializeAuth();

    const checkAuthOnStorageChange = () => {
      const token = storage.get("authToken");
      const user = storage.get("authUser");
      setIsAuthenticated(!!token && !!user);
      setUser(user || null);
    };

    window.addEventListener("storage", checkAuthOnStorageChange);
    return () => window.removeEventListener("storage", checkAuthOnStorageChange);
  }, []);

  const login = (token, user) => {
    storage.set("authToken", token);
    storage.set("authUser", user);
    setIsAuthenticated(true);
    setUser(user);
    setIsBlocked(user?.isBlocked === true);
  };
  
  const logout = () => {
    storage.remove("authToken");
    storage.remove("authUser");
    setIsAuthenticated(false);
    setUser(null);
    navigate('/iniciarSesion');
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout, isBlocked, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
