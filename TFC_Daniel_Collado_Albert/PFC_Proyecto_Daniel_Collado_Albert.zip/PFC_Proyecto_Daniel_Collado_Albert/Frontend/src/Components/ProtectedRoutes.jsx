import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../Components/AuthContext';

export const ProtectedRoutes = () => {
  const { isAuthenticated, isBlocked, isLoading, user } = useContext(AuthContext);

  if (isLoading) return null;

  if (!isAuthenticated) return <Navigate to="/api/login" />;

  if (isBlocked) {
    const id = user?._id;
    if (!id) {
      console.error("Usuario bloqueado sin ID definido");
      return <Navigate to="/api/iniciarSesion" replace />;
    }
    return <Navigate to={`/api/bloqueado/${id}`} replace />;
  }
  
  return <Outlet />;
};
