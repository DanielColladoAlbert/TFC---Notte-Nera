import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../css/Registro.css";
import "../css/base/sweetAlert.css";
import foto_usuario from "../assets/Imagenes/foto_usuario_blanco.png";
import ojoAbierto from "../assets/Imagenes/ojo_abierto.png";
import ojoCerrado from "../assets/Imagenes/ojo_cerrado.png";
import Swal from "sweetalert2";

const BASE_URL = "http://localhost:3016/api";

const Registro = () => {
  const navigate = useNavigate();
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [user, setUser] = useState({
    nombreUsuario: "",
    nombre: "",
    apellidos: "",
    correo: "",
    contrasena: "",
    foto: null,
  });
  const [confirmarContrasena, setConfirmarContrasena] = useState("");
  const [imagePreview, setImagePreview] = useState(null);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [formModified, setFormModified] = useState(false);

  const validators = {
    nombreUsuario: (value) => /^[\w@!#$%^&*º()[\]{}\-+=~.]{5,}$/.test(value),
    correo: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value),
    nombre: (value) => /^[\p{L} \-'`´]+$/u.test(value),
    apellidos: (value) => /^[\p{L} \-'`´]+$/u.test(value),
    contrasena: (value) => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[-_!?@]).{8,}$/.test(value),
  };

  useEffect(() => {

    Object.keys(touched).forEach((field) => {
      if (touched[field] && validators[field]) {
        const isValid = validators[field](user[field]);
        setErrors(prev => ({ ...prev, [`${field}Error`]: !isValid }));
      }
    });

    if (touched.confirmarContrasena && user.contrasena !== confirmarContrasena) {
      setErrors(prev => ({ ...prev, confirmarContrasenaError: true }));
    } else if (touched.confirmarContrasena) {
      setErrors(prev => ({ ...prev, confirmarContrasenaError: false }));
    }
  }, [user, confirmarContrasena, touched]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const imageRegex = /\.(jpe?g|png|gif)$/i;
    if (file) {
      if (!imageRegex.test(file.name)) {
        setErrors((prevErrors) => ({ ...prevErrors }));
        setImagePreview(null);
        setUser((prev) => ({ ...prev, foto: null }));
        e.target.value = "";
        Swal.fire({
          icon: "error",
          title: "Archivo no válido",
          text: "Solo se permiten imágenes en formato JPEG, JPG, PNG o GIF.",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        return;
      }
      setErrors((prevErrors) => ({ ...prevErrors }));
      const reader = new FileReader();
      reader.onload = (event) => setImagePreview(event.target.result);
      reader.readAsDataURL(file);
      setUser((prev) => ({ ...prev, foto: file }));
      setFormModified(true);
    }
  };

  const handleCancelImage = () => {
    setImagePreview(null);
    setUser((prev) => ({ ...prev, foto: null }));
    const input = document.getElementById("foto");
    if (input) input.value = "";
    setFormModified(true);
  };

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const toggleConfirmPasswordVisibility = () => {
    setConfirmPasswordVisible(!confirmPasswordVisible);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (!touched[name]) {
      setTouched(prev => ({ ...prev, [name]: true }));
    }
    
    setUser((prev) => ({ ...prev, [name]: value }));
    setFormModified(true);
  };
  
  const handleConfirmPasswordChange = (e) => {
    const value = e.target.value;
    setConfirmarContrasena(value);
    
    if (!touched.confirmarContrasena) {
      setTouched(prev => ({ ...prev, confirmarContrasena: true }));
    }
    setFormModified(true);
  };

  const handleCancel = () => {
    if (formModified) {

      Swal.fire({
        icon: "warning",
        title: "¿Estás seguro?",
        text: "No se guardarán los cambios realizados",
        showCancelButton: true,
        confirmButtonText: "Sí, salir",
        cancelButtonText: "No, continuar con el registro",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-cancel-button",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate(-1);
        }
      });
    } else {
    
      navigate(-1);
    }
  };

  const esNombreUsuarioRestringido = (nombre) => {
  const limpio = nombre
    .toLowerCase()
    .normalize("NFD")
    .replace(/[^\p{L}\p{N}]/gu, "") // quita símbolos y espacios
    .replace(/usuarioeliminado/g, "usuarioeliminado");

  return limpio === "usuarioeliminado";
};

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const allTouched = {};
    Object.keys(validators).forEach(field => {
      allTouched[field] = true;
    });
    allTouched.confirmarContrasena = true;
    setTouched(allTouched);

    let formValid = true;
    Object.keys(validators).forEach(field => {
      const isValid = validators[field](user[field]);
      setErrors(prev => ({ ...prev, [`${field}Error`]: !isValid }));
      if (!isValid) formValid = false;
    });
    
    if (user.contrasena !== confirmarContrasena) {
      setErrors(prev => ({ ...prev, confirmarContrasenaError: true }));
      formValid = false;
    }

    if (esNombreUsuarioRestringido(user.nombreUsuario)) {
      Swal.fire({
        icon: "error",
        title: "Nombre no permitido",
        text: "Este nombre de usuario está restringido. Por favor, elige otro.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    if (!formValid) {
      Swal.fire({
        icon: "error",
        title: "Datos incorrectos",
        text: "Por favor, corrija los errores en el formulario.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    const formData = new FormData();
    formData.append("nombreUsuario", user.nombreUsuario);
    formData.append("nombre", user.nombre);
    formData.append("apellidos", user.apellidos);
    formData.append("correo", user.correo);
    formData.append("contrasena", user.contrasena);
    if (user.foto) {
      formData.append("foto", user.foto);
    }

    try {
      const response = await fetch(`${BASE_URL}/registro`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      const data = await response.json();

      if (!response.ok) {
        const errorText = data?.errorMessage || "No se pudo registrar el usuario.";
        Swal.fire({
          icon: "error",
          title: "Error",
          text: errorText,
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Registro exitoso",
          text: "Ahora puedes iniciar sesión.",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        navigate("/api/iniciarSesion");
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error de conexión",
        text: "Intántalo nuevamente más tarde.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  return (
    <div className="registro-usuario-container">
      <div className="registro-usuario-content">
        <form autoComplete="off" className="registro-usuario-form" onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="registro-usuario-columna1">
            <div className="registro-usuario-fotoPerfil">
              <img
                src={imagePreview || foto_usuario}
                alt="Foto de perfil"
                width="150"
                height="150"
                className="registro-usuario-foto-perfil"
              />
              <label htmlFor="foto">Seleccionar Foto de Perfil:</label>
              <input type="file" name="foto" id="foto" onChange={handleImageChange}  tabIndex="1"/>
              {imagePreview && (
                <button type="button" className="registro-usuario-boton-cancelar-foto" onClick={handleCancelImage}>
                  Cancelar
                </button>
              )}
            </div>
          </div>
          <div className="registro-usuario-columna2">
            <label>Nombre de Usuario:</label>
            <input 
              type="text" 
              autoComplete="new-username" 
              name="nombreUsuario" 
              value={user.nombreUsuario} 
              onChange={handleInputChange}
              required 
              tabIndex="2"
            />
            {touched.nombreUsuario && errors.nombreUsuarioError && 
              <span className="registro-usuario-mensaje-error">Mínimo 5 caracteres alfanuméricos.</span>
            }

            <label>Nombre:</label>
            <input 
              type="text" 
              name="nombre" 
              value={user.nombre} 
              onChange={handleInputChange}
              required 
              tabIndex="3"
            />
            {touched.nombre && errors.nombreError && 
              <span className="registro-usuario-mensaje-error">Solo se permiten letras.</span>
            }

            <label>Apellidos:</label>
            <input 
              type="text" 
              name="apellidos" 
              value={user.apellidos} 
              onChange={handleInputChange}
              required 
              tabIndex="4"
            />
            {touched.apellidos && errors.apellidosError && 
              <span className="registro-usuario-mensaje-error">Solo se permiten letras.</span>
            }
          </div>

          <div className="registro-usuario-columna3">
            <label>Correo Electrónico:</label>
            <input 
              type="email" 
              name="correo" 
              value={user.correo} 
              onChange={handleInputChange}  
              required 
              tabIndex="5"
            />
            {touched.correo && errors.correoError && 
              <span className="registro-usuario-mensaje-error">Correo no válido.</span>
            }

            <label>Contraseña:</label>
            <div className="registro-usuario-input-wrapper">
              <input
                type={passwordVisible ? "text" : "password"}
                name="contrasena"
                value={user.contrasena}
                onChange={handleInputChange}
                id="contrasena-registro"
                className="registro-usuario-input-contrasena"
                autoComplete="new-password"
                required
                minLength={8}
                tabIndex="6"
              />
              <button type="button" className="boton-ojo" onClick={togglePasswordVisibility}>
                <img
                  src={passwordVisible ? ojoAbierto : ojoCerrado}
                  alt="Mostrar/Ocultar"
                  className="registro-usuario-ojo"
                />
              </button>
            </div>
            {touched.contrasena && errors.contrasenaError && (
              <span className="registro-usuario-mensaje-error">
                Debe tener +8 caracteres, una mayúscula, número y símbolo.
              </span>
            )}

            <label>Repetir Contraseña:</label>
            <div className="registro-usuario-input-wrapper">
              <input
                type={confirmPasswordVisible ? "text" : "password"}
                value={confirmarContrasena}
                onChange={handleConfirmPasswordChange}
                onBlur={() => setTouched(prev => ({ ...prev, confirmarContrasena: true }))}
                required
                id="contrasena-registro-confirmar"
                tabIndex="7"
              />
              <button type="button" className="boton-ojo" onClick={toggleConfirmPasswordVisibility}>
                <img
                  src={confirmPasswordVisible ? ojoAbierto : ojoCerrado}
                  alt="Mostrar/Ocultar"
                  className="registro-usuario-ojo"
                  id="ojo-confirmar"
                />
              </button>
            </div>
            {touched.confirmarContrasena && errors.confirmarContrasenaError && (
              <span className="registro-usuario-mensaje-error">
                Las contraseñas no coinciden.
              </span>
            )}

            <button className="registro-usuario-boton" type="submit">
              Registrarse
            </button>
            <button className="registro-usuario-boton" type="button" onClick={handleCancel}>
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Registro;