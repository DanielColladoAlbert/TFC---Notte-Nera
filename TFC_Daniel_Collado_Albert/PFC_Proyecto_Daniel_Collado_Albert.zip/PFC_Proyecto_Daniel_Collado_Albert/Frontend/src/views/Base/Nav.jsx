import { useState } from "react";
import "../../css/base/Nav.css";
import storage from "../../Storage/storage"; 
import { useNavigate } from "react-router-dom"; 

const Nav = () => {
  const [isActive, setIsActive] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const navigate = useNavigate();

  const authUser = storage.get("authUser");
  const isAdmin = authUser?.profile === "ADMIN"; 

  const openMenu = () => {
    setIsActive(true);
    setIsClosing(false);
  };

  const closeMenu = () => {
    setIsClosing(true); 
    setTimeout(() => {
      setIsActive(false);
      setIsClosing(false);
    }, 500); 
  };

  const handleNavigation = (path) => {
    if (authUser) {
      navigate(path); 
    } else {
      navigate("/api/iniciarSesion"); 
    }
  };

  return (
    <div className={`nav ${isActive ? "active" : ""} ${isClosing ? "closing" : ""}`}>
      <div className="menu-icon" onClick={openMenu}>
        <div></div>
        <div></div>
        <div></div>
      </div>
      <div role="link" onClick={() => handleNavigation("/api/tatuajesRealizados")}>Tatuajes realizados</div>
      <div role="link" onClick={() => handleNavigation("/api/citas")}>Citas</div>
      <div role="link" onClick={() => handleNavigation("/api/disenosDisponibles")}>Diseños disponibles</div>
      <div role="link" onClick={() => handleNavigation("/api/resenas")}>Reseñas</div>
      {isAdmin && ( 
        <div role="link" onClick={() => handleNavigation("/api/lista")}>Lista de usuarios</div>
      )}
      <div className="close-icon" onClick={closeMenu}>
        &times;
      </div>
    </div>
  );
};

export default Nav;
