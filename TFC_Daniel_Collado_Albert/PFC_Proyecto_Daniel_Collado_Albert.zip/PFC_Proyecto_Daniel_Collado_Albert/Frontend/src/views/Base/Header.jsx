import { useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../../css/base/Header.css";
import "../../css/base/sweetAlert.css";
import logo from "../../assets/Imagenes/logo.png";
import iniciarSesionImg from "../../assets/Imagenes/iniciar_sesion.png";
import registrarseImg from "../../assets/Imagenes/registrarse.png";
import perfilImg from "../../assets/Imagenes/foto_usuario.png";
import cerrarSesion from "../../assets/Imagenes/cerrar_sesion.png";
import { AuthContext } from "../../Components/AuthContext";
import Swal from 'sweetalert2';
import storage from "../../Storage/storage";


const Header = () => {

  const navigate = useNavigate();

  const { isAuthenticated, logout } = useContext(AuthContext);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 850);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 850);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleLogout = async () => {
    try {
      const response = await fetch("/api/logout", { method: "GET", credentials: "include" });

      if (response.ok) {
        logout();
        Swal.fire({
          icon: 'success',
          title: 'Vuelva pronto',
          text: 'Has cerrado sesión correctamente.',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        }).then(() => {
          window.location.href = "/api/";
        });
      } else {
        throw new Error('Error al cerrar sesión');
      }
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Ha ocurrido un error al intentar cerrar sesión.',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  const authUser = storage.get("authUser");

  return (
    <div className="header">
      <a href="/api/" title="Inicio">
        <img src={logo} alt="Logo" className="logo" />
      </a>
      <a href="/api/" title="Inicio">
        <h1 className="title">Notte Nera</h1>
      </a>
      <div className="buttons">
        {isAuthenticated ? (
          <>
            {isAuthenticated && !authUser?.isBlocked && (
              <button onClick={() => navigate(`/api/perfil/${authUser._id}`)}>
                {isMobile ? <img src={perfilImg} alt="Ver perfil" className="button-img" /> : "Ver perfil"}
              </button>
            )}
            <button onClick={handleLogout}>
              {isMobile ? <img src={cerrarSesion} alt="Cerrar sesión" className="button-img" /> : "Cerrar sesión"}
            </button>
          </>
        ) : (
          <>
            <button onClick={() => navigate ("/api/iniciarSesion")}>
              {isMobile ? <img src={iniciarSesionImg} alt="Iniciar sesión" className="button-img" /> : "Iniciar sesión"}
            </button>
            <button onClick={() => navigate("/api/registro")}>
              {isMobile ? <img src={registrarseImg} alt="Registrarse" className="button-img" /> : "Registrarse"}
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Header;
