import "../../css/base/Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <p className="footer-item">Teléfono: +123 456 789</p>
      <p className="footer-item">C/ San Nathaniel Nº 35 </p>
      <p className="footer-item">&copy; 2023 Notte Nera. Todos los derechos reservados.</p>
      <p className="footer-item">Email: NotteNera@tattoostudio.com</p>
    </div>
  );
};

export default Footer;
