import { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import storage from "../../../Storage/storage";
import '../../../css/resenas/R-Inicio.css';
import estrella from '../../../assets/Imagenes/estrella.png';
import imagenErrorBlanco from "../../../assets/Imagenes/error-imagen-blanco.png";
import foto_usuario from "../../../assets/Imagenes/foto_usuario_blanco.png";

const BASE_URL = "http://localhost:3016";

const Resenas = ({ user }) => {
    const [resenas, setResenas] = useState([]);
    const [filter, setFilter] = useState('todas');
    const [order, setOrder] = useState('');
    const [isDirty, setIsDirty] = useState(false);
    const navigate = useNavigate();

    const authUser = storage.get("authUser");
    const isAdmin = authUser?.profile === "ADMIN";

    useEffect(() => {
        fetchResenas();
    }, [filter, order]);

    useEffect(() => {
        const handleBeforeUnload = (e) => {
            if (isDirty) {
                e.preventDefault();
                e.returnValue = "";
            }
        };
        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => window.removeEventListener("beforeunload", handleBeforeUnload);
    }, [isDirty]);

    const fetchResenas = useCallback(async () => {
        try {
            const token = storage.get('authToken');
            const queryParams = new URLSearchParams();

            if (filter && filter !== 'todas') {
                queryParams.append('estado', filter);
            }

            if (order) {
                queryParams.append('ordenarPor', order);
            }

            const response = await fetch(`${BASE_URL}/api/resenas?${queryParams.toString()}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            });

            if (!response.ok) {
                handleFetchError(response);
                return;
            }

            const data = await response.json();
            setResenas(data.resenas);
        } catch (error) {
            console.error('Error fetching reseñas:', error);
        }
    }, [filter, order]);

    const handleFetchError = async (response) => {
        if (response.status === 401) {
            console.error("Token inválido o caducado");
            localStorage.removeItem("authToken");
            localStorage.removeItem("authUser");
            navigate('/api/iniciarSesion');
        } else {
            const errorMsg = await response.text();
            throw new Error(`Error en la solicitud: ${errorMsg}`);
        }
    };

    const formatDate = (dateString) => {
        const fecha = new Date(dateString);
        const dia = String(fecha.getDate()).padStart(2, '0');
        const mes = String(fecha.getMonth() + 1).padStart(2, '0');
        const anio = fecha.getFullYear();
        return `${dia}/${mes}/${anio}`;
    };

    const formattedResenas = useMemo(() => {
        return resenas.map(resena => ({
            ...resena,
            fechaFormateada: formatDate(resena.fecha)
        }));
    }, [resenas]);

    const mostrarEstadisticas = async () => {
        try {
            const token = localStorage.getItem('authToken');

            const response = await fetch(`${BASE_URL}/api/resenas/estadisticas`, {
                method: "GET",
                credentials: "include",
                headers: {
                  'Accept': 'application/json',
                  'Authorization': `Bearer ${token}`
                }
            });

            const text = await response.text();

            const contentType = response.headers.get("content-type");
            if (!contentType || !contentType.includes("application/json")) {
                throw new Error("La respuesta no es un JSON válido.");
            }

            const data = JSON.parse(text);

            const totalResenasElem = document.getElementById("totalResenas");
            const notaMediaElem = document.getElementById("notaMedia");

            if (totalResenasElem) totalResenasElem.innerText = data.total ?? "—";
            if (notaMediaElem) notaMediaElem.innerText = parseFloat(data.media).toFixed(2) ?? "—";

            for (let i = 1; i <= 5; i++) {
                const votoElem = document.getElementById(`voto${i}`);
                if (votoElem) votoElem.innerText = data.estrellas[i] ?? 0;
            }

            document.getElementById("statsModal").style.display = "block";
        } catch (error) {
            console.error('Error fetching estadisticas:', error.message);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Hubo un problema al cargar las estadísticas: ${error.message}`,
                customClass: {
                    popup: 'custom-popup',
                    title: 'custom-title',
                    content: 'custom-content',
                    confirmButton: 'custom-confirm-button',
                }
            });
        }
    };

    const cerrarEstadisticas = () => {
        document.getElementById("statsModal").style.display = "none";
    };

    const cambiarEstado = async (resenaId, estado) => {
        try {
            const token = storage.get('authToken');
            if (!token) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'No estás autenticado. Por favor, inicia sesión.',
                    customClass: {
                        popup: 'custom-popup',
                        title: 'custom-title',
                        content: 'custom-content',
                        confirmButton: 'custom-confirm-button',
                    },
                });
                return;
            }

            const response = await fetch(`${BASE_URL}/api/resenas/estado/${resenaId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ estado })
            });

            if (response.ok) {
                Swal.fire({
                    icon: 'success',
                    title: 'Estado actualizado correctamente',
                    text: '',
                    customClass: {
                        popup: 'custom-popup',
                        title: 'custom-title',
                        content: 'custom-content',
                        confirmButton: 'custom-confirm-button',
                    },
                });
                fetchResenas();
            } else {
                const errorMsg = await response.text();
                Swal.fire({
                    icon: 'error',
                    title: 'Error al actualizar el estado',
                    text: errorMsg,
                    customClass: {
                        popup: 'custom-popup',
                        title: 'custom-title',
                        content: 'custom-content',
                        confirmButton: 'custom-confirm-button',
                    },
                });
            }
        } catch (error) {
            console.error('Error al cambiar estado:', error);
        }
    };

    const filtrarResenas = (estado) => {
        setFilter(estado);
    };

    const ordenarResenas = (e) => {
        setOrder(e.target.value);
    };

    const confirmDelete = (id) => {
        Swal.fire({
            title: '¿Quieres eliminar esta reseña?',
            text: "Esta acción no se puede deshacer.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            customClass: {
                popup: "custom-popup",
                title: "custom-title",
                content: "custom-content",
                confirmButton: "custom-confirm-button",
                cancelButton: "custom-confirm-button",
            },
        }).then((result) => {
            if (result.isConfirmed) {
                handleDelete(id);
            }
        });
    };

    const handleDelete = async (id) => {
        try {
            const token = localStorage.getItem("authToken");
            if (!token) return;

            const response = await fetch(`${BASE_URL}/api/resenas/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            });

            if (!response.ok) {
                const errorMsg = await response.text();
                throw new Error(`Error eliminando el diseño: ${errorMsg}`);
            }

            setResenas(resenas.filter(resena => resena._id !== id));
            Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: 'La reseña ha sido eliminada correctamente.',
                customClass: {
                    popup: 'custom-popup',
                    title: 'custom-title',
                    content: 'custom-content',
                    confirmButton: 'custom-confirm-button',
                },
            });
        } catch (error) {
            console.error('Error eliminando la reseña:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se pudo eliminar la reseña.',
                customClass: {
                    popup: 'custom-popup',
                    title: 'custom-title',
                    content: 'custom-content',
                    confirmButton: 'custom-confirm-button',
                },
            });
        }
    };

    const comprobarID = (resena) => {
        if (!authUser || !authUser._id) {
            console.warn("AuthUser no válido:", authUser);
            return false;
        }
        
        let clienteId;
        if (resena?.clienteId?._id) {
            clienteId = resena.clienteId._id;
        } else if (resena?.clienteId) {
            clienteId = resena.clienteId;
        } else {
            console.warn("ClienteId no encontrado en reseña:", resena);
            return false;
        }
        
        const userId = authUser._id;
        
        const esElMismoUsuario = String(clienteId).trim() === String(userId).trim();
        
        return esElMismoUsuario;
    };

    const getFotoPerfilUrl = (fotoPerfil) => {
        if (
            !fotoPerfil ||                                 
            fotoPerfil.trim() === "" ||                    
            fotoPerfil === "null" || 
            fotoPerfil === "undefined" || 
            fotoPerfil.includes("null") || 
            fotoPerfil.includes("undefined") || 
            fotoPerfil.startsWith('/Img')
        ) {
            return foto_usuario;
        }

        return `${BASE_URL}${fotoPerfil}`;
    };

    const getClienteId = (clienteId) => {
        if (clienteId && typeof clienteId === 'object' && clienteId._id) return clienteId._id;
        return clienteId;
    };

    const estaBloqueado = (clienteId) => {
        return clienteId && typeof clienteId === 'object' && clienteId.bloqueado;
    };

    return (
        <div>
            <h1 className='titulo-resenas'>Reseñas</h1>

            {isAdmin && (
                <div className='filtro-contenedor'>
                    <label htmlFor="filtroEstado">Filtrar por:</label>
                    <select id="filtroEstado" onChange={(e) => filtrarResenas(e.target.value)} value={filter}>
                        <option value="todas">Todas</option>
                        <option value="aprobado">Aprobado</option>
                        <option value="por aprobar">Por aprobar</option>
                        <option value="cancelado">Cancelado</option>
                    </select>
                </div>
            )}

            <div className='filtro-contenedor'>
                <label htmlFor="ordenarPor">Ordenar por:</label>
                <select id="ordenarPor" onChange={ordenarResenas} value={order}>
                    <option value="">-- Seleccione una opción --</option>
                    <option value="recientes">Más recientes</option>
                    <option value="antiguas">Más antiguas</option>
                    <option value="mejorValorados">Mejor valorados</option>
                    <option value="peorValorados">Peor valorados</option>
                </select>
            </div>

            {resenas.length === 0 ? (
                <div className="diseno-vacio" id='dd-vacio'>
                    <img src={imagenErrorBlanco} alt="No hay diseños" className="diseno-vacio-img" />
                    <h2>No hay reseñas.</h2>
                    <p>¿A que esperas para dejar tu comentario?</p>
                </div>
            ) : (
                <div className="resenas-lista">
                    {formattedResenas.map(resena => (
                        <div className="resena-item" key={resena._id}>
                            <img
                                src={getFotoPerfilUrl(resena.fotoPerfil)}
                                alt="Foto de perfil"
                                className="resena-img"
                            />
                            <div className="info-contenedor">
                                <p><strong>{resena.nombreUsuario}</strong></p>
                                <p>{resena.resena}</p>
                                <div className="estrellas">
                                    {[...Array(resena.estrellas)].map((_, i) => (
                                        <img key={i} src={estrella} alt="⭐" className="estrella" />
                                    ))}
                                </div>
                                <p>Fecha: <span className="fecha">{resena.fechaFormateada}</span></p>
                            </div>

                            <div className="resena-acciones-grid">
                                {resena.nombreUsuario === "Usuario eliminado" ? (
                                    // Para usuarios eliminados
                                    isAdmin && (
                                        <>
                                            <div className="accion-item">
                                                <button className="resena-boton-eliminar" onClick={() => confirmDelete(resena._id)}>
                                                    Eliminar
                                                </button>
                                            </div>
                                            <div className="accion-item">
                                                <label htmlFor={`estado-${resena._id}`} id='estado-label'>Estado:</label>
                                                <select 
                                                    className='select-estado' 
                                                    id={`estado-${resena._id}`} 
                                                    onChange={(e) => cambiarEstado(resena._id, e.target.value)} 
                                                    value={resena.aprobado}
                                                >
                                                    <option value="por aprobar">Por aprobar</option>
                                                    <option value="aprobado">Aprobado</option>
                                                    <option value="cancelado">Cancelado</option>
                                                </select>
                                            </div>
                                        </>
                                    )
                                ) : (
                                    // Para usuarios normales
                                    <>
                                        {isAdmin && (
                                            <div className="accion-item">
                                                <label htmlFor={`estado-${resena._id}`} id='estado-label'>Estado:</label>
                                                <select 
                                                    className='select-estado' 
                                                    id={`estado-${resena._id}`} 
                                                    onChange={(e) => cambiarEstado(resena._id, e.target.value)} 
                                                    value={resena.aprobado}
                                                >
                                                    <option value="por aprobar">Por aprobar</option>
                                                    <option value="aprobado">Aprobado</option>
                                                    <option value="cancelado">Cancelado</option>
                                                </select>
                                            </div>
                                        )}

                                        {(isAdmin || comprobarID(resena)) && (
                                            <div className="accion-item">
                                                <button className="resena-boton-eliminar" onClick={() => confirmDelete(resena._id)}>
                                                    Eliminar
                                                </button>
                                            </div>
                                        )}

                                        {isAdmin && !comprobarID(resena) && (
                                            <div className="accion-item">
                                                <button
                                                    className='resena-boton-bloquear'
                                                    onClick={() => navigate(`/api/bloquear/${getClienteId(resena.clienteId)}`)}
                                                >
                                                    {estaBloqueado(resena.clienteId) ? 'Desbloquear' : 'Bloquear'}
                                                </button>
                                            </div>
                                        )}

                                        {comprobarID(resena) && (
                                            <div className="accion-item">
                                                <button 
                                                    onClick={() => navigate(`/api/resenas/editar/${resena._id}`)} 
                                                    className="resena-boton-editar"
                                                >
                                                    Editar
                                                </button>
                                            </div>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <div className="r-nuevo-volver">
                <button className="boton-nuevo" onClick={() => navigate('/api/resenas/nueva')}>Crear Reseña</button>
                <button className="boton-volver" onClick={()=> navigate("/api/")}>Volver</button>
            </div>

            {isAdmin && (
                <div>
                    <button onClick={mostrarEstadisticas} className='boton-estadisticas'>Estadísticas</button>
                    <div id="statsModal" className="modal">
                        <div className="modal-content">
                            <span className="close" onClick={cerrarEstadisticas}>&times;</span>
                            <h2>Estadísticas de Reseñas</h2>
                            <p>Total de reseñas: <span id="totalResenas"></span></p>
                            <p>Nota media: <span id="notaMedia"></span></p>
                            <p>Votos 1 estrella: <span id="voto1"></span></p>
                            <p>Votos 2 estrellas: <span id="voto2"></span></p>
                            <p>Votos 3 estrellas: <span id="voto3"></span></p>
                            <p>Votos 4 estrellas: <span id="voto4"></span></p>
                            <p>Votos 5 estrellas: <span id="voto5"></span></p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Resenas;