import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import estrella from '../../../assets/Imagenes/estrella.png';
import estrella_vacia from '../../../assets/Imagenes/estrella_vacia.png';
import '../../../css/resenas/R-Crear.css';
import storage from "../../../Storage/storage";

const BASE_URL = "http://localhost:3016";

const CrearResena = () => {
  const [estrellas, setEstrellas] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [resenaText, setResenaText] = useState('');
  const [formModified, setFormModified] = useState(false);

  useEffect(() => {
    if (resenaText !== '' || estrellas > 0) {
      setFormModified(true);
    } else {
      setFormModified(false);
    }
  }, [resenaText, estrellas]);

  const handleStarClick = (rating) => {
    setEstrellas(rating);
  };

  const handleResenaChange = (e) => {
    setResenaText(e.target.value);
  };

  const handleBack = () => {
    if (formModified) {
      Swal.fire({
        title: '¿Estás seguro?',
        text: 'Los cambios que has realizado se perderán si vuelves atrás.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, volver',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: 'custom-popup',
          title: 'custom-title',
          content: 'custom-content',
          confirmButton: 'custom-confirm-button',
          cancelButton: 'custom-cancel-button',
        },
      }).then((result) => {
        if (result.isConfirmed) {
          window.history.back();
        }
      });
    } else {
      window.history.back();
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const resena = resenaText;
    const token = localStorage.getItem('authToken');
    
    try {
        const response = await fetch(`${BASE_URL}/api/resenas/nueva`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ resena, estrellas }),
        });

        if (response.ok) {
            Swal.fire({
                title: 'Éxito',
                text: 'Reseña creada exitosamente',
                icon: 'success',
                customClass: {
                    popup: 'custom-popup',
                    title: 'custom-title',
                    content: 'custom-content',
                    confirmButton: 'custom-confirm-button',
                },
            }).then(() => {
              window.history.back();
            });
        } else {
            Swal.fire({
                title: 'Error',
                text: 'Debes de poner una puntuación',
                icon: 'error',
                customClass: {
                    popup: 'custom-popup',
                    title: 'custom-title',
                    content: 'custom-content',
                    confirmButton: 'custom-confirm-button',
                },
            });
        }
    } catch (error) {
        Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al conectar con el servidor',
            icon: 'error',
            customClass: {
                popup: 'custom-popup',
                title: 'custom-title',
                content: 'custom-content',
                confirmButton: 'custom-confirm-button',
            },
        });
    }
  };

  return (
    <div className="crear-resena-container">
      <div className="crear-resena-content">
        <form className="crear-resena-form" onSubmit={handleSubmit}>
          <div>
            <label className="crear-resena-label" htmlFor="resena">Reseña:</label>
            <br/>
            <textarea
              id="resena"
              name="resena"
              className="crear-resena-textarea"
              required
              tabIndex="1"
              value={resenaText}
              onChange={handleResenaChange}
            ></textarea>
          </div>
          <div>
            <label className="crear-resena-label" htmlFor="estrellas">Estrellas:</label>
            <div className="crear-resena-stars">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className="crear-resena-star"
                  onClick={() => handleStarClick(star)}
                  onMouseEnter={() => setHoveredStar(star)}
                  onMouseLeave={() => setHoveredStar(0)}
                >
                  <img
                    src={star <= (hoveredStar || estrellas) ? estrella : estrella_vacia}
                    alt={`Star ${star}`}
                  />
                </span>
              ))}
            </div>
          </div>
          <p className='resena-texto'>Ten en cuenta que primero se debe aprobar tu reseña para que se pueda visualizar en la página.</p>
          <button type="submit" className="crear-resena-button">Crear Reseña</button>
          <button type="button" className="crear-resena-button" onClick={handleBack}>Volver</button>
        </form>
      </div>
    </div>
  );
};

export default CrearResena;