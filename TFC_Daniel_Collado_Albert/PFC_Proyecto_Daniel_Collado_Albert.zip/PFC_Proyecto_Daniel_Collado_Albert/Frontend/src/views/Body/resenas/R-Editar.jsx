import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import "../../../css/base/sweetAlert.css";
import estrella from '../../../assets/Imagenes/estrella.png';
import estrella_vacia from '../../../assets/Imagenes/estrella_vacia.png';
import '../../../css/resenas/R-Editar.css'; 

const BASE_URL = "http://localhost:3016";

const EditarResena = () => {
  const { id } = useParams(); 
  const navigate = useNavigate();
  const [resena, setResena] = useState('');
  const [estrellas, setEstrellas] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [aprobado, setAprobado] = useState('');
  const [originalResena, setOriginalResena] = useState('');
  const [originalEstrellas, setOriginalEstrellas] = useState(0);

  useEffect(() => {
    const fetchResena = async () => {
      try {
        const response = await fetch(`${BASE_URL}/api/resenas/editar/${id}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken')}`
          }
        });
        if (response.ok) {
          const data = await response.json();
          setResena(data.resena.resena);
          setEstrellas(data.resena.estrellas);
          setAprobado(data.resena.aprobado);
          setOriginalResena(data.resena.resena);
          setOriginalEstrellas(data.resena.estrellas);
        } else {
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al cargar la reseña',
            icon: 'error',
            customClass: {
              popup: 'custom-popup',
              title: 'custom-title',
              content: 'custom-content',
              confirmButton: 'custom-confirm-button',
            },
          });
        }
      } catch (error) {
        Swal.fire({
          title: 'Error',
          text: 'Hubo un problema al conectar con el servidor',
          icon: 'error',
          customClass: {
            popup: 'custom-popup',
            title: 'custom-title',
            content: 'custom-content',
            confirmButton: 'custom-confirm-button',
          },
        });
      }
    };
    fetchResena();
  }, [id]);

  const handleStarClick = (rating) => {
    setEstrellas(rating);
    if (rating !== originalEstrellas) setAprobado("por aprobar");
  };

  const handleChange = (e) => {
    setResena(e.target.value);
    if (e.target.value !== originalResena) setAprobado("por aprobar");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('authToken');

    try {
      const response = await fetch(`${BASE_URL}/api/resenas/editar/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ resena, estrellas, aprobado }),
      });

      const data = await response.json();

      if (response.ok) {
        Swal.fire({
          title: 'Éxito',
          text: data.mensaje || 'Reseña editada exitosamente',
          icon: 'success',
          customClass: {
            popup: 'custom-popup',
            title: 'custom-title',
            content: 'custom-content',
            confirmButton: 'custom-confirm-button',
          },
        }).then(() => {
          window.history.back();
        });
      } else {
        Swal.fire({
          title: 'Error',
          text: data.mensaje || 'Hubo un problema al editar la reseña',
          icon: 'error',
          customClass: {
            popup: 'custom-popup',
            title: 'custom-title',
            content: 'custom-content',
            confirmButton: 'custom-confirm-button',
          },
        });
      }
    } catch (error) {
      Swal.fire({
        title: 'Error',
        text: 'Hubo un problema al conectar con el servidor',
        icon: 'error',
        customClass: {
          popup: 'custom-popup',
          title: 'custom-title',
          content: 'custom-content',
          confirmButton: 'custom-confirm-button',
        },
      });
    }
  };

  const handleVolver = () => {
    if (resena !== originalResena || estrellas !== originalEstrellas) {
      Swal.fire({
        title: "¿Estás seguro de que quieres salir?",
        text: "Los cambios no se guardarán.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, volver',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: 'custom-popup',
          title: 'custom-title',
          content: 'custom-content',
          confirmButton: 'custom-confirm-button',
          cancelButton: 'custom-cancel-button',
        },
      }).then((result) => {
        if (result.isConfirmed) {
          window.history.back();
        }
      });
    } else {
      window.history.back();
    }
  };

  return (
    <div className="editar-resena-container">
      <div className="editar-resena-content">
        <h1 className='resena-titulo'>Editar Reseña</h1>
        <form className="editar-resena-form" onSubmit={handleSubmit}>
          <div>
            <label className="editar-resena-label" htmlFor="resena">Reseña:</label>
            <br/>
            <textarea
              id="resena"
              name="resena"
              className="editar-resena-textarea"
              value={resena}
              onChange={handleChange}
              required
              tabIndex="1"
            ></textarea>
          </div>
          <div>
            <label className="editar-resena-label" htmlFor="estrellas">Estrellas:</label>
            <div className="editar-resena-stars">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className="editar-resena-star"
                  onClick={() => handleStarClick(star)}
                  onMouseEnter={() => setHoveredStar(star)}
                  onMouseLeave={() => setHoveredStar(0)}
                >
                  <img
                    src={star <= (hoveredStar || estrellas) ? estrella : estrella_vacia}
                    alt={`Star ${star}`}
                  />
                </span>
              ))}
            </div>
          </div>

          <p className='resena-texto'>Ten en cuenta que al editar se debe volver a aprobar tu reseña para que se pueda visualizar en la página.</p>

          <button type="submit" className="editar-resena-button">Guardar Cambios</button>
          <button type="button" className="editar-resena-button" onClick={handleVolver}>Volver</button>
        </form>
      </div>
    </div>
  );
};

export default EditarResena;
