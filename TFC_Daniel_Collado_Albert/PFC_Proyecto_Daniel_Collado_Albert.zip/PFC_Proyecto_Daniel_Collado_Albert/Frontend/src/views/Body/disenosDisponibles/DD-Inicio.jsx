import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import "../../../css/disenosDisponibles/DD-Inicio.css";
import "../../../css/base/sweetAlert.css";
import imagenError from "../../../assets/Imagenes/error-imagen.png";
import imagenErrorBlanco from "../../../assets/Imagenes/error-imagen-blanco.png";

const BASE_URL = "http://localhost:3016";

const DisenosDisponibles = () => {
  const navigate = useNavigate();
  const [disenos, setDisenos] = useState([]);
  const [authUser, setAuthUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const isTokenExpired = (token) => {
    try {

      if (!token || token.split('.').length !== 3) {
        throw new Error("Token no tiene el formato JWT válido.");
      }

      const payloadEncoded = token.split('.')[1];
      const payloadDecoded = atob(payloadEncoded);
      const payload = JSON.parse(payloadDecoded);

      return payload.exp * 1000 < Date.now();
    } catch (error) {
      console.error("Error al procesar el token:", error.message);
      return true;
    }
  };

  useEffect(() => {
    const storedUser = localStorage.getItem("authUser");
    const storedToken = localStorage.getItem("authToken");

    if (storedUser && storedToken && !isTokenExpired(storedToken)) {
      setAuthUser(JSON.parse(storedUser));
      fetchDisenos(storedToken);
    } else {
      console.error("Token inválido o caducado");
      localStorage.removeItem("authToken");
      localStorage.removeItem("authUser");
      navigate('/api/iniciarSesion'); 
    }
  }, [navigate]);

  const fetchDisenos = async (token) => {
    try {
      setLoading(true);
      const response = await fetch(`${BASE_URL}/api/disenosDisponibles`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          console.error("Token inválido o caducado");
          localStorage.removeItem("authToken");
          localStorage.removeItem("authUser");
          navigate('/api/iniciarSesion');
        } else {
          const errorMsg = await response.text();
          throw new Error(`Error en la solicitud: ${errorMsg}`);
        }
      }

      const data = await response.json();
      setDisenos(data.disenos);
    } catch (error) {
      console.error('Error fetching diseños:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("authToken");
      if (!token) {
        console.error("No se encontró el token");
        return;
      }

      const response = await fetch(`${BASE_URL}/api/disenosDisponibles/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorMsg = await response.text();
        throw new Error(`Error eliminando el diseño: ${errorMsg}`);
      }

      setDisenos(disenos.filter(diseno => diseno._id !== id));
      Swal.fire({
        title: 'Éxito',
        text: 'El diseño ha sido eliminado correctamente.',
        icon: 'success',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    } catch (error) {
      console.error('Error eliminando el diseño:', error);
      Swal.fire({
        title: 'Error',
        text: 'No se pudo eliminar el diseño.',
        icon: 'error',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    }
  };

  const confirmDelete = (id) => {
    Swal.fire({
      title: '¿Quieres eliminar este diseño?',
      text: "Esta acción no se puede deshacer.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      customClass: {
        popup: "custom-popup",
        title: "custom-title",
        content: "custom-content",
        confirmButton: "custom-confirm-button",
        cancelButton: "custom-confirm-button",
      },
    }).then((result) => {
      if (result.isConfirmed) {
        handleDelete(id);
      }
    });
  };

  const isAdmin = authUser?.profile === "ADMIN";

const handleReserve = (diseno) => {
  const preloadedData = {
    descripcion: diseno.descripcion,
    tamano: diseno.tamano,
    foto: `${BASE_URL}${diseno.foto}`,
    disenoId: diseno._id,
    tiempoEstimado: diseno.tiempoEstimado || 'No especificado',
    precio: diseno.precio || 0,
    precioExclusivo: diseno.precioExclusivo || 0,
    yaRealizado: diseno.yaRealizado,
  };

  navigate('/api/citas/nueva', { state: { preloadedData } });
};
  if (loading) {
    return <div className="diseno-vacio"><h2>Cargando diseños...</h2></div>;
  }

  const disponibles = disenos.filter(diseno => diseno.disponible !== false);
  const noDisponibles = disenos.filter(diseno => diseno.disponible === false);

  return (
    <div>
      <h1 className='titulo-resenas'>Diseños disponibles</h1>
      {isAdmin && disponibles.length > 0 && (
        <div>
          <h2 className='dd-titulo-inicio'><u>Disponibles</u></h2>
          <div className="disenos-lista">
            {disponibles.map((diseno) => (
              <div key={diseno._id} className="diseno-item">
                <img
                  src={diseno.foto?.startsWith("http") ? diseno.foto : `${BASE_URL}${diseno.foto}`}
                  alt={`Imagen del diseño: ${diseno.titulo}`}
                  className="diseno-img"
                  onError={(e) => (e.target.src = imagenError)}
                />
                <div className="info-contenedor">
                  <h3>{diseno.titulo}</h3>
                  <p><strong>Descripción:</strong> {diseno.descripcion}</p>
                  <p><strong>Tamaño:</strong> {diseno.tamano}</p>
                  <p><strong>Estilo:</strong> {diseno.tipo || 'No especificado'}</p>
                  <p><strong>Fecha:</strong> {
                    diseno.fecha
                      ? new Date(diseno.fecha).toLocaleDateString('es-ES')
                      : new Date().toLocaleDateString('es-ES')
                  }</p>
                  <p><strong>Tiempo estimado:</strong> {diseno.tiempoEstimado || 'No especificado'}</p>
                  <p><strong>Precio:</strong> {diseno.precio || 'No especificado'} €</p>
                  <p><strong>Precio exclusivo:</strong> {diseno.precioExclusivo || 'No especificado'} €</p>

                  {isAdmin && (
                    <div className="diseno-botones-contenedor">
                      <div className="diseno-editar-eliminar">
                        <button
                          className="diseno-boton-editar"
                          onClick={() => navigate(`/api/disenosDisponibles/editar/${diseno._id}`)}
                        >
                          Editar
                        </button>

                        <button
                          className="diseno-boton-eliminar"
                          onClick={() => confirmDelete(diseno._id)}
                        >
                          Eliminar
                        </button>
                      </div>
                    </div>
                  )}

                  <button
                    className="diseno-boton-reservar"
                    onClick={() => handleReserve(diseno)}
                  >
                    Reservar Tatuaje
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {isAdmin && noDisponibles.length > 0 && (
        <div>
          
          <h2 className='dd-titulo-inicio'><u>Diseño realizado o reservado</u></h2>
          <div className="disenos-lista">
            {noDisponibles.map((diseno) => (
              <div key={diseno._id} className="diseno-item">
                <img
                 src={diseno.foto?.startsWith("http") ? diseno.foto : `${BASE_URL}${diseno.foto}`}
                  alt={`Imagen del diseño: ${diseno.titulo}`}
                  className="diseno-img"
                  onError={(e) => (e.target.src = imagenError)}
                />
                <div className="info-contenedor">
                  <h3>{diseno.titulo}</h3>
                  <p><strong>Descripción:</strong> {diseno.descripcion}</p>
                  <p><strong>Tamaño:</strong> {diseno.tamano}</p>
                  <p><strong>Estilo:</strong> {diseno.tipo || 'No especificado'}</p>
                  <p><strong>Fecha:</strong> {
                    diseno.fecha
                      ? new Date(diseno.fecha).toLocaleDateString('es-ES')
                      : new Date().toLocaleDateString('es-ES')
                  }</p>
                  <p><strong>Tiempo estimado:</strong> {diseno.tiempoEstimado || 'No especificado'}</p>
                  <p><strong>Precio:</strong> {diseno.precio || 'No especificado'} €</p>
                   <p><strong>Precio exclusivo:</strong> {diseno.precioExclusivo || 'No especificado'} €</p>

                  {isAdmin && (
                    <div className="diseno-botones-contenedor">
                      <div className="diseno-editar-eliminar">
                        <button
                          className="diseno-boton-editar"
                          onClick={() => navigate(`/api/disenosDisponibles/editar/${diseno._id}`)}
                        >
                          Editar
                        </button>

                        <button
                          className="diseno-boton-eliminar"
                          onClick={() => confirmDelete(diseno._id)}
                        >
                          Eliminar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!isAdmin && disponibles.length > 0 && (
        <div className="disenos-lista">
          {disponibles.map((diseno) => (
            <div key={diseno._id} className="diseno-item">
              <img
                src={diseno.foto?.startsWith("http") ? diseno.foto : `${BASE_URL}${diseno.foto}`}
                alt={`Imagen del diseño: ${diseno.titulo}`}
                className="diseno-img"
                onError={(e) => (e.target.src = imagenError)}
              />
              <div className="info-contenedor">
                <h3>{diseno.titulo}</h3>
                <p><strong>Descripción:</strong> {diseno.descripcion}</p>
                <p><strong>Tamaño:</strong> {diseno.tamano}</p>
                <p><strong>Estilo:</strong> {diseno.tipo || 'No especificado'}</p>
                <p><strong>Fecha:</strong> {
                  diseno.fecha
                    ? new Date(diseno.fecha).toLocaleDateString('es-ES')
                    : new Date().toLocaleDateString('es-ES')
                }</p>
                <p><strong>Tiempo estimado:</strong> {diseno.tiempoEstimado || 'No especificado'}</p>
                <p><strong>Precio:</strong> {diseno.precio || 'No especificado'} €</p>
                 <p><strong>Precio exclusivo:</strong> {diseno.precioExclusivo || 'No especificado'} €</p>

                <button
                  className="diseno-boton-reservar"
                  onClick={() => handleReserve(diseno)}
                >
                  Reservar Tatuaje
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {(isAdmin ? disenos.length === 0 : disponibles.length === 0) && (
        <div className="diseno-vacio" id='dd-vacio'>
          <img src={imagenErrorBlanco} alt="No hay diseños" className="diseno-vacio-img" />
          <h2>No hay diseños disponibles.</h2>
        </div>
      )}
      <div className="nuevo-volver">
        {isAdmin && (
          <button className="boton-nuevo" onClick={() => navigate('/api/disenosDisponibles/nuevo')}>
            Añadir nuevo diseño
          </button>
        )}
        <button className="boton-volver" onClick={() => navigate('/')}>
          Volver
        </button>
      </div>
    </div>
  );
};

export default DisenosDisponibles;