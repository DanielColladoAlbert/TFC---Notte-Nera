import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";
import "../../../css/disenosDisponibles/DD-Editar.css";
import "../../../css/base/sweetAlert.css";
import axios from "axios";

const BASE_URL = "http://localhost:3016";

const EditarDiseno = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    foto: null,
    titulo: "",
    descripcion: "",
    tamano: "",
    tipo: "",
    precio: "",
    tiempoEstimado: "",
    disponible: false,
    precioExclusivo: 0,
    yaRealizado: false,
  });

  const [initialData, setInitialData] = useState(null);
  const [originalFoto, setOriginalFoto] = useState("");
  const [loading, setLoading] = useState(true);
  const [preview, setPreview] = useState("");

  useEffect(() => {
    const fetchDiseno = async () => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        Swal.fire({
          title: "Error",
          text: "No se proporcionó un token. Por favor, inicia sesión nuevamente.",
          icon: "error",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        navigate("/login");
        return;
      }

      try {
        const response = await axios.get(`${BASE_URL}/api/disenosDisponibles/editar/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const data = response.data.diseno;

        if (!data) throw new Error("No se pudo obtener el diseño.");

        const parsedData = {
          foto: null,
          titulo: data.titulo || "",
          descripcion: data.descripcion || "",
          tamano: data.tamano || "",
          tipo: data.tipo || "",
          precio: data.precio || "",
          tiempoEstimado: data.tiempoEstimado || "",
          disponible: typeof data.disponible === "boolean" ? data.disponible : false,
          precioExclusivo: data.precioExclusivo || 0,
          yaRealizado: typeof data.yaRealizado === "boolean" ? data.yaRealizado : false,
        };

        setFormData(parsedData);
        setInitialData({ ...parsedData });
        if (data.foto) {
          setOriginalFoto(`${BASE_URL}${data.foto}`);
        }
      } catch (error) {
        console.error("Error al obtener los datos:", error);
        Swal.fire({
          title: "Error",
          text: error.message,
          icon: "error",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        navigate("/apì/");
      } finally {
        setLoading(false);
      }
    };

    fetchDiseno();
  }, [id, navigate]);

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (name === "foto") {
      const file = files[0];
      if (file && /\.(jpe?g|png|gif)$/i.test(file.name)) {
        setFormData((prev) => ({ ...prev, foto: file }));
        const reader = new FileReader();
        reader.onload = () => setPreview(reader.result);
        reader.readAsDataURL(file);
      } else {
        Swal.fire({
          title: "Formato inválido",
          text: "Solo se permiten imágenes JPEG, JPG, PNG o GIF.",
          icon: "error",
          confirmButtonText: "Entendido",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
      }
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: type === "checkbox" ? checked : value,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("authToken");

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (key === "foto" && !value && originalFoto) {
        // Si no hay nueva foto, enviar la ruta original
        data.append("foto", originalFoto.replace(BASE_URL, ""));
      } else if (value !== null) {
        data.append(key, value);
      }
    });

    try {
      await axios.patch(`${BASE_URL}/api/disenosDisponibles/editar/${id}`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      Swal.fire({
        title: "Éxito",
        text: "Los cambios se han guardado correctamente.",
        icon: "success",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      navigate(-1);
    } catch (error) {
      console.error(error);
      Swal.fire({
        title: "Error",
        text: "No se pudo guardar los cambios.",
        icon: "error",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  const hayCambios = () => {
    const { foto, ...actual } = formData;
    const { foto: _, ...inicial } = initialData || {};
    return JSON.stringify(actual) !== JSON.stringify(inicial);
  };

  if (loading) {
    return <div className="editar-diseno-container">Cargando...</div>;
  }

  return (
    <div className="editar-diseno-container">
      <div className="editar-diseno-content">
        <form onSubmit={handleSubmit} encType="multipart/form-data" className="editar-diseno-form">
          <div className="editar-diseno-left-column">
            <div>
              <label htmlFor="foto" className="editar-diseno-label">Foto:</label>
              <input
                type="file"
                id="foto"
                name="foto"
                accept="image/jpeg, image/jpg, image/png, image/gif"
                onChange={handleChange}
                className="editar-diseno-file"
                tabIndex="1"
              />
              {(preview || originalFoto) && (
                <div className="imagen-previa" style={{ marginTop: "10px" }}>
                  <p>Foto actual:</p>
                  <img
                    src={preview || originalFoto}
                    alt="Vista previa"
                    width="150"
                    height="150"
                    className="editar-diseno-imagen-previa"
                  />
                </div>
              )}
            </div>
          </div>
          <div className="editar-diseno-right-column">
            <div>
              <label htmlFor="titulo" className="editar-diseno-label">Título:</label>
              <input
                type="text"
                id="titulo"
                name="titulo"
                value={formData.titulo}
                onChange={handleChange}
                required
                className="editar-diseno-input"
                tabIndex="2"
              />
            </div>
            <div>
              <label htmlFor="descripcion" className="editar-diseno-label">Descripción:</label>
              <textarea
                id="descripcion"
                name="descripcion"
                value={formData.descripcion}
                onChange={handleChange}
                required
                className="editar-diseno-textarea"
                tabIndex="3"
              ></textarea>
            </div>
            <div>
              <label htmlFor="tamano" className="editar-diseno-label">Tamaño:</label>
              <input
                type="text"
                id="tamano"
                name="tamano"
                value={formData.tamano}
                onChange={handleChange}
                required
                className="editar-diseno-input"
                tabIndex="4"
              />
            </div>
            <div>
              <label htmlFor="tipo" className="editar-diseno-label">Estilo:</label>
              <input
                type="text"
                id="tipo"
                name="tipo"
                value={formData.tipo}
                onChange={handleChange}
                className="editar-diseno-input"
                tabIndex="5"
              />
            </div>
            <div>
              <label htmlFor="precio" className="editar-diseno-label">Precio:</label>
              <input
                type="number"
                min={0}
                id="precio"
                name="precio"
                value={formData.precio}
                onChange={handleChange}
                className="editar-diseno-input"
                tabIndex="6"
              />
            </div>
            <div>
              <label htmlFor="tiempoEstimado" className="editar-diseno-label">Tiempo Estimado:</label>
              <input
                type="text"
                id="tiempoEstimado"
                name="tiempoEstimado"
                value={formData.tiempoEstimado}
                onChange={handleChange}
                className="editar-diseno-input"
                tabIndex="7"
              />
            </div>
            <div>
              <label htmlFor="precioExclusivo" className="editar-diseno-label">Precio extra si es exclusivo:</label>
              <input
                type="number"
                min={0}
                name="precioExclusivo"
                value={formData.precioExclusivo}
                onChange={(e) =>
                setFormData(prev => ({
                  ...prev,
                  precioExclusivo: e.target.valueAsNumber,
                }))
              }
                className="editar-diseno-input"
                tabIndex="8"
                
              />
            </div>
            {/* Contenedor para los checkboxes lado a lado */}
            <div className="checkbox-container">
              <div className="checkbox-field">
                <label htmlFor="disponible" className="editar-diseno-label">Disponible:</label>
                <input
                  type="checkbox"
                  id="disponible"
                  name="disponible"
                  checked={formData.disponible}
                  onChange={handleChange}
                  tabIndex="9"
                />
              </div>
              <div className="checkbox-field">
                <label htmlFor="yaRealizado" className="editar-diseno-label">¿Ha sido el tatuaje ya realizado?:</label>
                <input
                  type="checkbox"
                  id="yaRealizado"
                  name="yaRealizado"
                  checked={formData.yaRealizado}
                  onChange={handleChange}
                  tabIndex="10"
                />
              </div>
            </div>
          </div>
        </form>
        <div className="nuevo-volver-diseno-editar">
          <button onClick={handleSubmit} className="editar-diseno-button">Guardar Cambios</button>
          <button
            type="button"
            onClick={() => {
              if (!hayCambios()) {
                navigate(-1);
              } else {
                Swal.fire({
                  title: "¿Estás seguro de que quieres salir?",
                  text: "Los cambios no se guardarán.",
                  icon: "warning",
                  showCancelButton: true,
                  confirmButtonText: "Sí, volver",
                  cancelButtonText: "Cancelar",
                  customClass: {
                    popup: "custom-popup",
                    title: "custom-title",
                    content: "custom-content",
                    confirmButton: "custom-confirm-button",
                    cancelButton: "custom-cancel-button",
                  },
                }).then((result) => {
                  if (result.isConfirmed) {
                    navigate(-1);
                  }
                });
              }
            }}
            className="editar-diseno-button"
          >
            Volver
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditarDiseno;