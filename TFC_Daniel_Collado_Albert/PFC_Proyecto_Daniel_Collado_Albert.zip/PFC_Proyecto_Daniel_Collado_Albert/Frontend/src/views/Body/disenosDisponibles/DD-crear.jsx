import { useState } from 'react';
import '../../../css/disenosDisponibles/DD-crear.css';
import Swal from 'sweetalert2';
import "../../../css/base/sweetAlert.css";
import { useNavigate } from 'react-router-dom';

const BASE_URL = "http://localhost:3016";

export default function CrearDiseno() {
  const [foto, setFoto] = useState(null);
  const [fotoPreview, setFotoPreview] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    descripcion: '',
    tamano: '',
    tipo: '',
    precio: '',
    tiempoEstimado: '',
    precioExclusivo: '',
  });
  const [initialFormData, setInitialFormData] = useState({
    titulo: '',
    descripcion: '',
    tamano: '',
    tipo: '',
    precio: '',
    tiempoEstimado: '',
    precioExclusivo: '',
  });
  const navigate = useNavigate();

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const imageRegex = /\.(jpe?g|png|gif)$/i;

    if (file && !imageRegex.test(file.name)) {
      Swal.fire({
        icon: 'error',
        title: 'Extensión no permitida',
        text: 'Solo se permiten imágenes con las extensiones JPEG, JPG, PNG o GIF.',
        customClass: {
          popup: 'custom-popup',
          title: 'custom-title',
          content: 'custom-content',
          confirmButton: 'custom-confirm-button',
        },
      });
      setFoto(null);
      setFotoPreview(null);
    } else {
      setFoto(file);
      setFotoPreview(URL.createObjectURL(file));
      setFormData((prev) => ({ ...prev, foto: file }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const imageRegex = /\.(jpe?g|png|gif)$/i;
    if (foto && !imageRegex.test(foto.name)) {
      Swal.fire({
        icon: 'error',
        title: 'Extensión no permitida',
        text: 'Solo se permiten imágenes con las extensiones JPEG, JPG, PNG o GIF.',
        customClass: {
          popup: 'custom-popup',
          title: 'custom-title',
          content: 'custom-content',
          confirmButton: 'custom-confirm-button',
        },
      });
      return;
    }

    const submitData = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (value !== null) submitData.append(key, value);
    });

    const token = localStorage.getItem('authToken');

    try {
      const response = await fetch(`${BASE_URL}/api/disenosDisponibles/nuevo`, {
        method: "POST",
        body: submitData,
        credentials: "include",
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.error || "No se pudo crear el diseño.");
      }

      Swal.fire({
        icon: "success",
        title: "Diseño creado",
        text: "El diseño se ha creado correctamente.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      navigate(-1);
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error.message,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  const hasChanges = () => {
    return Object.keys(initialFormData).some((key) => {
      if (key === 'foto') return false; // ignorar foto
      return initialFormData[key] !== formData[key];
    });
  };

const handleBack = async (e) => {
  e.preventDefault();

  if (!hasChanges()) {
    navigate(-1);
    return;
  }

  const result = await Swal.fire({
    title: '¿De verdad quieres volver?',
    text: 'No se guardarán los cambios realizados.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Sí, volver',
    cancelButtonText: 'Cancelar',
    customClass: {
      popup: "custom-popup",
      title: "custom-title",
      content: "custom-content",
      confirmButton: "custom-confirm-button",
      cancelButton: "custom-confirm-button",
    }
  });

  if (result.isConfirmed) {
    navigate(-1);
  }
};

  return (
    <div className="crear-diseno-container">
      <div className="crear-diseno-content">
        <form
          onSubmit={handleSubmit}
          className="crear-diseno-form"
          encType="multipart/form-data"
        >
          <div className="crear-diseno-left-column">
            <label htmlFor="foto" className="crear-diseno-label">Foto del Diseño:</label>
            <input
              type="file"
              id="foto"
              name="foto"
              accept="image/jpeg, image/jpg, image/png, image/gif"
              onChange={handleFileChange}
              required
              className="crear-diseno-file"
              tabIndex="1"
            />
            {fotoPreview && (
              <div className="imagen-previa">
                <p>Imagen previa:</p>
                <img
                  src={fotoPreview}
                  alt="Imagen previa"
                  className="crear-diseno-imagen-previa"
                />
              </div>
            )}
          </div>

          <div className="crear-diseno-right-column">
            <label htmlFor="titulo" className="crear-diseno-label">Título:</label>
            <input
              type="text"
              id="titulo"
              name="titulo"
              value={formData.titulo}
              onChange={handleInputChange}
              required
              className="crear-diseno-input"
               tabIndex="1"
            />

            <label htmlFor="descripcion" className="crear-diseno-label">Descripción:</label>
            <textarea
              id="descripcion"
              name="descripcion"
              value={formData.descripcion}
              onChange={handleInputChange}
              required
              className="crear-diseno-textarea"
               tabIndex="2"
            ></textarea>

            <label htmlFor="tamano" className="crear-diseno-label">Tamaño:</label>
            <input
              type="text"
              id="tamano"
              name="tamano"
              value={formData.tamano}
              onChange={handleInputChange}
              required
              className="crear-diseno-input"
               tabIndex="3"
            />

            <label htmlFor="tipo" className="crear-diseno-label">Estilo:</label>
            <input
              type="text"
              id="tipo"
              name="tipo"
              value={formData.tipo}
              onChange={handleInputChange}
              className="crear-diseno-input"
               tabIndex="4"
            />

            <label htmlFor="precio" className="crear-diseno-label">Precio:</label>
            <input
              type="number"
              id="precio"
              name="precio"
              value={formData.precio}
              onChange={handleInputChange}
              className="crear-diseno-input"
              tabIndex="5"
              min={0}
            />

            <label htmlFor="tiempoEstimado" className="crear-diseno-label">Tiempo Estimado:</label>
            <input
              type="text"
              id="tiempoEstimado"
              name="tiempoEstimado"
              value={formData.tiempoEstimado}
              onChange={handleInputChange}
              className="crear-diseno-input"
               tabIndex="6"
            />

            <label htmlFor="precioExclusivo" className="crear-diseno-label">Precio extra si es exclusivo:</label>
            <input
              type="number"
              id="precioExclusivo-dd"
              name="precioExclusivo"
              value={formData.precioExclusivo}
              onChange={handleInputChange}
              className="crear-diseno-input"
              tabIndex="7"
              min={0}/>
          </div>
          
        </form>
        <div className="nuevo-volver-diseno">
            <button onClick={handleSubmit} className="crear-diseno-button">Crear Diseño</button>
            <button type="button" className="crear-diseno-button" onClick={handleBack}>
            Volver
          </button>
        </div>
      </div>
    </div>
  );
}