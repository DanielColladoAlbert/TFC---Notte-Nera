import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import "../../../css/base/sweetAlert.css";
import '../../../css/PanelAdmin/PA-Bloquear.css';

const BASE_URL = "http://localhost:3016";

const PABloquear = () => {
  const { id } = useParams(); 
  const [user, setUser] = useState(null);
  const [motivoBloqueo, setMotivoBloqueo] = useState('');
  const [initialMotivoBloqueo, setInitialMotivoBloqueo] = useState('');
  const [formModified, setFormModified] = useState(false);

  useEffect(() => {
    if (!id) {
      console.error('id is undefined');
      return;
    }

    const fetchUserData = async () => {
      try {
        const response = await fetch(`${BASE_URL}/api/bloquear/${id}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);

          setInitialMotivoBloqueo('');
        } else {
          const errorData = await response.json();
          Swal.fire({
            title: 'Error',
            text: errorData.message || 'Ocurrió un error al obtener la información del usuario',
            icon: 'error',
            customClass: {
              popup: "custom-popup",
              title: "custom-title",
              content: "custom-content",
              confirmButton: "custom-confirm-button",
            },
          });
        }
      } catch (error) {
        Swal.fire({
          title: 'Error',
          text: 'No se pudo completar la solicitud para obtener la información del usuario',
          icon: 'error',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
      }
    };

    fetchUserData();
  }, [id]);

  // Detectar cambios en el formulario
  useEffect(() => {
  
    if (!user?.bloqueado && motivoBloqueo !== initialMotivoBloqueo) {
      setFormModified(true);
    } else {
      setFormModified(false);
    }
  }, [motivoBloqueo, initialMotivoBloqueo, user]);

  const handleMotivoChange = (e) => {
    setMotivoBloqueo(e.target.value);
  };

  const handleBack = () => {
    if (formModified) {
      Swal.fire({
        title: '¿Estás seguro?',
        text: 'Los cambios que has realizado se perderán si vuelves atrás.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, volver',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-cancel-button",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          window.history.back();
        }
      });
    } else {
      window.history.back();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!user.bloqueado && !motivoBloqueo.trim()) {
      return Swal.fire({
        title: 'Error',
        text: 'Debe ingresar un motivo de bloqueo',
        icon: 'error',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }

    try {
      const response = await fetch(`${BASE_URL}/api/bloquear/${user._id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify({ motivoBloqueo }),
      });

      if (response.ok) {
        const data = await response.json();
        Swal.fire({
          title: 'Éxito',
          text: data.message,
          icon: 'success',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        }).then(() => {
          window.location.reload();
        });
      } else {
        const errorData = await response.json();
        Swal.fire({
          title: 'Error',
          text: errorData.message || 'Ocurrió un error',
          icon: 'error',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
      }
    } catch (error) {
      Swal.fire({
        title: 'Error',
        text: 'No se pudo completar la solicitud',
        icon: 'error',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  if (!user) {
    return <div>Cargando...</div>;
  }

  const formattedFecha = user.fechaBloqueo
    ? new Date(user.fechaBloqueo).toLocaleDateString('es-ES', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      })
    : '';

  return (
    <div className="bloquear-usuario-container">
      <h1 className="PA-titulo">Bloquear/Desbloquear Usuario</h1>
      <p className="dato">Nombre de Usuario: <span>{user.nombreUsuario}</span></p>
      <p className="dato">Estado Actual: <span>{user.bloqueado ? 'Bloqueado' : 'Activo'}</span></p>
      <form onSubmit={handleSubmit} className="bloquear-form">
        {!user.bloqueado ? (
          <div className="campo-textarea">
            <label htmlFor="motivoBloqueo">Motivo del Bloqueo:</label>
            <textarea
              id="motivo"
              name="motivoBloqueo"
              value={motivoBloqueo}
              onChange={handleMotivoChange}
              required
              tabIndex="1"
            />
          </div>
        ) : (
          <>
            <div className="campo">
              <label>Motivo del Bloqueo:</label>
              <p>{user.motivoBloqueo}</p>
            </div>
            <div className="campo">
              <label>Fecha de Bloqueo:</label>
              <p>{formattedFecha}</p>
            </div>
          </>
        )}
        <div className="botones">
          <button type="submit" className="btn-submit">
            {user.bloqueado ? 'Desbloquear' : 'Bloquear'}
          </button>
          <button
            type="button"
            className="btn-volver"
            onClick={handleBack}
          >
            Volver
          </button>
        </div>
      </form>
    </div>
  );
};

export default PABloquear;