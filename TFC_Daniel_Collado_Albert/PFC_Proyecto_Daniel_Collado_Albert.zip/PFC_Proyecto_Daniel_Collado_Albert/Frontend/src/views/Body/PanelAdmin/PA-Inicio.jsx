import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import storage from "../../../Storage/storage";
import "../../../css/base/sweetAlert.css";
import '../../../css/PanelAdmin/PA-Inicio.css';
import imagenErrorBlanco from "../../../assets/Imagenes/error-imagen-blanco.png";


const ListaUsuarios = ({ initialSearch = '' }) => {
  const [search, setSearch] = useState(initialSearch);
  const [usuarios, setUsuarios] = useState([]);
  const [filteredUsuarios, setFilteredUsuarios] = useState([]);
  const [currentUserId, setCurrentUserId] = useState(null);
  const navigate = useNavigate();

  const BASE_URL = "http://localhost:3016";

  useEffect(() => {
    const fetchUsuarios = async () => {
      try {
        const token = localStorage.getItem('authToken');
        const response = await fetch(`${BASE_URL}/api/lista`, {
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        const data = await response.json();
        if (Array.isArray(data.usuarios)) {
          setUsuarios(data.usuarios);

          const authUser = storage.get("authUser");
          setCurrentUserId(authUser._id);
        } else {
          throw new Error('Respuesta inválida de usuarios');
        }
      } catch (error) {
        console.error('Error al obtener usuarios:', error);
        Swal.fire({
          title: 'Error', 
          text: 'No se pudo obtener la lista de usuarios', 
          icon:'error',
            customClass: {
            popup: 'custom-popup',
            title: 'custom-title',
            content: 'custom-content',
            confirmButton: 'custom-confirm-button',
          },});
        }
      };

    fetchUsuarios();
  }, []);

useEffect(() => {
  setFilteredUsuarios(
    usuarios.filter(u => {
      const nombre = u.nombreUsuario.toLowerCase();
      const termino = search.toLowerCase();

      for (let i = 0; i < termino.length; i++) {
        if (nombre[i] !== termino[i]) {
          return false;
        }
      }
      return true;
    })
  );
}, [search, usuarios]);

  const showAlert = (title, text, icon) => {
    Swal.fire({
      title,
      text,
      icon,
      customClass: {
        popup: 'custom-popup',
        title: 'custom-title',
        content: 'custom-content',
        confirmButton: 'custom-confirm-button',
      },
    });
  };

const confirmarCambioPerfil = async (userId, nuevoPerfil, nombreUsuario) => {
  if (userId === currentUserId) {
    showAlert('Error', 'No puedes cambiar tu propio perfil', 'error');
    return;
  }

  const result = await Swal.fire({
    title: 'Aviso',
    text: `¿Deseas cambiar el perfil de ${nombreUsuario} a ${nuevoPerfil}?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Sí, cambiar',
    cancelButtonText: 'Cancelar',
    customClass: {
      popup: 'custom-popup',
      title: 'custom-title',
      content: 'custom-content',
      confirmButton: 'custom-confirm-button',
    },
  });

  if (!result.isConfirmed) return;

  try {
    const token = localStorage.getItem('authToken');
    const response = await fetch(`${BASE_URL}/api/cambiarPerfil/${userId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ perfil: nuevoPerfil }),
    });
    const data = await response.json();

    if (data.success) {

      setUsuarios(prevUsuarios => 
        prevUsuarios.map(usuario => 
          usuario._id === userId 
            ? { ...usuario, perfil: nuevoPerfil }
            : usuario
        )
      );
      
      showAlert('Éxito', 'Perfil actualizado correctamente', 'success');
    } else {
      showAlert('Error', data.message || 'Error al actualizar el perfil', 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showAlert('Error', 'Error al actualizar el perfil', 'error');
  }
};

  const confirmarEliminacion = async (userId, nombreUsuario, callback) => {
    if (userId === currentUserId) {
      showAlert('Error', 'No puedes eliminar tu propio usuario', 'error');
      return;
    }

    const result = await Swal.fire({
      title: '¿Estás seguro?',
      text: `Esta acción eliminará a: ${nombreUsuario}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      customClass: {
        popup: 'custom-popup',
        title: 'custom-title',
        content: 'custom-content',
        confirmButton: 'custom-confirm-button',
      },
    });

    if (result.isConfirmed) {
      callback();
    }
  };

const eliminarUsuario = async (event, userId) => { 
  event.preventDefault();
  try {
    const token = localStorage.getItem('authToken');

    await fetch(`${BASE_URL}/api/resenas/anonimizar/${userId}`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    await fetch(`${BASE_URL}/api/resenas/anonimizar/${userId}`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const citasResponse = await fetch(`${BASE_URL}/api/citas`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!citasResponse.ok) throw new Error("Error al obtener citas");

    const { data } = await citasResponse.json();
    const citasDelUsuario = data.citas.filter(cita => cita.clienteId === userId);

    await Promise.all(
      citasDelUsuario.map(cita =>
        fetch(`${BASE_URL}/api/citas/${cita._id}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
      )
    );

    const response = await fetch(`${BASE_URL}/api/${userId}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });

    const eliminado = await response.json();

    if (eliminado.success) {
      document.querySelector(`#usuario-${userId}`)?.remove();
      showAlert('Éxito', 'Usuario eliminado correctamente', 'success');
    } else {
      showAlert('Error', eliminado.message || 'Error al eliminar el usuario', 'error');
    }

  } catch (error) {
    console.error('Error:', error);
    showAlert('Error', 'Error al eliminar el usuario', 'error');
  }
};

  const adminCount = (usuarios || []).filter(u => u.perfil === 'ADMIN').length;

  return (
    <div>
      <div id='pa-cabecera'>
        <h1 className='titulo-resenas'>Panel Administrador</h1>
        <div>
          <input
            type="text"
            placeholder="Buscar por nombre de usuario"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pa-busqueda"
          />
        </div>
      </div>
      <div id="usuarios-lista">
        {filteredUsuarios.length === 0 ? (
          <div className='usuario-vacio'>
            <img src={imagenErrorBlanco} alt="No hay diseños" className="diseno-vacio-img" />
            <p >No hay usuarios registrados.</p>
          </div>
        ) : (
          <table id="tabla-usuarios">
            <thead>
              <tr>
                <th>Nombre de Usuario</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Correo</th>
                <th>Perfil</th>
                <th>Bloqueado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsuarios.map(usuario => (
                <tr key={usuario._id} id={`usuario-${usuario._id}`}>
                  <td>{usuario.nombreUsuario}</td>
                  <td>{usuario.nombre}</td>
                  <td>{usuario.apellidos}</td>
                  <td>{usuario.correo}</td>
                  <td>
                    { usuario._id === currentUserId ? (
                      <span>No puedes cambiar tu propio perfil</span>
                    ) : (
                      <select
                        name="perfil"
                        value={usuario.perfil}
                        onChange={e =>
                          confirmarCambioPerfil(
                            usuario._id,
                            e.target.value,
                            usuario.nombreUsuario
                          )
                        }
                      >
                        <option value="USUARIO">Usuario</option>
                        <option value="ADMIN">Administrador</option>
                      </select>
                    )}
                  </td>
                  <td>{usuario.bloqueado ? 'Sí' : 'No'}</td>
                  <td>
                    { usuario._id === currentUserId ? (
                      <span>No puedes eliminar/bloquear tu propio usuario</span>
                    ) : (
                      <>
                        <form
                          onSubmit={e => {
                            e.preventDefault();
                           confirmarEliminacion(usuario._id, usuario.nombreUsuario, () => eliminarUsuario(e, usuario._id));


                          }}
                          style={{ display: 'inline' }}
                        >
                          <button className='pa-boton-rojo' type="submit">Eliminar Usuario</button>
                        </form>
                        <button
                          className='pa-boton-rojo'
                          onClick={() => navigate(`/api/bloquear/${usuario._id}`)}
                        >
                          {usuario.bloqueado ? 'Desbloquear' : 'Bloquear'}
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <button id='pa-volver' type="button" onClick={() => navigate("/api/")}>Volver</button>
    </div>
  );
};

export default ListaUsuarios;