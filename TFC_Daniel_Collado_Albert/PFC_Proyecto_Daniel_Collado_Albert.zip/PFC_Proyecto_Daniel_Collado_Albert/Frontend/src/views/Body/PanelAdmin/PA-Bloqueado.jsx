import { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import storage from '../../../Storage/storage';
import Swal from 'sweetalert2';
import { AuthContext } from '../../../Components/AuthContext';
import '../../../css/PanelAdmin/PA-Bloqueado.css';
import '../../../css/base/sweetAlert.css';

const BASE_URL = 'http://localhost:3016';

const PABloqueado = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext);
  const [perfil, setPerfil] = useState(null);
  const [error, setError] = useState(null);

  const customClass = () => ({
    popup: "custom-popup",
    title: "custom-title",
    content: "custom-content",
    confirmButton: "custom-confirm-button",
    cancelButton: "custom-confirm-button",
  });

  const isTokenExpired = (token) => {
    try {
      if (!token || token.split('.').length !== 3) throw new Error("Token no tiene el formato JWT válido.");
      const payloadDecoded = atob(token.split('.')[1]);
      const payload = JSON.parse(payloadDecoded);
      return payload.exp * 1000 < Date.now();
    } catch (error) {
      console.error("Error al procesar el token:", error.message);
      return true;
    }
  };

  // Función para verificar si es el último admin
  const checkLastAdmin = async () => {
    try {
      const token = storage.get("authToken");
      const response = await fetch(`${BASE_URL}/api/contarAdmins`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Error al verificar administradores");
      }

      const data = await response.json();
      const isLast = data.count <= 1;
      return isLast; // Retorna true si hay 1 o menos admins
    } catch (error) {
      return false;
    }
  };

const handleDelete = async () => {
  const authUser = storage.get("authUser");
  
  // Verificar si el usuario es admin y si es el último
  if (authUser.profile && authUser.profile.toLowerCase() === 'admin') {
    const isLastAdmin = await checkLastAdmin();
    
    if (isLastAdmin) {
      Swal.fire({
        icon: "warning",
        title: "No se puede eliminar la cuenta",
        text: "Eres el último administrador del sistema. No puedes eliminar tu cuenta hasta que haya otro administrador.",
        customClass: customClass(),
      });
      return;
    } 
  }

  const result = await Swal.fire({
    icon: "warning",
    title: "¿Estás seguro?",
    text: "Esta acción eliminará permanentemente la cuenta del usuario y las citas pendientes.",
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
    customClass: customClass(),
  });

  if (!result.isConfirmed) return;

  try {
    const token = storage.get("authToken");

    // Anonimizar reseñas del usuario
    await fetch(`${BASE_URL}/api/resenas/anonimizar/${id}`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
      }
    });

    // Obtener y eliminar citas del usuario
    const citasResponse = await fetch(`${BASE_URL}/api/citas`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!citasResponse.ok) throw new Error("Error al obtener citas");

    const citasData = await citasResponse.json();
    const citas = citasData.data.citas;
    const citasDelUsuario = citas.filter(cita => cita.clienteId === id);

    for (const cita of citasDelUsuario) {
      await fetch(`${BASE_URL}/api/citas/${cita._id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

    // Eliminar usuario
    const deleteUserResponse = await fetch(`${BASE_URL}/api/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      credentials: "include",
    });

    if (deleteUserResponse.ok) {
      // Eliminar token haciendo logout
      try {
        await fetch(`${BASE_URL}/api/logout`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          credentials: "include",
        });
      } catch (logoutError) {
        console.warn("Error al hacer logout en el servidor:", logoutError);
      }

      Swal.fire({ 
        icon: "success", 
        title: "Usuario eliminado con éxito", 
        customClass: customClass() 
      }).then(() => {

        if (authUser._id === id) {
          logout();
          navigate("/api/");
        } else {

          navigate("/api/panelAdmin");
        }
      });
    } else {
      const errorData = await deleteUserResponse.json();
      throw new Error(errorData.message || "Error al eliminar la cuenta");
    }
  } catch (error) {
    Swal.fire({ 
      icon: "error", 
      title: "Error", 
      text: error.message || "No se pudo eliminar la cuenta.", 
      customClass: customClass() 
    });
  }
};

  useEffect(() => {
    if (!id) {
      setError("ID de perfil no proporcionado.");
      return;
    }

    const fetchPerfil = async () => {
      try {
        const token = localStorage.getItem('authToken');
        if (isTokenExpired(token)) {
          localStorage.removeItem("authToken");
          localStorage.removeItem("authUser");
          navigate('/api/iniciarSesion');
          return;
        }

        const res = await fetch(`${BASE_URL}/api/perfil/${id}`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });

        const contentType = res.headers.get("content-type");
        if (!res.ok || !contentType || !contentType.includes("application/json")) {
          const text = await res.text();
          throw new Error(`Respuesta inesperada del servidor: ${text}`);
        }

        const data = await res.json();
        if (data.status && data.user) {
          setPerfil(data.user);
        } else {
          throw new Error("No se pudo cargar el perfil del usuario.");
        }
      } catch (err) {
        setError(err.message);
        Swal.fire({
          title: 'Error',
          text: err.message || 'Error al cargar perfil',
          icon: 'error',
          customClass: customClass(),
        });
      }
    };

    fetchPerfil();
  }, [id, navigate]);

  if (error) return <div className="perfil-error">Error: {error}</div>;
  if (!perfil) return <div className="perfil-cargando">Cargando perfil...</div>;

  return (
    <div className="perfil-contenedor">
      <div className="perfil-tarjeta">
        <h2 className='perfil-titulo'>El usuario {perfil.nombreUsuario} ha sido bloqueado</h2>
        <p className="perfil-texto"><strong>Email:</strong> {perfil.correo}</p>
        <p className="perfil-texto"><strong>Nombre completo:</strong> {perfil.nombre} {perfil.apellidos}</p>
        <br/><br/>
        <p className="perfil-texto"><strong>Motivo:</strong> {perfil.motivoBloqueo}</p>
        <p className="perfil-texto"><strong>Fecha de bloqueo:</strong> {new Date(perfil.fechaBloqueo).toLocaleDateString()}</p>
        
        <div className="perfil-buttons">
          <button onClick={() => navigate("/api/panelAdmin")}>Volver al Panel</button>
          <button onClick={handleDelete} className="perfil-delete-button">
            Dar de baja usuario
          </button>
        </div>
      </div>
    </div>
  );
};

export default PABloqueado;