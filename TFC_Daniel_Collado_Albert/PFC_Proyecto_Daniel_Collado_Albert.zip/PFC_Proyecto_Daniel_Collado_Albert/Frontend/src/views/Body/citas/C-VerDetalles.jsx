import { useEffect, useState } from 'react';
import '../../../css/citas/C-VerDetalles.css';
import { useParams, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import "../../../css/base/sweetAlert.css";


const BASE_URL = "http://localhost:3016";

const DetallesCita = () => {
  const { id } = useParams();
  const [cita, setCita] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCita = async () => {
      try {
        const token = localStorage.getItem('authToken');
        const res = await fetch(`${BASE_URL}/api/citas/verDetalles/${id}`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
          }
        });

        if (!res.ok) {
          const errorMsg = await res.text();
          throw new Error(`Error en la solicitud: ${errorMsg}`);
        }

        const json = await res.json();
        setCita(json.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCita();
  }, [id]);

  if (loading) return <div className="detalles-container">Cargando...</div>;
  if (error) return <div className="detalles-container">Error: {error}</div>;
  if (!cita) return null;

  const handleDelete = async (id) => {
      try {
        const token = localStorage.getItem("authToken");
        if (!token) {
          console.error("No se encontró el token");
          return;
        }
  
        const response = await fetch(`${BASE_URL}/api/citas/${id}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
  
        if (!response.ok) {
          const errorMsg = await response.text();
          throw new Error(`Error eliminando la cita: ${errorMsg}`);
        }
  
        navigate("/api/citas"); 

        Swal.fire({
          title: 'Éxito',
          text: 'La cita ha sido eliminada correctamente.',
          icon: 'success',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          }
        });
      } catch (error) {
        console.error('Error eliminando el diseño:', error);
        Swal.fire({
          title: 'Error',
          text: 'No se pudo eliminar el diseño.',
          icon: 'error',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          }
        });
      }
    };
  
    const confirmDelete = (id) => {
      Swal.fire({
        title: '¿Quieres eliminar esta cita?',
        text: "Esta acción no se puede deshacer.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-confirm-button",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          handleDelete(id);
        }
      });
    };

  return (
    <div className="detalles-container">
      <div className="detalles-content">
        <h1>Detalles de la Cita</h1>

        {cita.foto && (
          <img
           src={cita.foto?.startsWith("http") ? cita.foto : `${BASE_URL}${cita.foto}`}
            alt="Foto de la cita"
            className="foto-cita"
          />
        )}

        <p><strong style={{ color: '#ffdd00' }}>Nombre del Cliente:</strong> {cita.nombreCompletoCliente}</p>
        <p><strong style={{ color: '#ffdd00' }}>Descripción:</strong> {cita.descripcion || 'Por estimar'}</p>
        <p><strong style={{ color: '#ffdd00' }}>Tamaño:</strong> {cita.tamano || 'Por estimar'}</p>
        <p><strong style={{ color: '#ffdd00' }}>Fecha:</strong> {cita.fecha ? new Date(cita.fecha).toLocaleDateString('es-ES') : 'Por estimar'}</p>
        <p><strong style={{ color: '#ffdd00' }}>Precio:</strong> {cita.precio ? `${cita.precio}€` : 'Por estimar'}</p>
        <p><strong style={{ color: '#ffdd00' }}>Tiempo Estimado:</strong> {cita.tiempoEstimado || 'Por estimar'}</p>
        <p><strong style={{ color: '#ffdd00' }}>Estado:</strong> {cita.estado || 'Por estimar'}</p>

        <div className="detalles-buttons">
          <a href={`/api/citas/editar/${cita._id}`}>
            <button className='detalles-boton-editar'>Editar</button>
          </a>

           <button className="detalles-delete-button" onClick={() => confirmDelete(cita._id)}>
            Eliminar
          </button>

          
          <button className='detalles-volver' type="button" onClick={() => window.history.back()}>Volver</button>
        </div>
      </div>
    </div>
  );
};

export default DetallesCita;
