import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import "../../../css/citas/C-Inicio.css";
import "../../../css/base/sweetAlert.css";
import imagenError from "../../../assets/Imagenes/error-imagen.png";
import imagenErrorBlanco from "../../../assets/Imagenes/error-imagen-blanco.png";

const BASE_URL = "http://localhost:3016";

const Inicio = () => {
  const navigate = useNavigate();
  const [citas, setCitas] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchCitas = async () => {
      try {
        const token = localStorage.getItem("authToken");
        if (!token) {
          console.error("Token no encontrado en localStorage");
          return;
        }

        const res = await fetch(`${BASE_URL}/api/citas`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });

        const json = await res.json();

        if (json.success) {
          setCitas(json.data.citas);
          setUser(json.data.user);
        }
      } catch (error) {
        console.error("Error al cargar citas:", error);
      }
    };

    fetchCitas();
  }, []);

const perfil = user?.data?.data?.perfil;
const userId = user?.data?.data?._id;

const citasFiltradas = citas.filter(
  (cita) =>
    (perfil === 'USUARIO' && String(cita.clienteId) === String(userId)) ||
    perfil === 'ADMIN'
);

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("authToken");
      if (!token) {
        console.error("No se encontró el token");
        return;
      }

      const response = await fetch(`${BASE_URL}/api/citas/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorMsg = await response.text();
        throw new Error(`Error eliminando la cita: ${errorMsg}`);
      }

      setCitas(citas.filter(cita => cita._id !== id));
      Swal.fire({
        title: 'Éxito',
        text: 'La cita ha sido eliminada correctamente.',
        icon: 'success',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    } catch (error) {
      console.error('Error eliminando la cita:', error);
      Swal.fire({
        title: 'Error',
        text: 'No se pudo eliminar la cita.',
        icon: 'error',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    }
  };

  const confirmDelete = (id) => {
    Swal.fire({
      title: '¿Quieres eliminar esta cita?',
      text: "Esta acción no se puede deshacer.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      customClass: {
        popup: "custom-popup",
        title: "custom-title",
        content: "custom-content",
        confirmButton: "custom-confirm-button",
        cancelButton: "custom-confirm-button",
      },
    }).then((result) => {
      if (result.isConfirmed) {
        handleDelete(id);
      }
    });
  };

  const agruparCitasPorFecha = (citas) => {
    const citasAgrupadas = {};

    citas.forEach(cita => {
      const fecha = new Date(cita.fecha).toLocaleDateString('es-ES');
      if (!citasAgrupadas[fecha]) {
        citasAgrupadas[fecha] = [];
      }
      citasAgrupadas[fecha].push(cita);
    });

    // Ordenar las fechas de la más cercana a la más lejana
    const fechasOrdenadas = Object.keys(citasAgrupadas).sort((a, b) => {
      const dateA = new Date(a.split('/').reverse().join('-')); // Convertir a formato YYYY-MM-DD
      const dateB = new Date(b.split('/').reverse().join('-'));
      return dateA - dateB;
    });

    return { citasAgrupadas, fechasOrdenadas };
  };

  const { citasAgrupadas, fechasOrdenadas } = agruparCitasPorFecha(citasFiltradas);

  return (
    <div>
      <h1 className='titulo-resenas'>Citas</h1>
      <div className="tatuajes-lista">
        {citasFiltradas.length > 0 ? (
          user?.data?.data?.perfil === 'ADMIN' ? (
            fechasOrdenadas.map(fecha => (
              <div key={fecha} className="fecha-container">
                <h2 className='c-fecha'><u>{fecha}</u></h2>
                <div className="citas-del-mismo-dia">
                  {citasAgrupadas[fecha].map((cita) => (
                    <div key={cita._id} className="tatuaje-item">
                      <img
                         src={cita.foto?.startsWith("http") ? cita.foto : `${BASE_URL}${cita.foto}`}
                        alt={`Imagen del tatuaje: ${cita.titulo}`}
                        className="tatuaje-img"
                        onError={(e) => (e.target.src = imagenError)}
                      />
                      <div className="info-contenedor">
                        <p><strong>Descripción:</strong> {cita.descripcion}</p>
                        <p><strong>Fecha:</strong> {cita.fecha ? new Date(cita.fecha).toLocaleDateString('es-ES') : new Date().toLocaleDateString('es-ES')}</p>
                        <p><strong>Hora:</strong> {cita.fecha ? new Date(cita.fecha).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }) : 'No especificada'}</p>
                        <p><strong>Confirmado:</strong> {cita.estado}</p>
                        {cita.estado === 'cancelada' && (
                        <p><strong>Motivo del cancelamiento:</strong> {cita.motivoCancelacion}</p>
                        )}

                        <div className="cita-botones-contenedor">
                          <div className="cita-editar-eliminar">
                            <button
                              className="cita-boton-editar"
                              onClick={() => navigate(`/api/citas/editar/${cita._id}`)}
                            >
                              Editar
                            </button>

                            <button
                              className="cita-boton-eliminar"
                              onClick={() => confirmDelete(cita._id)}
                            >
                              Eliminar
                            </button>
                          </div>

                          <button
                            className="cita-boton-verDetalles"
                            onClick={() => navigate(`/api/citas/verDetalles/${cita._id}`)}
                          >
                            Ver detalles
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <div className="fecha-container">
              <div className="citas-del-mismo-dia">
                {citasFiltradas.map((cita) => (
                  <div key={cita._id} className="tatuaje-item">
                    <img
                      src={cita.foto?.startsWith("http") ? cita.foto : `${BASE_URL}${cita.foto}`}
                      alt={`Imagen del tatuaje: ${cita.titulo}`}
                      className="tatuaje-img"
                      onError={(e) => (e.target.src = imagenError)}
                    />
                    <div className="info-contenedor">
                      <p><strong>Descripción:</strong> {cita.descripcion}</p>
                      <p><strong>Fecha:</strong> {cita.fecha ? new Date(cita.fecha).toLocaleDateString('es-ES') : new Date().toLocaleDateString('es-ES')}</p>
                      <p><strong>Hora:</strong> {cita.fecha ? new Date(cita.fecha).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }) : 'No especificada'}</p>
                      <p><strong>Confirmado:</strong> {cita.estado}</p>
                      {cita.estado === 'cancelada' && (
                        <p className="cita-cancelada"><strong>Motivo del Candelamiento:</strong> {cita.motivoCancelacion}</p>
                      )}

                      <div className="cita-botones-contenedor">
                        <div className="cita-editar-eliminar">
                          <button
                            className="cita-boton-editar"
                            onClick={() => navigate(`/api/citas/editar/${cita._id}`)}
                          >
                            Editar
                          </button>

                          <button
                            className="cita-boton-eliminar"
                            onClick={() => confirmDelete(cita._id)}
                          >
                            Eliminar
                          </button>
                        </div>

                        <button
                          className="cita-boton-verDetalles"
                          onClick={() => navigate(`/api/citas/verDetalles/${cita._id}`)}
                        >
                          Ver detalles
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        ) : (
          <div className="c-cita-vacia-inicio">
            <img src={imagenErrorBlanco} alt="No hay tatuajes" className="c-cita-vacia-inicio-img" />
            <h2>No hay citas.</h2>
            <p>¿Qué esperas para tatuarte?</p>
          </div>
        )}
      </div>

      <div className="nuevo-volver">
        <button className="boton-nuevo" onClick={() => navigate('/api/citas/nueva')}>Proponer cita</button>
        <button className="boton-volver" onClick={() => navigate('/')}>Volver</button>
      </div>
    </div>
  );
};

export default Inicio;