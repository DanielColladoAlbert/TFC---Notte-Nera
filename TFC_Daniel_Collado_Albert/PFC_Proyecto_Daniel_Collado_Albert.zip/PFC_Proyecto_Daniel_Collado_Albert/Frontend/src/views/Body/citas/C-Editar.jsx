import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import storage from "../../../Storage/storage";
import Swal from 'sweetalert2';
import "../../../css/citas/C-Editar.css";
import "../../../css/base/sweetAlert.css";
import enviar from "../../../assets/Imagenes/enviar.png";
import { v4 as uuidv4 } from 'uuid';

const BASE_URL = "http://localhost:3016";

const EditarCitaTatuaje = ({ user }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [cita, setCita] = useState(null);
  const [formData, setFormData] = useState(null);
  const [initialFormData, setInitialFormData] = useState(null);
  const [fotoPreview, setFotoPreview] = useState(null);
  const [esDisenoPredefinido, setEsDisenoPredefinido] = useState(false);
  const [conversacion, setConversacion] = useState([]);
  const [nuevoMensaje, setNuevoMensaje] = useState("");
  const [mensajeEnEdicion, setMensajeEnEdicion] = useState(null);
  const [textoTemporal, setTextoTemporal] = useState("");
  const [menuActivo, setMenuActivo] = useState(null);
  const [motivoCancelacion, setMotivoCancelacion] = useState("");
  const [minDateTime, setMinDateTime] = useState("");
  const menuRef = useRef(null);
  const chatEndRef = useRef(null);

  const authUser = storage.get("authUser");
  const isAdmin = authUser?.profile === "ADMIN";
  const userId = authUser?._id;

  const esPropietarioCita = cita && String(cita.clienteId) === String(userId);
  
  // Restricciones para campos personales 
  const camposPersonalesRestringidos = esDisenoPredefinido || (isAdmin && !esPropietarioCita);
  
  const imageRegex = /\.(jpe?g|png|gif)$/i;
  const camposBloqueados = !isAdmin && esDisenoPredefinido;

  const fileInputRef = useRef(null);

  const normalizarConversacion = (conversacion) => {
    if (!Array.isArray(conversacion)) return [];
    
    return conversacion.flatMap(item => {
      if (typeof item === "string") {
        try {
          const parsed = JSON.parse(item);
          return Array.isArray(parsed) ? parsed : [parsed];
        } catch {
          return [];
        }
      }
      return item;
    });
  };

  const isTokenExpired = (token) => {
    try {
      if (!token || token.split('.').length !== 3) throw new Error("Token no tiene el formato JWT válido.");
      const payloadDecoded = atob(token.split('.')[1]);
      const payload = JSON.parse(payloadDecoded);
      return payload.exp * 1000 < Date.now();
    } catch (error) {
      console.error("Error al procesar el token:", error.message);
      return true;
    }
  };

  useEffect(() => {
    const now = new Date();
    const formatted = now.toISOString().slice(0, 16);
    setMinDateTime(formatted);
  }, []);

  useEffect(() => {
    const fetchCita = async () => {
      try {
        const token = localStorage.getItem('authToken');
        if (isTokenExpired(token)) {
          localStorage.removeItem("authToken");
          localStorage.removeItem("authUser");
          navigate('/api/iniciarSesion');
          return;
        }

        const res = await fetch(`${BASE_URL}/api/citas/editar/${id}`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });

        const contentType = res.headers.get("content-type");
        if (!res.ok || !contentType || !contentType.includes("application/json")) {
          const text = await res.text();
          throw new Error(`Respuesta inesperada del servidor: ${text}`);
        }

        const responseData = await res.json();

        if (responseData.success && responseData.data?.cita) {
          const citaEncontrada = responseData.data.cita;
          
          setCita(citaEncontrada);
          setEsDisenoPredefinido(citaEncontrada.foto?.startsWith("http") || false);
          
          const conversacionNormalizada = normalizarConversacion(citaEncontrada.conversacion || []);
          setConversacion(conversacionNormalizada);

          if (citaEncontrada.motivoCancelacion) {
            setMotivoCancelacion(citaEncontrada.motivoCancelacion);
          }

          const initialData = {
            nombreCompletoCliente: citaEncontrada.nombreCompletoCliente || '',
            descripcion: citaEncontrada.descripcion || '',
            tamano: citaEncontrada.tamano || '',
            fecha: isNaN(Date.parse(citaEncontrada.fecha)) ? '' : new Date(citaEncontrada.fecha).toISOString().slice(0, 16),
            estado: citaEncontrada.estado || 'pendiente',
            precio: citaEncontrada.precio || '',
            tiempoEstimado: citaEncontrada.tiempoEstimado || '',
            foto: null,
            motivoCancelacion: citaEncontrada.motivoCancelacion || '',
          };
          setFormData(initialData);
          setInitialFormData(initialData);
        } else {
          throw new Error("Datos de la cita no disponibles");
        }
      } catch (err) {
        console.error('Error al cargar la cita:', err);
        Swal.fire({
          title: 'Error',
          text: err.message || 'Error al cargar la cita',
          icon: 'error',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          }
        });
      }
    };

    fetchCita();
  }, [id, navigate]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuActivo(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversacion]);

  const hasChanges = () => {
    if (!initialFormData || !formData) return false;
    return Object.keys(initialFormData).some((key) => {
      if (key === 'foto') return false;
      return initialFormData[key] !== formData[key];
    }) || conversacion.length !== (cita?.conversacion?.length || 0) ||
      JSON.stringify(conversacion) !== JSON.stringify(
        normalizarConversacion(cita?.conversacion || [])
      );
  };

  const handleBack = async (e) => {
    e.preventDefault();

    if (hasChanges()) {
      const result = await Swal.fire({
        title: '¿De verdad quieres volver?',
        text: 'No se guardarán los cambios realizados.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, volver',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-confirm-button",
        }
      });

      if (result.isConfirmed) {
       navigate("/api/citas")
      }
    } else {
      navigate("/api/citas")
    }
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;

    if (name === 'foto') {
      const file = files[0];
      if (file && imageRegex.test(file.name)) {
        const reader = new FileReader();
        reader.onload = (e) => setFotoPreview(e.target.result);
        reader.readAsDataURL(file);
        setFormData((prev) => ({ ...prev, foto: file }));
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Solo se permiten imágenes JPEG, JPG, PNG o GIF.',
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        e.target.value = '';
        setFotoPreview(null);
      }
    } else if (name === 'estado') {
      setFormData((prev) => ({ ...prev, [name]: value }));

      if (value !== 'cancelada') {
        setMotivoCancelacion('');
        setFormData((prev) => ({ ...prev, motivoCancelacion: '' }));
      }
    } else if (name === 'motivoCancelacion') {
      setMotivoCancelacion(value);
      setFormData((prev) => ({ ...prev, motivoCancelacion: value }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const agregarMensaje = () => {
    if (!nuevoMensaje.trim()) return;
    const nuevo = { userId, text: nuevoMensaje.trim() };
    setConversacion(prev => [...prev, nuevo]);
    setNuevoMensaje("");
  };

  const editarMensaje = (index) => {
    setMensajeEnEdicion(index);
    setTextoTemporal(conversacion[index].text);
    setMenuActivo(null);
  };

  const finalizarEdicion = (index) => {
    if (textoTemporal.trim()) {
      const copia = [...conversacion];
      copia[index].text = textoTemporal.trim();
      setConversacion(copia);
    }
    setMensajeEnEdicion(null);
    setTextoTemporal("");
  };

  const cancelarEdicion = () => {
    setMensajeEnEdicion(null);
    setTextoTemporal("");
  };

  const eliminarMensaje = (index) => {
    const nuevaConversacion = conversacion.filter((_, idx) => idx !== index);
    setConversacion(nuevaConversacion);
    setMenuActivo(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.nombreCompletoCliente) {
      Swal.fire({
        icon: "error",
        title: "Nombre completo del cliente es requerido",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    if (!formData.fecha) {
      Swal.fire({
        icon: "error",
        title: "Fecha es requerida",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    if (formData.estado === 'cancelada' && !motivoCancelacion.trim()) {
      Swal.fire({
        icon: "error",
        title: "Motivo de cancelación requerido",
        text: "Por favor, ingrese el motivo de la cancelación de la cita.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    try {
      const token = localStorage.getItem('authToken');
      const data = new FormData();

      data.append("conversacion", JSON.stringify([...conversacion]));

      // Solo incluir campos que el usuario puede editar
      if (esPropietarioCita || !isAdmin) {

        data.append("nombreCompletoCliente", formData.nombreCompletoCliente);
        data.append("descripcion", formData.descripcion);
        data.append("tamano", formData.tamano);
        
        if (formData.foto) {
          data.append("foto", formData.foto);
        }
      } else {

        data.append("nombreCompletoCliente", cita.nombreCompletoCliente);
        data.append("descripcion", cita.descripcion);
        data.append("tamano", cita.tamano);
      }

      data.append("fecha", formData.fecha);
      
      if (isAdmin) {
        data.append("estado", formData.estado);
        data.append("precio", formData.precio);
        data.append("tiempoEstimado", formData.tiempoEstimado);
        
        if (formData.estado === 'cancelada') {
          data.append("motivoCancelacion", motivoCancelacion);
        }
      }

      await axios.patch(`${BASE_URL}/api/citas/editar/${id}`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      Swal.fire({
        icon: 'success',
        title: 'Cambios guardados con éxito',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          confirmButton: "custom-confirm-button",
        }
      });

      window.history.back();
    } catch (error) {
      console.error('Error al guardar:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error al guardar',
        text: 'No se pudo actualizar la cita.',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    }
  };

  if (!cita || !formData) return <div className="citas-container"><p>Cargando cita...</p></div>;

  return (
    <div className="citas-container">
      <form className="citas-formulario" onSubmit={handleSubmit}>
        <div className="citas-campos-grid">
          {/* Columna izquierda */}
          <div className="columna-form">
            <div className="citas-campo">
              <label className="citas-label">Cambiar imagen del tatuaje:</label>
              {camposPersonalesRestringidos ? (
                <div className="campo-texto-solo-lectura">
                  <p className="texto-restringido">
                    {esDisenoPredefinido 
                      ? "Debido a que es un diseño preestablecido no se puede cambiar la imagen."
                      : "Solo el propietario de la cita puede cambiar la imagen."
                    }
                  </p>
                </div>
              ) : (
                <input
                  ref={fileInputRef}
                  className="citas-file"
                  type="file"
                  name="foto"
                  accept="image/*"
                  onChange={handleChange}
                  readOnly={camposBloqueados}
                />
              )}
              <div className="citas-imagenes-container">
                {cita.foto && (
                  <div className="citas-imagen-wrapper">
                    <p className="citas-p p-imagen-previa">{cita.foto?.startsWith("http") ? "" : "Imagen previa:"}</p>
                    <img
                      className="citas-imagen-previa"
                      src={cita.foto?.startsWith("http") ? cita.foto : `${BASE_URL}${cita.foto}`}
                      alt="Foto de la cita"
                      id='foto-previo-c'
                    />
                  </div>
                )}
                {fotoPreview && (
                  <div className="citas-imagen-wrapper c-foto-nueva">
                    <p className="citas-p">Foto nueva:</p>
                    <img
                      src={fotoPreview}
                      alt="Vista previa"
                      className="citas-imagen-previa"
                    />
                    <button
                      type="button"
                      className="citas-boton cancelar-imagen-boton"
                      onClick={() => {
                        setFotoPreview(null);
                        setFormData((prev) => ({ ...prev, foto: null }));
                        if (fileInputRef.current) {
                          fileInputRef.current.value = ''; // Limpiar el input file
                        }
                      }}
                    >
                      Cancelar Imagen
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="citas-campo">
              <label className="citas-label">Descripción:</label>
              {camposPersonalesRestringidos ? (
                <div className="campo-texto-solo-lectura">
                  <p className="texto-restringido">{formData.descripcion || "Sin descripción"}</p>
                </div>
              ) : (
                <textarea
                  className="citas-textarea"
                  name="descripcion"
                  value={formData.descripcion}
                  onChange={handleChange}
                  readOnly={camposBloqueados}
                  tabIndex="1"
                ></textarea>
              )}
            </div>

            <div className="citas-campo">
              <label className="citas-label">Tamaño:</label>
              {camposPersonalesRestringidos ? (
                <div className="campo-texto-solo-lectura">
                  <p className="texto-restringido">{formData.tamano || "Sin especificar"}</p>
                </div>
              ) : (
                <input
                  className="citas-input"
                  type="text"
                  name="tamano"
                  value={formData.tamano}
                  onChange={handleChange}
                  readOnly={camposBloqueados}
                  tabIndex="2"
                />
              )}
            </div>

            {isAdmin && (
              <div className="citas-campo">
                <label className="citas-label">Tiempo Estimado:</label>
                <input
                  className="citas-input"
                  type="text"
                  name="tiempoEstimado"
                  value={formData.tiempoEstimado}
                  onChange={handleChange}
                  tabIndex="3"
                />
              </div>
            )}
          </div>

          {/* Columna derecha */}
          <div className="columna-form">
            <div className="citas-campo">
              <label className="citas-label" id='cita-editar-nombre'>Nombre completo del cliente:</label>
              {camposPersonalesRestringidos ? (
                <div className="campo-texto-solo-lectura">
                  <p className="texto-restringido">{formData.nombreCompletoCliente || "Sin nombre"}</p>
                </div>
              ) : (
                <input
                  className="citas-input"
                  type="text"
                  name="nombreCompletoCliente"
                  value={formData.nombreCompletoCliente}
                  onChange={handleChange}
                  required
                  tabIndex="4"
                />
              )}
            </div>

            <div className="citas-campo">
              <label className="citas-label">Fecha:</label>
              <input
                className="citas-input"
                type="datetime-local"
                name="fecha"
                value={formData.fecha}
                min={minDateTime}
                onChange={handleChange}
                tabIndex="5"
              />
            </div>

            {isAdmin && (
              <>
                <div className="citas-campo">
                  <label className="citas-label">Estado de la Cita:</label>
                  <select
                    className="citas-input"
                    name="estado"
                    value={formData.estado}
                    onChange={handleChange}
                    required
                    tabIndex="6"
                  >
                    <option value="pendiente">Pendiente</option>
                    <option value="confirmada">Confirmada</option>
                    <option value="cancelada">Cancelada</option>
                  </select>
                </div>

                {formData.estado === 'cancelada' && (
                  <div className="citas-campo motivo-cancelacion-campo">
                    <label className="citas-label">Motivo de Cancelación:</label>
                    <textarea
                      className="citas-textarea motivo-cancelacion"
                      name="motivoCancelacion"
                      value={motivoCancelacion}
                      onChange={handleChange}
                      placeholder="Indique el motivo de la cancelación"
                      required
                      tabIndex="7"
                    ></textarea>
                  </div>
                )}

                <div className="citas-campo">
                  <label className="citas-label">Precio:</label>
                  <input
                    className="citas-input"
                    type="number"
                    name="precio"
                    value={formData.precio}
                    onChange={handleChange}
                    required
                    tabIndex={formData.estado === 'cancelada' ? "8" : "7"}
                    min={0}
                  />
                </div>
              </>
            )}

            <div className="chat-box">
              <label>Chat con el tatuador:</label>
              <div className="chat-messages">
                {conversacion.length > 0 ? (
                  conversacion.map((msg, i) => {
                    const esMio = String(msg.userId) === String(userId);
                    return (
                      <div key={uuidv4()} className={`msg ${esMio ? 'user' : 'admin'}`}>
                        <div className="msg-contenido">
                          {mensajeEnEdicion === i ? (
                            <input
                              className="edit-msg-input"
                              value={textoTemporal}
                              onChange={(e) => setTextoTemporal(e.target.value)}
                              onBlur={() => finalizarEdicion(i)}
                              onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                  finalizarEdicion(i);
                                } else if (e.key === 'Escape') {
                                  cancelarEdicion();
                                }
                              }}
                              autoFocus
                            />
                          ) : (
                            <span>{msg.text}</span>
                          )}
                          {esMio && (
                            <div className="msg-opciones" ref={menuRef}>
                              <button 
                                type="button"
                                onClick={() => setMenuActivo(menuActivo === i ? null : i)} 
                                className="menu-btn"
                              >
                                ⋮
                              </button>
                              {menuActivo === i && (
                                <div className="msg-menu">
                                  <div onClick={() => editarMensaje(i)}>Editar</div>
                                  <div onClick={() => eliminarMensaje(i)}>Eliminar</div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="no-messages">
                    <p>No hay mensajes en la conversación</p>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
              <div className="chat-input">
                <input
                  type="text"
                  value={nuevoMensaje}
                  onChange={(e) => setNuevoMensaje(e.target.value)}
                  placeholder="Escribe un mensaje"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      agregarMensaje();
                    }
                  }}
                />
                <button
                  type="button"
                  id="enviar-mensaje-boton"
                  onClick={agregarMensaje}
                >
                  <img src={enviar} id='foto-enviar' className="enviar-editar-cita" alt="Enviar" />
                </button>
              </div>
            </div>
          
          </div>
        </div>
        <button id="guardar-boton" type="submit" className="citas-boton">Guardar cambios</button>
        <button id="volver-boton-c" type="button" className="citas-boton" onClick={handleBack}>Volver</button>
      </form>
    </div>
  );
};

export default EditarCitaTatuaje;