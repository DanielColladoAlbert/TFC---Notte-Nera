import { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Swal from "sweetalert2";
import "../../../css/citas/C-Crear.css";
import "../../../css/base/sweetAlert.css";
import storage from "../../../Storage/storage";
import enviar from "../../../assets/Imagenes/enviar.png";
import { v4 as uuidv4 } from 'uuid';

const BASE_URL = "http://localhost:3016";

const CrearCita = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const preloadedData = location.state?.preloadedData || {};

  const [userId, setUserId] = useState(null);
  const [foto, setFoto] = useState(null);
  const [fotoPreview, setFotoPreview] = useState(preloadedData.foto || null);
  const [minDateTime, setMinDateTime] = useState("");
  const [isExclusive, setIsExclusive] = useState(false);
  
  // Estados para el chat
  const [conversacion, setConversacion] = useState([]);
  const [nuevoMensaje, setNuevoMensaje] = useState("");
  const [mensajeEnEdicion, setMensajeEnEdicion] = useState(null);
  const [textoTemporal, setTextoTemporal] = useState(""); // Estado para el texto temporal
  const [menuActivo, setMenuActivo] = useState(null);
  
  // Referencias para el chat
  const menuRef = useRef(null);
  const chatEndRef = useRef(null);
  
  const [formData, setFormData] = useState({
    clienteId: "",
    nombreCompletoCliente: "",
    descripcion: preloadedData.descripcion || "",
    tamano: preloadedData.tamano || "",
    fecha: "",
    precio: preloadedData.precio || "",
    tiempoEstimado: preloadedData.tiempoEstimado || "",
    estado: "pendiente",
    disenoId: preloadedData.disenoId || ""
  });

  const [initialFormData, setInitialFormData] = useState({ ...formData });

  const readOnlyFields = {
    descripcion: !!preloadedData.descripcion,
    tamano: !!preloadedData.tamano
  };

  const authUser = storage.get("authUser");
  const isAdmin = authUser?.profile === "ADMIN";

  // Verificar si el diseño ya fue realizado
const yaRealizado = String(preloadedData.yaRealizado).toLowerCase() === "true";

  useEffect(() => {
    if (authUser && authUser._id) {
      setUserId(authUser._id);
    }
  }, [authUser]);

  useEffect(() => {
    const now = new Date();
    const formatted = now.toISOString().slice(0, 16);
    setMinDateTime(formatted);
  }, []);

  useEffect(() => {
    return () => {
      if (fotoPreview && !fotoPreview.startsWith('http')) {
        URL.revokeObjectURL(fotoPreview);
      }
    };
  }, [fotoPreview]);

  // Para manejar clicks fuera del menú del chat
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuActivo(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Para scroll automático del chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversacion]);

  const hasChanges = () => {
    return Object.keys(formData).some(key => 
      formData[key] !== initialFormData[key]
    ) || foto !== null || isExclusive || conversacion.length > 0;
  };

  const handleFileChange = (e) => {
    if (preloadedData.foto) return;
    const file = e.target.files[0];
    const imageRegex = /\.(jpe?g|png|gif)$/i;

    if (file && !imageRegex.test(file.name)) {
      Swal.fire({
        icon: "error",
        title: "Archivo no válido",
        text: "Solo se permiten imágenes en formato JPEG, JPG, PNG o GIF.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      setFoto(null);
      setFotoPreview(null);
    } else {
      setFoto(file);
      setFotoPreview(URL.createObjectURL(file));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (readOnlyFields[name]) return;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleBack = async (e) => {
    e.preventDefault();
    if (hasChanges()) {
      const result = await Swal.fire({
        title: '¿De verdad quieres volver?',
        text: 'No se guardarán los cambios realizados.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, volver',
        cancelButtonText: 'Cancelar',
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-confirm-button",
        }
      });
      if (result.isConfirmed) navigate(-1);
    } else {
      navigate(-1);
    }
  };

  // Función para agregar mensaje al chat
  const agregarMensaje = () => {
    if (!nuevoMensaje.trim()) return;
    
    const nuevo = { userId, text: nuevoMensaje.trim() };
    setConversacion(prev => [...prev, nuevo]);
    setNuevoMensaje("");
  };

  // Función para iniciar la edición de un mensaje
  const editarMensaje = (index) => {
    setMensajeEnEdicion(index);
    setTextoTemporal(conversacion[index].text); // Guardar el texto original
    setMenuActivo(null); // Cerrar el menú
  };

  // Función para finalizar la edición con validación
  const finalizarEdicion = (index) => {
    if (textoTemporal.trim()) {
      // Actualizar el mensaje con el texto temporal
      const copia = [...conversacion];
      copia[index].text = textoTemporal.trim();
      setConversacion(copia);
    }
    // Limpiar estados de edición
    setMensajeEnEdicion(null);
    setTextoTemporal("");
  };

  // Función para cancelar la edición
  const cancelarEdicion = () => {
    setMensajeEnEdicion(null);
    setTextoTemporal("");
  };

  // Función para eliminar mensaje
  const eliminarMensaje = (index) => {
    const nuevaConversacion = conversacion.filter((_, idx) => idx !== index);
    setConversacion(nuevaConversacion);
    setMenuActivo(null);
  };

  // Función para calcular el precio final 
  const calcularPrecioFinal = () => {
    const precioBase = parseFloat(formData.precio) || 0;
    const precioExclusivo = parseFloat(preloadedData.precioExclusivo) || 0;
    
    if (isExclusive && preloadedData.disenoId) {
      return precioBase + precioExclusivo;
    }
    return precioBase;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const precioBase = parseFloat(formData.precio) || 0;
    const precioFinal = (preloadedData.disenoId && isExclusive)
      ? precioBase + (parseFloat(preloadedData.precioExclusivo) || 0)
      : precioBase;

    const submitData = new FormData();

    const updatedFormData = { ...formData, precio: precioFinal };

    Object.entries(updatedFormData).forEach(([key, value]) => {
      submitData.append(key, value);
    });

    if (conversacion.length > 0) {
      submitData.append("conversacion", JSON.stringify(conversacion));
    }

    if (foto) {
      submitData.append("foto", foto);
    } else if (preloadedData.foto) {
      submitData.append("fotoUrl", preloadedData.foto);
      submitData.append("usarFotoDiseno", "true");
    }

    try {
      const token = localStorage.getItem('authToken');
      if (!token) throw new Error("No hay sesión activa");

      const isTokenExpired = (token) => {
        try {
          const payload = JSON.parse(atob(token.split('.')[1]));
          return payload.exp * 1000 < Date.now();
        } catch {
          return true;
        }
      };

      if (isTokenExpired(token)) {
        localStorage.clear();
        Swal.fire({ icon: "warning", title: "Sesión expirada", text: "Por favor, inicia sesión de nuevo." });
        navigate("/api/iniciarSesion");
        return;
      }

      const response = await fetch(`${BASE_URL}/api/citas/nueva`, {
        method: "POST",
        body: submitData,
        credentials: "include",
        headers: { 'Accept': 'application/json', 'Authorization': `Bearer ${token}` }
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || "No se pudo crear la cita.");

      if (isExclusive && formData.disenoId) {
        const patchResponse = await fetch(`${BASE_URL}/api/disenosDisponibles/editar/disponible/${formData.disenoId}`, {
          method: "PATCH",
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ disponible: false })
        });

        if (!patchResponse.ok) {
          const patchData = await patchResponse.json();
          throw new Error(patchData?.error || "No se pudo actualizar el diseño.");
        }
      }

      Swal.fire({
        icon: "success",
        title: "Cita creada",
        text: "La cita se ha creado correctamente.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });

      navigate("/api/citas");
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error.message,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  return (
    <div className="crear-cita-container">
      <form onSubmit={handleSubmit} encType="multipart/form-data" className="crear-cita-form">
        <div id="c-foto">
          <br/>
          <label htmlFor="foto" id="foto-label">Foto:</label><br />
          <input
            type="file"
            id="foto"
            accept="image/jpeg, image/jpg, image/png, image/gif"
            onChange={handleFileChange}
            className="cita-foto"
            disabled={!!preloadedData.foto}
            tabIndex="1"
            required
          />
          <div className="image-container">
            {fotoPreview && <img src={fotoPreview} alt="Previsualización del tatuaje" className="fotoPreview" />}
          </div>
        </div>

        <div id="c-nombreCompleto">
          <label htmlFor="nombreCompletoCliente" id="nombreCompleto-label">Nombre completo del cliente:</label><br />
          <input
            type="text"
            name="nombreCompletoCliente"
            id="nombreCompletoCliente"
            value={formData.nombreCompletoCliente}
            onChange={handleInputChange}
            required
            tabIndex="2"
          />
        </div>

        <div>
          <label htmlFor="descripcion">Descripción:</label><br />
          <textarea
            name="descripcion"
            id="descripcion"
            value={formData.descripcion}
            onChange={handleInputChange}
            required
            readOnly={readOnlyFields.descripcion}
            className={readOnlyFields.descripcion ? "readonly-field" : ""}
            tabIndex="3"
          />
        </div>

        <div>
          <label htmlFor="fecha">Fecha y hora de la Cita:</label><br />
          <input
            type="datetime-local"
            name="fecha"
            id="fecha"
            value={formData.fecha}
            onChange={handleInputChange}
            min={minDateTime}
            required
            tabIndex="4"
          />
        </div>

        <div>
          <label htmlFor="tamano">Tamaño:</label><br />
          <input
            type="text"
            name="tamano"
            id="tamano"
            placeholder="Ej: 00cm x 00cm"
            value={formData.tamano}
            onChange={handleInputChange}
            required
            readOnly={readOnlyFields.tamano}
            className={readOnlyFields.tamano ? "readonly-field" : ""}
            tabIndex="5"
            style={{ marginBottom: '60px' }}
          />
        </div>
      {(isAdmin || (preloadedData.precio && preloadedData.disenoId)) && (
        <div>
          <label htmlFor="precio">Precio:</label><br />
          <input
            type="number"
            name="precio"
            id="precio"
            value={formData.precio}
            onChange={handleInputChange}
            readOnly={!isAdmin} 
            className={!isAdmin ? "readonly-field" : ""}
            tabIndex="6"
            min={0}
          />
          <div className="precio-final-container" style={{ minHeight: '50px' }}>
            {isExclusive && preloadedData.disenoId && (
              <small className="precioExclusivo-aviso">
                Se te quedará en: {calcularPrecioFinal()}€
                <br/>
                <p  style={{ color: '#ffdd00' }}> - - No se puede cambiar la exclusividad una vez creada la cita - -</p>
              </small>
            )}
          </div>
        </div>
      )}

      {(readOnlyFields.descripcion || readOnlyFields.tamano) && (
        <>
          {yaRealizado === true ? (
            <div>
              <label htmlFor="sinExclusividad">Sin exclusividad:</label><br />
              <input
                id="sinExclusividad"
                name="sinExclusividad"
                type="text"
                value="El tatuaje ya ha sido realizado previamente"
                readOnly
                className="readonly-field"
              />
            </div>
          ) : (
            <div id="reserva-dd-cita">
              <div {...(!isAdmin ? { id: "precioExclusivo-crear-c" } : {})}>
                <label htmlFor="precioExclusivo" id="precioExclusivo-label" className="preEx">
                  Hacer tu tatuaje exclusivo por {(parseFloat(preloadedData.precioExclusivo) || 0)}€ más? 
                </label>
                <input
                  id="precioExclusivo-cb"
                  name="precioExclusivo"
                  type="checkbox"
                  checked={isExclusive}
                  onChange={(e) => setIsExclusive(e.target.checked)}
                />
              </div>
            </div>
          )}
        </>
      )}

        {isAdmin && (
          <>
            <div id={
              (readOnlyFields.descripcion || readOnlyFields.tamano)
                ? "tiempo-estimado-c"
                : ""
            }>
              <label htmlFor="tiempoEstimado">Tiempo estimado:</label><br />
              <input
                type="text"
                name="tiempoEstimado"
                id="tiempoEstimado"
                value={formData.tiempoEstimado}
                onChange={handleInputChange}
                tabIndex="7"
              />
            </div>
            <div>
              <label htmlFor="estado">Estado de la Cita:</label><br />
              <select
                name="estado"
                id="estado"
                value={formData.estado}
                onChange={handleInputChange}
                tabIndex="8"
              >
                <option value="pendiente">Pendiente</option>
                <option value="confirmada">Confirmada</option>
              </select>
            </div>
          </>
        )}

        {/* Sección del Chat */}
        <div className="chat-box">
          <label>Chat con el tatuador:</label>
          <div className="chat-messages">
            {conversacion.map((msg, i) => {
              const esMio = String(msg.userId) === String(userId);
              return (
                <div key={uuidv4()} className={`msg ${esMio ? 'user' : 'admin'}`}>
                  <div className="msg-contenido">
                    {mensajeEnEdicion === i ? (
                      <input
                        className="edit-msg-input"
                        value={textoTemporal}
                        onChange={(e) => setTextoTemporal(e.target.value)}
                        onBlur={() => finalizarEdicion(i)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            finalizarEdicion(i);
                          } else if (e.key === 'Escape') {
                            cancelarEdicion();
                          }
                        }}
                        autoFocus
                      />
                    ) : (
                      <span>{msg.text}</span>
                    )}
                    {esMio && (
                      <div className="msg-opciones" ref={menuRef}>
                        <button 
                          type="button"
                          onClick={() => setMenuActivo(menuActivo === i ? null : i)} 
                          className="menu-btn"
                        >
                          ⋮
                        </button>
                        {menuActivo === i && (
                          <div className="msg-menu">
                            <div onClick={() => editarMensaje(i)}>Editar</div>
                            <div onClick={() => eliminarMensaje(i)}>Eliminar</div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>
          <div className="chat-input">
            <input
              type="text"
              value={nuevoMensaje}
              onChange={(e) => setNuevoMensaje(e.target.value)}
              placeholder="Escribe un mensaje"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  agregarMensaje();
                }
              }}
            />
            <button
              type="button"
              id="enviar-mensaje-boton"
              onClick={agregarMensaje}
            >
              <img src={enviar} id='foto-enviar' className="enviar-crear-cita" alt="Enviar" />
            </button>
          </div>
        </div>

        <div className={`botones-container ${isAdmin ? "admin-buttons" : ""}`}>
          <button className="cita-crear" type="submit">Crear Cita</button>
          <button className="cita-volver" type="button" onClick={handleBack}>Volver</button>
        </div>

      </form>
    </div>
  );
};

export default CrearCita;