import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";
import "../../../css/tatuajesRealizados/TR-Editar.css";
import "../../../css/base/sweetAlert.css";
import { sendRequest } from "../../../functions";
import axios from "axios";

const BASE_URL = "http://localhost:3016";

const Editar = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    foto: null,
    titulo: "",
    descripcion: "",
    tamano: "",
    tipo: "",
    fecha: "",
    nombreCliente: ""
  });

  const [originalFoto, setOriginalFoto] = useState("");
  const [loading, setLoading] = useState(true);
  const [preview, setPreview] = useState("");
  const [isDirty, setIsDirty] = useState(false);

  useEffect(() => {
    const fetchTatuaje = async () => {
      try {
        const data = await sendRequest("GET", null, `${BASE_URL}/api/tatuajesRealizados/editar/${id}`);
        if (!data) throw new Error("No se pudo obtener el tatuaje.");

        setFormData({
          foto: null,
          titulo: data.data.titulo || "",
          descripcion: data.data.descripcion || "",
          tamano: data.data.tamano || "",
          tipo: data.data.tipo || "",
          fecha: data.data.fecha ? data.data.fecha.slice(0, 10) : "",
          nombreCliente: data.data.nombreCliente || ""
        });

        if (data.data.foto) {
          setOriginalFoto(`${BASE_URL}${data.data.foto}`);
        }
      } catch (error) {
        console.error("Error al obtener los datos:", error);
        Swal.fire({
          title: "Error",
          text: error.message,
          icon: "error",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        navigate("/api/");
      } finally {
        setLoading(false);
      }
    };

    fetchTatuaje();
  }, [id, navigate]);

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);

  const handleChange = (e) => {
    setIsDirty(true);
    const { name, value, files } = e.target;
    if (name === "foto") {
      const file = files[0];
      if (file && /\.(jpe?g|png|gif)$/i.test(file.name)) {
        setFormData((prev) => ({ ...prev, foto: file }));
        const reader = new FileReader();
        reader.onload = () => setPreview(reader.result);
        reader.readAsDataURL(file);
      } else {
        Swal.fire({
          title: "Formato inválido",
          text: "Solo se permiten imágenes JPEG, JPG, PNG o GIF.",
          icon: "error",
          confirmButtonText: "Entendido",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
      }
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (value) data.append(key, value);
    });

    try {
      const token = localStorage.getItem("authToken");
      const response = await axios.patch(`${BASE_URL}/api/tatuajesRealizados/editar/${id}`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      Swal.fire({
        title: "Éxito",
        text: "Los cambios se han guardado correctamente.",
        icon: "success",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      setIsDirty(false);
      navigate(-1);
    } catch (error) {
      console.error(error);
      Swal.fire({
        title: "Error",
        text: (error.response?.data?.message) || "No se pudo guardar los cambios.",
        icon: "error",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  const handleVolver = () => {
    if (isDirty) {
      Swal.fire({
        title: "¿Estás seguro de que quieres salir?",
        text: "Los cambios no se guardarán.",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sí, salir",
        cancelButtonText: "Cancelar",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-cancel-button",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate(-1);
        }
      });
    } else {
      navigate(-1);
    }
  };

  if (loading) {
    return <div className="editar-tatuaje-container">Cargando...</div>;
  }

  return (
    <div className="editar-tatuaje-container">
      <div className="editar-tatuaje-content">
        <form onSubmit={handleSubmit} encType="multipart/form-data" className="editar-tatuaje-form">
          <div className="editar-tatuaje-left-column">
            <label htmlFor="foto" className="editar-tatuaje-label" id="editar-foto-nueva">Foto</label>
            <input
              type="file"
              name="foto"
              id="foto"
              accept="image/jpeg, image/jpg, image/png, image/gif"
              onChange={handleChange}
              className="editar-tatuaje-file"
              tabIndex="1"
            />
            {(preview || originalFoto) && (
              <div className="imagen-previa">
                <p id="editar-tatuaje-p">Foto actual:</p>
                <img
                  src={preview || originalFoto}
                  alt="Imagen previa"
                  className="editar-tatuaje-imagen-previa"
                />
              </div>
            )}
          </div>
          <div className="editar-tatuaje-right-column">
            <label htmlFor="titulo" className="editar-tatuaje-label">Título</label>
            <input
              type="text"
              name="titulo"
              id="titulo"
              value={formData.titulo}
              onChange={handleChange}
              className="editar-tatuaje-input"
              required
              tabIndex="2"
            />
            <label htmlFor="descripcion" className="editar-tatuaje-label">Descripción</label>
            <textarea
              name="descripcion"
              id="descripcion"
              value={formData.descripcion}
              onChange={handleChange}
              className="editar-tatuaje-textarea"
              required
              maxLength="250"
              rows="5"
              cols="50"
              tabIndex="3"
            />
            <label htmlFor="tamano" className="editar-tatuaje-label">Tamaño</label>
            <input
              type="text"
              name="tamano"
              id="tamano"
              value={formData.tamano}
              onChange={handleChange}
              className="editar-tatuaje-input"
              required
              tabIndex="4"
            />
            <label htmlFor="tipo" className="editar-tatuaje-label">Estilo</label>
            <input
              type="text"
              name="tipo"
              id="tipo"
              value={formData.tipo}
              onChange={handleChange}
              className="editar-tatuaje-input"
              tabIndex="5"
            />
            <label htmlFor="fecha" className="editar-tatuaje-label">Fecha</label>
            <input
              type="date"
              name="fecha"
              id="fecha"
              value={formData.fecha}
              onChange={handleChange}
              className="editar-tatuaje-input"
              tabIndex="6"
            />
            <label htmlFor="tipo" className="editar-tatuaje-label">Nombre del cliente</label>
            <input
              type="text"
              name="nombreCliente"
              id="nombreCliente"
              value={formData.nombreCliente}
              onChange={handleChange}
              className="editar-tatuaje-input"
              tabIndex="5"
            />
            <button type="submit" className="editar-tatuaje-button" id="tr-guardar-boton">Guardar cambios</button>
          </div>
        </form>
        <button type="button" onClick={handleVolver} className="editar-tatuaje-button" id="tr-volver-boton">Volver</button>
      </div>
    </div>
  );
};

export default Editar;
