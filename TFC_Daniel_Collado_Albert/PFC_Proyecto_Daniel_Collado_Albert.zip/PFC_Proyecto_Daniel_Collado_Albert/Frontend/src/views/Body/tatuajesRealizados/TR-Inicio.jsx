import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2'; 
import "../../../css/tatuajesRealizados/TR-Inicio.css";
import imagenError from "../../../assets/Imagenes/error-imagen.png";
import imagenErrorBlanco from "../../../assets/Imagenes/error-imagen-blanco.png";

const BASE_URL = "http://localhost:3016"; 

const Inicio = () => {
    const navigate = useNavigate();
    const [authUser, setAuthUser] = useState(null); 
    const [tatuajes, setTatuajes] = useState([]); 
    const [loading, setLoading] = useState(true);

    const isTokenExpired = (token) => {
        try {

            if (!token || token.split('.').length !== 3) {
                throw new Error("Token no tiene el formato JWT válido.");
            }

            const payloadEncoded = token.split('.')[1]; 
            const payloadDecoded = atob(payloadEncoded); 
            const payload = JSON.parse(payloadDecoded); 

            return payload.exp * 1000 < Date.now();
        } catch (error) {
            console.error("Error al procesar el token:", error.message);
            return true; 
        }
    };

    useEffect(() => {
        const storedUser = localStorage.getItem("authUser");
        const storedToken = localStorage.getItem("authToken");

        if (storedUser && storedToken && !isTokenExpired(storedToken)) {
            setAuthUser(JSON.parse(storedUser));
            fetchTatuajes(storedToken);
        } else {
            console.error("Token inválido o caducado");
            localStorage.removeItem("authToken");
            localStorage.removeItem("authUser");
            navigate('/api/iniciarSesion'); 
        }
    }, [navigate]);

    const fetchTatuajes = async (token) => {
        try {
            setLoading(true); 
            const response = await fetch(`${BASE_URL}/api/tatuajesRealizados/`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            });

            if (!response.ok) {
                if (response.status === 401) {
                    console.error("Token inválido o caducado");
                    localStorage.removeItem("authToken");
                    localStorage.removeItem("authUser");
                    navigate('/api/iniciarSesion'); 
                } else {
                    const errorMsg = await response.text();
                    throw new Error(`Error en la solicitud: ${errorMsg}`);
                }
            }

            const data = await response.json(); 

            setTatuajes(data.data);
        } catch (error) {
            console.error('Error fetching tatuajes:', error);
        } finally {
            setLoading(false); 
        }
    };

    const handleDelete = async (id) => {
        try {
            const token = localStorage.getItem("authToken");
            if (!token) {
                console.error("No se encontró el token");
                return;
            }

            const response = await fetch(`${BASE_URL}/api/tatuajesRealizados/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            });

            if (!response.ok) {
                const errorMsg = await response.text();
                throw new Error(`Error eliminando el tatuaje: ${errorMsg}`);
            }

            setTatuajes(tatuajes.filter(tatuaje => tatuaje._id !== id)); 
            Swal.fire({
                title: 'Éxito',
                text: 'El tatuaje ha sido eliminado correctamente.',
                icon: 'success',
                customClass: {
                    popup: "custom-popup",
                    title: "custom-title",
                    content: "custom-content",
                    confirmButton: "custom-confirm-button",
                }
            });
        } catch (error) {
            console.error('Error eliminando el tatuaje:', error);
            Swal.fire({
                title: 'Error',
                text: 'No se pudo eliminar el tatuaje.',
                icon: 'error',
                customClass: {
                    popup: "custom-popup",
                    title: "custom-title",
                    content: "custom-content",
                    confirmButton: "custom-confirm-button",
                }
            });
        }
    };

    const confirmDelete = (id) => {
        Swal.fire({
            title: '¿Quieres eliminar este tatuaje?',
            text: "Esta acción no se puede deshacer.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            customClass: {
                popup: "custom-popup",
                title: "custom-title",
                content: "custom-content",
                confirmButton: "custom-confirm-button",
                cancelButton: "custom-confirm-button",
            },
        }).then((result) => {
            if (result.isConfirmed) {
                handleDelete(id);
            }
        });
    };

    const isAdmin = authUser?.profile === "ADMIN";
    
    if (loading) {
        return <div id="inicio-container">Cargando...</div>; 
    }

    return (
        
        <div id="inicio-contenedor">
            <h1 className='titulo-resenas' id="tr-titulo">Tatuajes Realizados</h1>
            <div id="tatuajes-contenedor">
                {tatuajes && tatuajes.length > 0 ? (
                    <ul className="tr-tatuajes-lista">
                        {tatuajes.map((tatuaje) => (
                            <li key={tatuaje._id} className="tr-tatuaje-item">
                                <img
                                    src={tatuaje.foto ? `${BASE_URL}${tatuaje.foto}` : imagenError}
                                    alt={`Imagen del tatuaje: ${tatuaje.titulo}`}
                                    className="tr-tatuaje-img"
                                    onError={(e) => (e.target.src = imagenError)}
                                />
                                <div className="tr-info-contenedor">
                                    <h3>{tatuaje.titulo}</h3>
                                    <p><strong>Descripción:</strong> {tatuaje.descripcion}</p>
                                    <p><strong>Tamaño:</strong> {tatuaje.tamano || 'No especificado'}</p>
                                    <p><strong>Estilo:</strong> {tatuaje.tipo || 'No especificado'}</p>
                                    <p><strong>Fecha:</strong> {
                                        tatuaje.fecha
                                            ? new Date(tatuaje.fecha).toLocaleDateString('es-ES')
                                            : new Date().toLocaleDateString('es-ES')
                                    }</p>
                                      {isAdmin && (
                                     <p><strong>Nombre del cliente:</strong> {tatuaje.nombreCliente}</p>
                                     )}
                                    </div>
                                    {isAdmin && (
                                        <div className="tr-editar-eliminar">
                                            <button
                                                className="tr-boton-editar"
                                                onClick={() => navigate(`editar/${tatuaje._id}`)}
                                            >
                                                Editar
                                            </button>
                                            <button
                                                className="tr-delete-button"
                                                onClick={() => confirmDelete(tatuaje._id)}
                                            >
                                                Eliminar
                                            </button>
                                        </div>
                                    )}
                                
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="tr-tatuaje-vacio">
                        <img src={imagenErrorBlanco} alt="No hay tatuajes" className="tr-tatuaje-vacio-img" />
                        <h2>No hay tatuajes realizados.</h2>
                    </div>
                )}
                <div className="tr-nuevo-volver">
                    {isAdmin && (
                        <button
                            className="tr-boton-nuevo"
                            onClick={() => navigate('/api/tatuajesRealizados/nuevo')}
                        >
                            Añadir nuevo tatuaje
                        </button>
                    )}
                    <button className="tr-boton-volver" type="button" onClick={() => navigate('/')}>
                        Volver
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Inicio;
