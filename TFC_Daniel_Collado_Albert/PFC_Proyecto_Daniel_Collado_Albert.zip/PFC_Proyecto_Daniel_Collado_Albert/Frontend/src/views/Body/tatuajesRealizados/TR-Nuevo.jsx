import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import "../../../css/tatuajesRealizados/TR-Nuevo.css";
import "../../../css/base/sweetAlert.css";

const BASE_URL = "http://localhost:3016"; 

const Nuevo = () => {
  const [foto, setFoto] = useState(null);
  const [fotoPreview, setFotoPreview] = useState(null);
  const [tatuajesRealizados, setTatuajesRealizados] = useState({
    titulo: "",
    descripcion: "",
    tamano: "",
    tipo: "",
    fecha: "",
    foto: null,
    nombreCliente: ""
  });
  const [isDirty, setIsDirty] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const imageRegex = /\.(jpe?g|png|gif)$/i;

    if (file && !imageRegex.test(file.name)) {
      Swal.fire({
        icon: "error",
        title: "Extensión no permitida",
        text: "Solo se permiten imágenes con las extensiones JPEG, JPG, PNG o GIF.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      setFoto(null);
      setFotoPreview(null);
    } else {
      setFoto(file);
      setFotoPreview(URL.createObjectURL(file));
      setTatuajesRealizados((prev) => ({ ...prev, foto: file }));
      setIsDirty(true);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTatuajesRealizados((prev) => ({ ...prev, [name]: value }));
    setIsDirty(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const imageRegex = /\.(jpe?g|png|gif)$/i;

    if (foto && !imageRegex.test(foto.name)) {
      Swal.fire({
        icon: "error",
        title: "Extensión no permitida",
        text: "Solo se permiten imágenes con las extensiones JPEG, JPG, PNG o GIF.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    const fechaSeleccionada = new Date(tatuajesRealizados.fecha);
    const fechaActual = new Date();

    fechaSeleccionada.setHours(0, 0, 0, 0);
    fechaActual.setHours(0, 0, 0, 0);

    if (fechaSeleccionada > fechaActual) {
      Swal.fire({
        icon: "error",
        title: "Fecha no válida",
        text: "La fecha de realización no puede ser superior a la fecha actual.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }

    const formData = new FormData();
    Object.entries(tatuajesRealizados).forEach(([key, value]) => {
      formData.append(key, value);
    });

    const token = localStorage.getItem('authToken');

    try {
      const response = await fetch(`${BASE_URL}/api/tatuajesRealizados/nuevo`, {
        method: "POST",
        body: formData,
        credentials: "include",
        headers: {
          'Authorization': `Bearer ${token}`
        },
      });

      if (!response.ok) {
        let errorMessage = "No se pudo crear el tatuaje.";
        try {
          const errorData = await response.json();
          errorMessage = errorData?.errorMessage || errorMessage;
        } catch (e) {
          errorMessage = `Error: ${response.status} ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();

      Swal.fire({
        icon: "success",
        title: "Tatuaje creado",
        text: "El tatuaje se ha creado correctamente.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      setIsDirty(false);
      navigate(-1);
    } catch (error) {
      console.error("Error al enviar:", error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error.message,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    }
  };

  return (
    <div className="crear-tatuaje-container">
      <div className="crear-tatuaje-content">
        <form
          onSubmit={handleSubmit}
          className="crear-tatuaje-form"
          encType="multipart/form-data"
        >
          <div className="crear-tatuaje-left-column">
            <div>
              <label htmlFor="foto" className="crear-tatuaje-label">Foto:</label><br />
              <input
                type="file"
                name="foto"
                id="foto"
                className="crear-tatuaje-file"
                accept="image/jpeg, image/jpg, image/png, image/gif"
                onChange={handleFileChange}
                required
                tabIndex="1"
              />
            </div>
            {fotoPreview && (
              <div className="imagen-previa">
                <p>Imagen previa:</p>
                <img
                  src={fotoPreview}
                  alt="Imagen previa"
                  className="crear-tatuaje-imagen-previa"
                />
              </div>
            )}
          </div>
          <div className="crear-tatuaje-right-column">
            <div>
              <label htmlFor="titulo" className="crear-tatuaje-label">Título:</label><br />
              <input
                type="text"
                name="titulo"
                id="titulo"
                className="crear-tatuaje-input"
                value={tatuajesRealizados.titulo}
                onChange={handleInputChange}
                required
                tabIndex="2"
              />
            </div>
            <div>
              <label htmlFor="descripcion" className="crear-tatuaje-label">Descripción:</label><br />
              <textarea
                name="descripcion"
                id="descripcion"
                className="crear-tatuaje-textarea"
                value={tatuajesRealizados.descripcion}
                onChange={handleInputChange}
                maxLength="250"
                required
                tabIndex="3"
              />
            </div>
            <div>
              <label htmlFor="tamano" className="crear-tatuaje-label">Tamaño:</label><br />
              <input
                type="text"
                name="tamano"
                id="tamano"
                className="crear-tatuaje-input"
                value={tatuajesRealizados.tamano}
                onChange={handleInputChange}
                placeholder="Ej: 00cm x 00cm"
                tabIndex="4"
              />
            </div>
            <div>
              <label htmlFor="tipo" className="crear-tatuaje-label">Estilo:</label><br />
              <input
                type="text"
                name="tipo"
                id="tipo"
                className="crear-tatuaje-input"
                value={tatuajesRealizados.tipo}
                onChange={handleInputChange}
                tabIndex="5"
              />
            </div>
            <div>
              <label htmlFor="fecha" className="crear-tatuaje-label">Fecha de Realización:</label><br />
              <input
                type="date"
                name="fecha"
                id="fecha"
                className="crear-tatuaje-input"
                value={tatuajesRealizados.fecha}
                onChange={handleInputChange}
                tabIndex="6"
              />
            </div>
            <div>
              <label htmlFor="nombreCliente" className="crear-tatuaje-label">Nombre del cliente:</label><br />
              <input
                type="text"
                name="nombreCliente"
                id="nombreCliente"
                className="crear-tatuaje-input"
                value={tatuajesRealizados.nombreCliente}
                onChange={handleInputChange}
                tabIndex="7"
                required="true"
              />
            </div>
            <div className="crear-tatuaje-buttons-container">
              <button type="submit" className="crear-tatuaje-button">Crear Tatuaje</button>
              <button
                type="button"
                className="crear-tatuaje-button"
                onClick={() => {
                  if (isDirty) {
                    Swal.fire({
                      title: "¿Estás seguro de que quieres salir?",
                      text: "Los cambios no se guardarán.",
                      icon: "warning",
                      showCancelButton: true,
                      confirmButtonText: "Sí, salir",
                      cancelButtonText: "Cancelar",
                      customClass: {
                        popup: "custom-popup",
                        title: "custom-title",
                        content: "custom-content",
                        confirmButton: "custom-confirm-button",
                        cancelButton: "custom-cancel-button",
                      },
                    }).then((result) => {
                      if (result.isConfirmed) {
                        navigate(-1);
                      }
                    });
                  } else {
                    navigate(-1);
                  }
                }}
              >
                Volver
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Nuevo;