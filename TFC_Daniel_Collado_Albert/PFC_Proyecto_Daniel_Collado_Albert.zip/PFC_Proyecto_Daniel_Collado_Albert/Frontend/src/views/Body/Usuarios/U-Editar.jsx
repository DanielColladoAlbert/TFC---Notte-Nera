import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import storage from "../../../Storage/storage";
import "../../../css/usuarios/U-Editar.css";
import "../../../css/base/sweetAlert.css";
import foto_usuario from "../../../assets/Imagenes/foto_usuario_blanco.png";
import ojoAbierto from "../../../assets/Imagenes/ojo_abierto.png";
import ojoCerrado from "../../../assets/Imagenes/ojo_cerrado.png";
import Swal from "sweetalert2";

const BASE_URL = "http://localhost:3016";

const EditarUsuario = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState({
    nombreUsuario: "",
    nombre: "",
    apellidos: "",
    correo: "",
    foto: "",
    perfil: "USUARIO"
  });
  const [originalUser, setOriginalUser] = useState(null); // Datos originales para comparar
  const [loading, setLoading] = useState(true);
  const [imagePreview, setImagePreview] = useState(null);
  const [originalImagePreview, setOriginalImagePreview] = useState(null); // Imagen original
  const [isPhotoDeleted, setIsPhotoDeleted] = useState(false); // Estado para controlar si la foto fue eliminada
  const [errors, setErrors] = useState({});
  const [newPassword, setNewPassword] = useState("");
  const [oldPassword, setOldPassword] = useState("");
  const [repeatPassword, setRepeatPassword] = useState("");
  const [isOldPasswordCorrect, setIsOldPasswordCorrect] = useState(true);
  const [visibleInputs, setVisibleInputs] = useState({
    oldPassword: false,
    newPassword: false,
    repeatPassword: false
  });
  const [hasChanges, setHasChanges] = useState(false); // Para detectar cambios

  const validators = {
    nombreUsuario: (value) => /^[\w@!#$%^&*º()[\]{}\-+=~.]{5,}$/.test(value),
    correo: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value),
    nombre: (value) => /^[\p{L} \-'`´]+$/u.test(value),
    apellidos: (value) => /^[\p{L} \-'`´]+$/u.test(value),
  };

  const checkForChanges = () => {
    if (!originalUser) return false;
    
    // Verificar cambios en campos del usuario
    const userFieldsChanged = Object.keys(originalUser).some(key => 
      originalUser[key] !== user[key]
    );
    
    // Verificar cambios en imagen o si la foto fue eliminada
    const imageChanged = imagePreview !== originalImagePreview || isPhotoDeleted;
    
    // Verificar si hay contraseña nueva
    const passwordChanged = newPassword.trim() !== "" || oldPassword.trim() !== "" || repeatPassword.trim() !== "";
    
    return userFieldsChanged || imageChanged || passwordChanged;
  };

  const validateNewPassword = (password) => {
    if (!password) return true; // Permitir contraseña vacía (no cambiar)
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[-_!?@]).{8,}$/.test(password);
  };

  const toggleVisibility = (field) => {
    setVisibleInputs((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  // Función para eliminar la foto de perfil
  const handleDeletePhoto = () => {
    Swal.fire({
      title: "¿Eliminar foto de perfil?",
      text: "Se restaurará la imagen por defecto",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
      customClass: {
        popup: "custom-popup",
        title: "custom-title",
        content: "custom-content",
        confirmButton: "custom-confirm-button",
        cancelButton: "custom-cancel-button",
      },
    }).then((result) => {
      if (result.isConfirmed) {
        setImagePreview(foto_usuario);
        setIsPhotoDeleted(true);
        // Limpiar el input de archivo
        const fileInput = document.getElementById('foto');
        if (fileInput) {
          fileInput.value = '';
        }
        setErrors((prevErrors) => ({ ...prevErrors, fotoError: false }));
      }
    });
  };

  // Cargar datos del usuario
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = storage.get("authToken");
        const response = await fetch(`${BASE_URL}/api/perfil/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await response.json();

        if (data.status) {
          // No incluir la contraseña 
          const { contrasena, ...userData } = data.user;
          setUser(userData);
          setOriginalUser({...userData}); // Guardar datos originales
          if (data.user.foto) {
            const imageUrl = `${BASE_URL}${data.user.foto}`;
            setImagePreview(imageUrl);
            setOriginalImagePreview(imageUrl); // Guardar imagen original
          }
        } else {
          console.error("Error al obtener los datos del usuario");
        }
      } catch (error) {
        console.error("Error de conexión con el servidor", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, [id]);

  // detectar cambios y actualizar el estado
  useEffect(() => {
    const changes = checkForChanges();
    setHasChanges(changes);
  }, [user, imagePreview, newPassword, oldPassword, repeatPassword, originalUser, originalImagePreview, isPhotoDeleted]);

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasChanges) {
        e.preventDefault();
        e.returnValue = ''; 
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasChanges]);

  // validar en tiempo real
  useEffect(() => {
    const newErrors = {};
    
    // Validar campos del usuario (sin incluir contraseña)
    Object.keys(validators).forEach(field => {
      if (user[field]) {
        const isValid = validators[field](user[field]);
        if (!isValid) {
          newErrors[`${field}Error`] = true;
        }
      }
    });
    
    // Validar nueva contraseña si se ha introducido
    if (newPassword && !validateNewPassword(newPassword)) {
      newErrors.contrasenaError = true;
    }
    
    // Validar que las contraseñas coincidan
    if (newPassword && repeatPassword && newPassword !== repeatPassword) {
      newErrors.repeatPasswordError = true;
    }
    
    setErrors(newErrors);
  }, [user, newPassword, repeatPassword]);

  // Verificar contraseña actual
  const verificarPassword = async (password) => {
    if (!password) return false;
    
    try {
      const token = storage.get("authToken");
      const response = await fetch(`${BASE_URL}/api/verificarContrasena`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id, oldPassword: password }),
      });

      const data = await response.json();
      setIsOldPasswordCorrect(data.valid);
      return data.valid;
    } catch (error) {
      console.error("Error verificando la contraseña actual", error);
      setIsOldPasswordCorrect(false);
      return false;
    }
  };

  // Validar contraseña actual
  useEffect(() => {
    if (oldPassword) {
      const timer = setTimeout(() => {
        verificarPassword(oldPassword);
      }, 500);
      
      return () => clearTimeout(timer);
    } else {
      setIsOldPasswordCorrect(true);
    }
  }, [oldPassword]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const imageRegex = /\.(jpe?g|png|gif)$/i;
    if (file && !imageRegex.test(file.name)) {
      setErrors((prevErrors) => ({ ...prevErrors, fotoError: true }));
      setImagePreview(null);
      e.target.value = "";
      Swal.fire({ 
        icon: "error", 
        title: "Archivo no válido", 
        text: "Solo se permiten imágenes.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }, 
      });
      return;
    }
    setErrors((prevErrors) => ({ ...prevErrors, fotoError: false }));
    setIsPhotoDeleted(false); // Resetear el estado de eliminación si se selecciona una nueva imagen
    const reader = new FileReader();
    reader.onload = function (event) {
      setImagePreview(event.target.result);
    };
    reader.readAsDataURL(file);
  };

  // Manejar cambios en los inputs con validación en tiempo real
  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === "contrasena") {
      setNewPassword(value);
    } else if (name === "oldPassword") {
      setOldPassword(value);
    } else if (name === "repeatPassword") {
      setRepeatPassword(value);
    } else {
      setUser((prev) => ({ ...prev, [name]: value }));
      
      // Validación en tiempo real para campos del usuario
      if (validators[name]) {
        const isValid = validators[name](value);
        setErrors(prev => ({ 
          ...prev, 
          [`${name}Error`]: !isValid
        }));
      }
    }
  };

  const esNombreUsuarioRestringido = (nombre) => {
    return nombre
      .toLowerCase()
      .normalize("NFD")
      .replace(/[^\p{L}\p{N}]/gu, "") === "usuarioeliminado";
  };

  // Función para manejar la navegación hacia atrás con confirmación
  const handleGoBack = () => {
    if (hasChanges) {
      Swal.fire({
        title: "¿Estás seguro?",
        text: "No se guardarán los cambios realizados",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sí, salir",
        cancelButtonText: "Cancelar",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
          cancelButton: "custom-cancel-button",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate(-1);
        }
      });
    } else {
      navigate(-1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validar todos los campos antes de enviar
    let formValid = true;
    const newErrors = {};
    
    // Validar campos del usuario
    Object.keys(validators).forEach(field => {
      const isValid = validators[field](user[field]);
      newErrors[`${field}Error`] = !isValid;
      if (!isValid) formValid = false;
    });
    
    // Validar nueva contraseña
    if (newPassword && !validateNewPassword(newPassword)) {
      newErrors.contrasenaError = true;
      formValid = false;
    }
    
    // Validar que las contraseñas coincidan
    if (newPassword && newPassword !== repeatPassword) {
      newErrors.repeatPasswordError = true;
      formValid = false;
    }

    if (esNombreUsuarioRestringido(user.nombreUsuario)) {
      Swal.fire({
        icon: "error",
        title: "Nombre no permitido",
        text: "Este nombre de usuario está restringido. Por favor, elige otro.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      return;
    }
        
    // Si hay nueva contraseña, validar la contraseña antigua
    if (newPassword && !await verificarPassword(oldPassword)) {
      newErrors.oldPasswordError = true;
      formValid = false;
      Swal.fire({ 
        icon: "error", 
        title: "Contraseña incorrecta", 
        text: "Por favor escribe la contraseña actual correctamente.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
      return;
    }
    
    setErrors(newErrors);
    
    if (!formValid) {
      Swal.fire({ 
        icon: "error", 
        title: "Datos incorrectos", 
        text: "Corrija los errores marcados, he intentalo de nuevo.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
      return;
    }

      try {
      const formData = new FormData();
      formData.append("nombreUsuario", user.nombreUsuario);
      formData.append("nombre", user.nombre);
      formData.append("apellidos", user.apellidos);
      formData.append("correo", user.correo);
      formData.append("perfil", user.perfil);

      if (isPhotoDeleted) {
        // Cargar la imagen por defecto y convertirla a Blob
        const response = await fetch(foto_usuario);
        const blob = await response.blob();
        const file = new File([blob], "foto_usuario_blanco.png", { type: blob.type });
        formData.append("foto", file);
      } else if (e.target.foto.files[0]) {
        formData.append("foto", e.target.foto.files[0]);
      }

      if (newPassword) {
        formData.append("contrasena", newPassword);
        formData.append("oldPassword", oldPassword);
        formData.append("repeatPassword", repeatPassword);
      }

      const token = storage.get("authToken");

      const response = await fetch(`${BASE_URL}/api/editar/${id}`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      const data = await response.json();
      if (response.ok) {
        setHasChanges(false);
        Swal.fire({ 
          icon: "success", 
          title: "Perfil actualizado",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          }
        });
        navigate(`/api/perfil/${id}`);
      } else {
        Swal.fire({ 
          icon: "error", 
          title: "Error", 
          text: data?.errorMessage || "Error al actualizar el perfil.",
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          }
        });
      }
    } catch (error) {
      console.error("Error al actualizar el perfil", error);
      Swal.fire({ 
        icon: "error", 
        title: "Error de conexión", 
        text: "No se pudo conectar con el servidor.",
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        }
      });
    }
  };

  if (loading) return <div className="perfil-container">Cargando...</div>;

  return (
    <div className="editar-container">
      {user && (
        <div className="editar-content">
          <form className="editar-form" onSubmit={handleSubmit} encType="multipart/form-data" autoComplete="off">
            <input type="hidden" name="perfil" value={user.perfil} />

            <div className="columna1">
              <div className="fotoPerfil">
                <img
                  src={imagePreview || foto_usuario}
                  alt="Foto de perfil"
                  width="150"
                  height="150"
                  className="foto-perfil"
                  onError={(e) => (e.target.src = foto_usuario)}
                />
                <label htmlFor="foto">Cambiar Foto de Perfil:</label>
                <input type="file" name="foto" id="foto" onChange={handleImageChange} />
                {errors.fotoError && (
                  <span className="mensaje-error">
                    Solo se permiten imágenes en formato JPEG, JPG, PNG o GIF.
                  </span>
                )}
                
                {/* Botón para eliminar foto - solo se muestra si hay una foto cargada */}
                {imagePreview && imagePreview !== foto_usuario && !isPhotoDeleted && (
                  <button 
                    type="button" 
                    className="boton-eliminar-foto" 
                    onClick={handleDeletePhoto} 
                  >
                    Eliminar Foto
                  </button>
                )}
              </div>
            </div>

            <div className="columna2">
              <div className="nombreUsuario">
                <label>Nombre de Usuario:</label>
                <input
                  type="text"
                  id="nombreUsuario"
                  name="nombreUsuario"
                  value={user.nombreUsuario}
                  onChange={handleInputChange}
                  className={errors.nombreUsuarioError ? "input-error" : ""}
                  required
                />
                {errors.nombreUsuarioError && (
                  <span className="mensaje-error">
                    El nombre de usuario debe tener al menos 5 caracteres.
                  </span>
                )}
              </div>

              <div className="nombre">
                <label>Nombre:</label>
                <input
                  type="text"
                  id="nombre"
                  name="nombre"
                  value={user.nombre}
                  onChange={handleInputChange}
                  className={errors.nombreError ? "input-error" : ""}
                  required
                />
                {errors.nombreError && (
                  <span className="mensaje-error">
                    El nombre no debe estar vacío ni contener números o símbolos.
                  </span>
                )}
              </div>

              <div className="apellidos">
                <label>Apellidos:</label>
                <input
                  type="text"
                  id="apellidos"
                  name="apellidos"
                  value={user.apellidos}
                  onChange={handleInputChange}
                  className={errors.apellidosError ? "input-error" : ""}
                  required
                />
                {errors.apellidosError && (
                  <span className="mensaje-error">
                    Los apellidos no deben estar vacíos ni contener números ni símbolos.
                  </span>
                )}
              </div>
            </div>

            <div className="columna3">
              <div className="correo">
                <label>Correo:</label><br />
                <input
                  type="email"
                  id="correo"
                  name="correo"
                  value={user.correo}
                  onChange={handleInputChange}
                  className={errors.correoError ? "input-error" : ""}
                  required
                />
                {errors.correoError && (
                  <span className="mensaje-error">El correo electrónico no es válido.</span>
                )}
              </div>

              {/* Componente para la contraseña actual */}
              <div className="nuevaContrasena">
                <label>Contraseña Actual:</label>
                <div className="password-input-container">
                  <input
                    type={visibleInputs.oldPassword ? "text" : "password"}
                    name="oldPassword"
                    value={oldPassword}
                    onChange={handleInputChange}
                    className={oldPassword && !isOldPasswordCorrect ? "input-error" : ""}
                    placeholder="Solo requerida para cambiar contraseña"
                    autoComplete="new-password"
                    data-form-type="other"
                  />
                  <button
                    type="button"
                    className="boton-ojo"
                    onClick={() => toggleVisibility("oldPassword")}
                  >
                    <img
                      src={visibleInputs.oldPassword ? ojoAbierto : ojoCerrado}
                      alt="Toggle contraseña"
                    />
                  </button>
                </div>
                {oldPassword && !isOldPasswordCorrect && (
                  <span className="mensaje-error">
                    La contraseña actual no es correcta.
                  </span>
                )}
              </div>

              {/* Componente para la nueva contraseña */}
              <div className="nuevaContrasena">
                <label>Nueva Contraseña:</label>
                <div className="password-input-container">
                  <input
                    type={visibleInputs.newPassword ? "text" : "password"}
                    name="contrasena"
                    value={newPassword}
                    onChange={handleInputChange}
                    className={errors.contrasenaError && newPassword ? "input-error" : ""}
                    placeholder="Dejar en blanco para no cambiarla"
                    autoComplete="new-password"
                    data-form-type="other"
                  />
                  <button
                    type="button"
                    className="boton-ojo"
                    onClick={() => toggleVisibility("newPassword")}
                  >
                    <img
                      src={visibleInputs.newPassword ? ojoAbierto : ojoCerrado}
                      alt="Toggle contraseña"                  
                    />
                  </button>
                </div>
                {errors.contrasenaError && newPassword && (
                  <span className="mensaje-error" id="contrasena-error">
                    La contraseña debe tener al menos 8 caracteres, incluir una mayúscula, un número y un símbolo.
                  </span>
                )}
              </div>

              {/* Componente para repetir la nueva contraseña */}
              <div className="nuevaContrasena">
                <label>Repetir Nueva Contraseña:</label>
                <div className="password-input-container">
                  <input
                    type={visibleInputs.repeatPassword ? "text" : "password"}
                    name="repeatPassword"
                    value={repeatPassword}
                    onChange={handleInputChange}
                    placeholder="Dejar en blanco para no cambiarla"
                    className={errors.repeatPasswordError && repeatPassword ? "input-error" : ""}
                    autoComplete="new-password"
                    data-form-type="other"
                  />
                  <button
                    type="button"
                    className="boton-ojo"
                    onClick={() => toggleVisibility("repeatPassword")}
                  >
                    <img
                      src={visibleInputs.repeatPassword ? ojoAbierto : ojoCerrado}
                      alt="Toggle contraseña"
                    />
                  </button>
                </div>
                {errors.repeatPasswordError && repeatPassword && (
                  <span className="mensaje-error">
                    Las contraseñas no coinciden.
                  </span>
                )}
              </div>
              <div className="botones-editar-usuario">
                <button className="boton" type="submit">
                  Guardar
                </button>
                <button className="boton" type="button" onClick={handleGoBack}>
                  Volver
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default EditarUsuario;