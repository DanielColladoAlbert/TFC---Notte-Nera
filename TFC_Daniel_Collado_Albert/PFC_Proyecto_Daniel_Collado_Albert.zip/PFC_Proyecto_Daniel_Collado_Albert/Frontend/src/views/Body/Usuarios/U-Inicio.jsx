import { useState, useEffect } from "react";
import "../../../css/usuarios/U-Inicio.css";
import fondoInicio from "../../../assets/Imagenes/fondoInicio.png";
import storage from "../../../Storage/storage";
import { useNavigate } from "react-router-dom";

const Inicio = () => {
  const [isBlocked, setisBlocked] = useState(false);
  const [id, setID] = useState(null);
  const navigate = useNavigate(); 

  useEffect(() => {
    const authUser = storage.get("authUser");
    if (authUser && authUser.isBlocked) {
      setisBlocked(authUser.isBlocked);
    }
    if (authUser && authUser._id) {
      setID(authUser._id);
    }
  }, []);

  return (
    <div className="main">
      {isBlocked ? (
        navigate(`/api/bloqueado/${id}`) 
      ) : (
        <>
          <div className="imagen-wrapper">
            <img
              src={fondoInicio}
              alt="fondoInicio"
              className="fondoInicio"
            />
          </div>
          <p className="texto">
            El tatuaje es una forma de arte corporal que ha trascendido generaciones y culturas.
            A través de diseños y símbolos, las personas expresan su identidad, creencias y experiencias.
            Ya sea como una declaración sutil o como una tradición,
            el tatuaje ofrece una forma única de llevar historias y significados de manera permanente.
            Cada trazo de tinta en la piel se convierte en un reflejo personal,
            creando una conexión profunda entre el arte, el cuerpo y el alma.
          </p>
        </>
      )}
    </div>
  );
};

export default Inicio;
