import { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import storage from "../../../Storage/storage";
import "../../../css/usuarios/U-Perfil.css";
import "../../../css/base/sweetAlert.css";
import foto_usuario from "../../../assets/Imagenes/foto_usuario_blanco.png";
import Swal from "sweetalert2"; 
import { AuthContext } from "../../../Components/AuthContext";

const BASE_URL = "http://localhost:3016";

const Perfil = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = storage.get("authToken");
        const response = await fetch(`${BASE_URL}/api/perfil/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) throw new Error("Error al obtener los datos del usuario");

        const data = await response.json();
        if (data.status) {
          setUser(data.user);
        } else {
          Swal.fire({ icon: "error", title: "Error", text: "No se pudo cargar la información del usuario.", customClass: customClass() });
        }
      } catch (error) {
        Swal.fire({ icon: "error", title: "Error", text: "No se pudo conectar con el servidor.", customClass: customClass() });
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id]);

  const customClass = () => ({
    popup: "custom-popup",
    title: "custom-title",
    content: "custom-content",
    confirmButton: "custom-confirm-button",
    cancelButton: "custom-confirm-button",
  });

  // Función para verificar si es el último admin
  const checkLastAdmin = async () => {
    try {
      const token = storage.get("authToken");
      const response = await fetch(`${BASE_URL}/api/contarAdmins`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Error al verificar administradores");
      }

      const data = await response.json();

      const isLast = data.count <= 1;
      return isLast; // Retorna true si hay 1 o menos admins
    } catch (error) {
      return false;
    }
  };

  const handleDelete = async () => {
    const authUser = storage.get("authUser");
    
    // Verificar si el usuario es admin y si es el último
    if (authUser.profile && authUser.profile.toLowerCase() === 'admin') {
      const isLastAdmin = await checkLastAdmin();
      
      if (isLastAdmin) {
        Swal.fire({
          icon: "warning",
          title: "No se puede eliminar la cuenta",
          text: "Eres el último administrador del sistema. No puedes eliminar tu cuenta hasta que haya otro administrador.",
          customClass: customClass(),
        });
        return;
      } 
    }

    const result = await Swal.fire({
      icon: "warning",
      title: "¿Estás seguro?",
      text: "Esta acción eliminará permanentemente tu cuenta y las citas pendientes.",
      showCancelButton: true,
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
      customClass: customClass(),
    });

    if (!result.isConfirmed) return;

    try {
      const token = storage.get("authToken");

      await fetch(`${BASE_URL}/api/resenas/anonimizar/${authUser._id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      const citasResponse = await fetch(`${BASE_URL}/api/citas`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!citasResponse.ok) throw new Error("Error al obtener citas");

      const citasData = await citasResponse.json();
      const citas = citasData.data.citas;
      const citasDelUsuario = citas.filter(cita => cita.clienteId === authUser._id);

      for (const cita of citasDelUsuario) {
        await fetch(`${BASE_URL}/api/citas/${cita._id}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }

      const deleteUserResponse = await fetch(`${BASE_URL}/api/${id}?_method=DELETE`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        credentials: "include",
      });

      if (deleteUserResponse.ok) {
        logout();
        Swal.fire({ icon: "success", title: "Usuario eliminado con éxito", customClass: customClass() })
          .then(() => navigate("/api/"));
      } else {
        // Manejar respuesta de error del servidor
        const errorData = await deleteUserResponse.json();
        throw new Error(errorData.message || "Error al eliminar la cuenta");
      }
    } catch (error) {
      Swal.fire({ icon: "error", title: "Error", text: error.message || "No se pudo eliminar la cuenta.", customClass: customClass() });
    }
  };

  const handleLogout = async () => {
    try {
      const response = await fetch("/api/logout", { method: "GET", credentials: "include" });
      if (response.ok) {
        storage.remove("authToken");
        storage.remove("authUser");
        Swal.fire({ icon: "success", title: "Vuelva pronto", text: "Has cerrado sesión correctamente.", customClass: customClass() }).then(() => window.location.reload());
      } else {
        throw new Error("Error al cerrar sesión");
      }
    } catch (error) {
      Swal.fire({ icon: "error", title: "Error", text: "Ha ocurrido un error al intentar cerrar sesión.", customClass: customClass() });
    }
  };

  if (loading) return <div className="perfil-container">Cargando...</div>;

  return (
    <div className="perfil-container">
      {user && (
        <div className="perfil-content">
          <img src={user.foto ? `${BASE_URL}${user.foto}` : foto_usuario} alt="Foto de perfil" width="150" height="150" onError={(e) => (e.target.src = foto_usuario)} />
          <p>Nombre de usuario: {user.nombreUsuario}</p>
          <p>Nombre: {user.nombre}</p>
          <p>Apellidos: {user.apellidos}</p>
          <p>Correo: {user.correo}</p>

          <div className="perfil-buttons">
            <button onClick={handleLogout}>Cerrar sesión</button>
            <button onClick={() => navigate(`/api/editar/${user._id}`)}>Editar Usuario</button>
            <button onClick={() => navigate("/api/")}>Volver</button>
            <button onClick={handleDelete} className="perfil-delete-button">Darse de baja</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Perfil;