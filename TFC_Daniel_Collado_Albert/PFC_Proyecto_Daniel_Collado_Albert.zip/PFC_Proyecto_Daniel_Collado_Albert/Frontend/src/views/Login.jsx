import { useState, useContext, useEffect } from "react";
import "../css/Login.css";
import "../css/base/sweetalert.css";
import Swal from "sweetalert2";
import { useNavigate, useLocation } from "react-router-dom";
import ojoAbierto from "../assets/Imagenes/ojo_abierto.png";
import ojoCerrado from "../assets/Imagenes/ojo_cerrado.png";
import { AuthContext } from "../Components/AuthContext";

const BASE_URL = "http://localhost:3016/api";

const Login = () => {
  const [nombreUsuario, setNombreUsuario] = useState("");
  const [contrasena, setContrasena] = useState("");
  const [passwordVisible, setContrasenaVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated } = useContext(AuthContext);

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/api/");
    }
  }, [isAuthenticated, navigate]);

  const togglePasswordVisibility = () => {
    setContrasenaVisible(!passwordVisible);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    if (isSubmitting) return;
    setIsSubmitting(true);

    if (!nombreUsuario || !contrasena) {
      await Swal.fire({
        icon: 'error',
        title: 'Error de validación',
        text: 'Por favor, ingresa tu nombre de usuario y contraseña',
        confirmButtonText: 'Entendido',
        allowOutsideClick: false,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-No-Redirect": "true"
        },
        body: JSON.stringify({ nombreUsuario, contrasena }),
        credentials: "include"
      });

      const data = await response.json();

      if (!response.ok) {
        await Swal.fire({
          icon: 'error',
          title: 'Error de autenticación',
          text: data.message || 'Usuario o contraseña incorrectos',
          confirmButtonText: 'Entendido',
          allowOutsideClick: false,
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });
        return;
      }

      if (!data.status || !data.token) {
        throw new Error("Formato de respuesta inválido");
      }

      if (data.data?.isBlocked) {
        const userId = data.data._id;
        if (!userId) {
          throw new Error("Usuario bloqueado pero sin ID");
        }

        login(data.token, data.data);

        await Swal.fire({
          icon: 'warning',
          title: 'Usuario bloqueado',
          text: 'Tu cuenta está bloqueada. Contacta con soporte.',
          confirmButtonText: 'Entendido',
          allowOutsideClick: false,
          customClass: {
            popup: "custom-popup",
            title: "custom-title",
            content: "custom-content",
            confirmButton: "custom-confirm-button",
          },
        });

        navigate(`/api/bloqueado/${userId}`);
        return;
      }

      login(data.token, data.data);

      await Swal.fire({
        icon: 'success',
        title: 'Has iniciado sesión correctamente',
        text: 'Bienvenid@ a Notte Nera',
        confirmButtonText: 'Continuar',
        allowOutsideClick: false,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });

      navigate("/api/");

    } catch (error) {
      console.error("Error durante el inicio de sesión:", error);

      await Swal.fire({
        icon: 'error',
        title: 'Error de conexión',
        text: error.message || 'No se pudo conectar con el servidor',
        confirmButtonText: 'Entendido',
        allowOutsideClick: false,
        customClass: {
          popup: "custom-popup",
          title: "custom-title",
          content: "custom-content",
          confirmButton: "custom-confirm-button",
        },
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h1 className="titulo">Iniciar Sesión</h1>
        <form onSubmit={handleLogin}>
          <label htmlFor="nombreUsuario">Nombre de usuario:</label>
          <input
            required
            type="text"
            id="nombreUsuario"
            placeholder="Nombre..."
            value={nombreUsuario}
            onChange={(e) => setNombreUsuario(e.target.value)}
            disabled={isSubmitting}
             tabIndex="1"
          />
          <br /><br />

          <label htmlFor="contrasena">Contraseña:</label>
          <div className="password-container">
            <input
              required
              minLength="8"
              type={passwordVisible ? "text" : "password"}
              id="contrasena"
              placeholder="Contraseña..."
              value={contrasena}
              onChange={(e) => setContrasena(e.target.value)}
              disabled={isSubmitting}
               tabIndex="2"
            />
            <button
              type="button"
              id="togglePassword"
              onClick={togglePasswordVisibility}
              disabled={isSubmitting}
            >
              <img src={passwordVisible ? ojoAbierto : ojoCerrado} alt="Mostrar/Ocultar" width="20" />
            </button>
          </div>
          <br />
          <div className="contenedor-botones-login">
            <button
              className="boton"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Procesando...' : 'Iniciar sesión'}
            </button>
            <button
              className="boton"
              type="button"
              onClick={() => !isSubmitting && navigate("/api/registro")}
              disabled={isSubmitting}
            >
              Registrarse
            </button>
            <button
              className="boton"
              type="button"
              onClick={() => !isSubmitting && navigate("/api/")}
              disabled={isSubmitting}
            >
              Volver
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
