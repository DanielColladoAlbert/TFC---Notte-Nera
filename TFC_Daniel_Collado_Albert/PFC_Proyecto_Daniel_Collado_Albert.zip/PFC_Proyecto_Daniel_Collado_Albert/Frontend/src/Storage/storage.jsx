const storage = {
    set: (key, value) => {
        if (window.localStorage) {
            const valToStore = typeof value === 'string' ? value : JSON.stringify(value);
            window.localStorage.setItem(key, valToStore);
        }
    },
    get: (key) => {
        if (window.localStorage) {
            const item = localStorage.getItem(key);
            try {
                return item ? JSON.parse(item) : null;
            } catch (error) {
                if (key !== "authToken") { 
                    console.warn(`No se pudo parsear '${key}' como JSON.`, error.message);
                }
                return item; 
            }
        }
        return null;
    },
    remove: (key) => {
        if (window.localStorage) {
            window.localStorage.removeItem(key);
        }
    }
};

export default storage;
