import Swal from 'sweetalert2';
import storage from './Storage/storage';
import axios from 'axios';

export const show_alerta = (msg, icon) => {
    Swal.fire({ title: msg, icon: icon });
}

axios.defaults.baseURL = import.meta.env.REACT_APP_BACKEND_URL;

axios.interceptors.response.use(
    response => response,
    async error => {
        if (error.response && error.response.status === 401) {
            const refreshToken = storage.get('refreshToken');

            if (refreshToken) {
                try {
                    const { data } = await axios.post('/auth/refresh-token', { refreshToken });
                    storage.set('authToken', data.token);
                    error.config.headers['Authorization'] = `Bearer ${data.token}`;
                    return axios(error.config);
                } catch (refreshError) {
                    console.error('Error al renovar el token:', refreshError.message);
                    redirectToLogin(); // Redirige al login
                }
            } else {
                redirectToLogin(); // Redirige si no hay token
            }
        }
        return Promise.reject(error);
    }
);

export const sendRequest = async (method, params, url, redir = "", needsAuth = true) => {
    try {
        const token = storage.get('authToken');

        if (needsAuth && (!token || token.split('.').length !== 3)) {
            redirectToLogin();
            return null;
        }

        const config = {
            method,
            url,
            data: params,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': needsAuth ? `Bearer ${token}` : undefined
            }
        };

        const response = await axios(config);

        if (response.data) {
            if (method !== 'GET') {
                show_alerta(response.data.message || 'Operación exitosa', 'success');
            }

            if (response.data.token) {
                storage.set('authToken', response.data.token);
                if (response.data.data) {
                    storage.set('authUser', response.data.data);
                }
            }

            if (redir) {
                setTimeout(() => window.location.href = redir, 2000);
            }

            return response.data;
        }

        return null;

    } catch (error) {
        console.error('Error en sendRequest:', error);
        show_alerta(error.response?.data?.message || 'Ocurrió un error inesperado', 'error');
        return null;
    }
};

export const redirectToLogin = () => {
    Swal.fire({
        title: "Sesión expirada",
        text: "Por favor, inicia sesión nuevamente.",
        icon: "warning",
        confirmButtonText: "Aceptar",
    }).then(() => {
        // Redirige al usuario a la página de inicio de sesión
        window.location.href = "/login";
    });
};

export default show_alerta;