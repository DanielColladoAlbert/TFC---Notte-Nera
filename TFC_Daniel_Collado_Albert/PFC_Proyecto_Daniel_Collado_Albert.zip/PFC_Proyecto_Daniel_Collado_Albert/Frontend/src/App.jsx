import { useState, useEffect } from "react";
import { Route, Routes, Navigate, useLocation } from "react-router-dom";

import Header from "./views/Base/Header";
import Nav from "./views/Base/Nav";
import Footer from "./views/Base/Footer";

import Inicio from "./views/Body/Usuarios/U-Inicio";
import Perfil from "./views/Body/Usuarios/U-Perfil";

import TatRelInicio from "./views/Body/tatuajesRealizados/TR-Inicio";
import TatRelEditar from "./views/Body/tatuajesRealizados/TR-Editar";
import TatRelNuevo from "./views/Body/tatuajesRealizados/TR-Nuevo";

import Citas from "./views/Body/citas/C-Inicio";
import VerDetallesCita from "./views/Body/citas/C-VerDetalles";
import CitaEditar from "./views/Body/citas/C-Editar";
import CitaNueva from "./views/Body/citas/C-Crear";

import DisenosDisponibles from "./views/Body/disenosDisponibles/DD-Inicio";
import DDCrear from "./views/Body/disenosDisponibles/DD-crear";
import DDEditar from "./views/Body/disenosDisponibles/DD-Editar";

import Resenas from "./views/Body/resenas/R-Inicio";
import ResenasCrear from "./views/Body/resenas/R-Crear";
import ResenasEditar from "./views/Body/resenas/R-Editar";

import PanelAdmin from "./views/Body/PanelAdmin/PA-Inicio";
import PABloquear from "./views/Body/PanelAdmin/PA-Bloquear";
import PABloqueado from "./views/Body/PanelAdmin/PA-Bloqueado";

import Login from "./views/Login";

import Registro from "./views/Registro";

import storage from "./Storage/storage";
import { AuthProvider } from "./Components/AuthContext";
import EditarUsuario from "./views/Body/Usuarios/U-Editar";
import { ProtectedRoutes } from './Components/ProtectedRoutes';

const App = () => {
  const [profile, setProfile] = useState("USUARIO");
  const [userId, setUserId] = useState(null);
  const [isBlocked, setIsBlocked] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const authUser = storage.get("authUser");
    if (authUser) {
      if (authUser.profile) {
        setProfile(authUser.profile);
      }
      if (authUser._id) {
        setUserId(authUser._id);
      }
      // Verificar si el usuario está bloqueado
      if (authUser.isBlocked === true) {
        setIsBlocked(true);
      }
    }
    setIsLoading(false);
  }, []);

  // Si está cargando, mostrar un loading
  if (isLoading) {
    return <div>Cargando...</div>;
  }

  // Si el usuario está bloqueado y no está ya en la página de bloqueado, redirigir
  if (isBlocked && userId && !location.pathname.includes('/api/bloqueado/')) {
    return <Navigate to={`/api/bloqueado/${userId}`} replace />;
  }

  return (
    <AuthProvider>
      <div className="app">
        <Header />
        <Nav />
        <main className="content">
          <Routes>
            
            {/* Rutas públicas */}
            <Route path="/api/iniciarSesion" element={<Login />} />
            <Route path="/api/registro" element={<Registro />} />
            <Route path="/api/" element={<Inicio />} />
            <Route path="/api/bloqueado/:id" element={<PABloqueado />} />

            {/* Rutas protegidas */}
            <Route element={<ProtectedRoutes />}>
              
              {/* Usuarios */}
              <Route path="/api/perfil/:id" element={<Perfil />} />
              <Route path="/api/editar/:id" element={<EditarUsuario />} />

              {/* panelAdmin */}
              <Route path="/api/lista" element={<PanelAdmin />} />
              <Route path="/api/bloquear/:id" element={<PABloquear />} />
              

              {/* tatuajesRealizados */}
              <Route path="/api/tatuajesRealizados" element={<TatRelInicio />} />
              <Route path="/api/tatuajesRealizados/editar/:id" element={<TatRelEditar />} />
              <Route path="/api/tatuajesRealizados/nuevo" element={<TatRelNuevo />} />

              {/* citas */}
              <Route path="/api/citas" element={<Citas />} />
              <Route path="/api/citas/nueva" element={<CitaNueva />} />
              <Route path="/api/citas/editar/:id" element={<CitaEditar />} />
              <Route path="/api/citas/verDetalles/:id" element={<VerDetallesCita />} />

              {/* disenosDisponibles */}
              <Route path="/api/disenosDisponibles" element={<DisenosDisponibles />} />
              <Route path="/api/disenosDisponibles/nuevo" element={<DDCrear />} />
              <Route path="/api/disenosDisponibles/editar/:id" element={<DDEditar />} />
              
              {/* resenas */}
              <Route path="/api/resenas" element={<Resenas />} />
              <Route path="/api/resenas/nueva" element={<ResenasCrear />} />
              <Route path="/api/resenas/editar/:id" element={<ResenasEditar />} />
              
            </Route>

            <Route path="*" element={<Inicio />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </AuthProvider>
  );
};

export default App;