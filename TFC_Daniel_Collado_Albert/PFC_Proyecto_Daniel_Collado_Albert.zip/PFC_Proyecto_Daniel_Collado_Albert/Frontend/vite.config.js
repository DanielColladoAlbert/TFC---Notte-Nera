import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  appType: 'spa', // <- esto fuerza el modo SPA con fallback a index.html
  server: {
    proxy: {
      '/tatuajesRealizados': {
        target: 'http://localhost:3016/api',
        changeOrigin: true,
        secure: false
      }
    }
  }
});
